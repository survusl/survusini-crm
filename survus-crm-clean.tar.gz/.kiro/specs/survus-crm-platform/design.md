# Design Document: SURVUS CRM Platform

## Overview

SURVUS — мультиарендная SaaS CRM-платформа для Instagram/Telegram продавцов. Архитектура построена на принципе строгой изоляции данных по `workspace_id`. Доступ к рабочему пространству осуществляется через UUID-токен без регистрации. Super Admin управляет всеми workspace-ами через отдельный защищённый интерфейс.

Стек:
- Backend: Node.js + Express
- Database: SQLite (dev/small deploy) / PostgreSQL (prod)
- Frontend: React + Vite
- Auth: UUID Access Token в заголовке `X-Access-Token`
- Multi-tenant: изоляция по `workspace_id` на уровне каждого SQL-запроса

---

## Architecture

```mermaid
graph TB
    subgraph Client
        FE[React Frontend<br/>Vite]
        SA[Super Admin UI<br/>React]
    end

    subgraph API Layer
        EX[Express Server<br/>Node.js]
        MW[Auth Middleware<br/>Token Validation]
        SAM[Super Admin Middleware<br/>Password Auth]
    end

    subgraph Business Logic
        WS[Workspace Service]
        LS[Lead Service]
        TS[Task Service]
        DS[Dashboard Service]
        CS[CRM Config Service]
    end

    subgraph Data Layer
        DB[(SQLite / PostgreSQL)]
        TPL[Template Definitions<br/>JSON files]
    end

    FE -->|X-Access-Token| MW
    SA -->|X-Admin-Password| SAM
    MW --> EX
    SAM --> EX
    EX --> WS
    EX --> LS
    EX --> TS
    EX --> DS
    EX --> CS
    WS --> DB
    LS --> DB
    TS --> DB
    DS --> DB
    CS --> DB
    WS --> TPL
```

Все запросы от клиентского фронтенда проходят через `AuthMiddleware`, который извлекает `workspace_id` из токена и прикрепляет его к объекту запроса. Все сервисы принимают `workspace_id` как обязательный параметр — это гарантирует изоляцию на уровне бизнес-логики, а не только на уровне роутинга.

Super Admin API использует отдельный middleware с паролем, хранящимся в переменной окружения.

---

## Components and Interfaces

### Backend Routes

```
/api/auth
  POST /validate          — проверка токена, возвращает workspace info

/api/leads
  GET    /                — список лидов (фильтр по status)
  POST   /                — создать лид
  GET    /:id             — карточка лида с историей статусов
  PATCH  /:id/status      — обновить статус лида

/api/tasks
  GET    /                — список задач (сортировка по due_date ASC)
  POST   /                — создать задачу
  PATCH  /:id/complete    — отметить задачу выполненной

/api/dashboard
  GET    /stats           — агрегированная статистика workspace

/api/admin                — защищён X-Admin-Password
  GET    /workspaces      — список всех workspace-ов
  POST   /workspaces      — создать workspace
  PATCH  /workspaces/:id  — обновить (статус, подписка, конфиг)
  DELETE /workspaces/:id  — удалить workspace
  GET    /stats           — системная статистика
  GET    /templates       — список CRM шаблонов
```

### Frontend Components

```
App
├── AuthGate              — проверяет токен из URL/localStorage
├── Layout
│   ├── Sidebar           — навигация: Dashboard, Contacts, Leads,
│   │                       Deals, Tasks, Appointments, Reports
│   └── TopBar
├── Pages
│   ├── Dashboard         — статистические карточки + последние лиды
│   ├── Leads             — таблица лидов с фильтрами
│   ├── LeadCard          — детальная карточка лида
│   ├── Tasks             — список задач
│   └── [Contacts, Deals, Appointments, Reports] — заглушки
└── SuperAdmin (отдельный роут /admin)
    ├── AdminLogin
    ├── WorkspaceList
    ├── WorkspaceForm
    └── WorkspaceDetail
```

### Auth Middleware

```typescript
// Псевдокод middleware
function authMiddleware(req, res, next) {
  const token = req.headers['x-access-token']
  if (!token) return res.status(401).json({ error: 'No token' })
  
  const workspace = db.findWorkspaceByToken(token)
  if (!workspace) return res.status(401).json({ error: 'Invalid token' })
  if (workspace.subscription_status === 'suspended') return res.status(403).json({ error: 'Suspended' })
  if (new Date() > workspace.subscription_until) return res.status(403).json({ error: 'Expired' })
  
  req.workspaceId = workspace.id
  next()
}
```

---

## Data Models

### workspaces

| Поле | Тип | Описание |
|------|-----|----------|
| id | UUID | Primary key |
| company_name | TEXT | Название компании |
| access_token | UUID | Уникальный токен доступа |
| template_id | TEXT | Идентификатор CRM шаблона |
| crm_config | JSON | Текущая конфигурация (tabs, statuses, color) |
| subscription_status | TEXT | active / suspended / expired |
| subscription_until | DATE | Дата окончания подписки |
| created_at | TIMESTAMP | Дата создания |

### leads

| Поле | Тип | Описание |
|------|-----|----------|
| id | UUID | Primary key |
| workspace_id | UUID | FK → workspaces.id |
| name | TEXT | Имя лида |
| username | TEXT | Username (Instagram/Telegram) |
| note | TEXT | Заметка (опционально) |
| status | TEXT | new / replied / paid / canceled |
| created_at | TIMESTAMP | Дата создания |
| updated_at | TIMESTAMP | Дата последнего обновления |

### lead_status_history

| Поле | Тип | Описание |
|------|-----|----------|
| id | UUID | Primary key |
| lead_id | UUID | FK → leads.id |
| workspace_id | UUID | FK → workspaces.id (для изоляции) |
| old_status | TEXT | Предыдущий статус |
| new_status | TEXT | Новый статус |
| changed_at | TIMESTAMP | Время изменения |

### tasks

| Поле | Тип | Описание |
|------|-----|----------|
| id | UUID | Primary key |
| workspace_id | UUID | FK → workspaces.id |
| title | TEXT | Заголовок задачи |
| due_date | TIMESTAMP | Срок выполнения |
| lead_id | UUID | FK → leads.id (опционально) |
| is_completed | BOOLEAN | Выполнена ли задача |
| is_overdue | BOOLEAN | Просрочена ли задача |
| created_at | TIMESTAMP | Дата создания |

### CRM Template Definition (JSON)

```json
{
  "id": "instagram_sales",
  "name": "Instagram Sales",
  "tabs": [
    { "key": "dashboard", "label": "Dashboard", "order": 1, "enabled": true },
    { "key": "leads", "label": "Leads", "order": 2, "enabled": true },
    { "key": "contacts", "label": "Contacts", "order": 3, "enabled": true },
    { "key": "deals", "label": "Deals", "order": 4, "enabled": true },
    { "key": "tasks", "label": "Tasks", "order": 5, "enabled": true },
    { "key": "appointments", "label": "Appointments", "order": 6, "enabled": false },
    { "key": "reports", "label": "Reports", "order": 7, "enabled": true }
  ],
  "lead_statuses": ["new", "replied", "paid", "canceled"],
  "primary_color": "#22c55e"
}
```

Четыре шаблона (`instagram_sales`, `beauty`, `services`, `simple_sales`) хранятся как статические JSON-файлы в `src/templates/`. При создании workspace шаблон копируется в `crm_config` — дальнейшие изменения шаблона не влияют на существующие workspace-ы.

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Уникальность Access Token

*For any* набора созданных workspace-ов, все `access_token` должны быть уникальными — ни один токен не должен повторяться.

**Validates: Requirements 1.2**

---

### Property 2: Применение CRM Template

*For any* workspace, созданного с конкретным `template_id`, поле `crm_config` должно содержать те же вкладки, статусы и базовую логику, что определены в соответствующем шаблоне.

**Validates: Requirements 1.3, 2.2**

---

### Property 3: Изоляция шаблона от workspace

*For any* workspace, созданного с шаблоном T, изменение определения шаблона T не должно изменять `crm_config` этого workspace.

**Validates: Requirements 2.3**

---

### Property 4: Workspace Isolation (изоляция данных)

*For any* валидного Access Token и любого запроса к API, все возвращаемые данные (лиды, задачи, статистика) должны принадлежать исключительно workspace, ассоциированному с этим токеном.

**Validates: Requirements 4.3, 9.3**

---

### Property 5: Отклонение невалидного токена

*For any* строки, не являющейся действующим Access Token зарегистрированного активного workspace, API должен вернуть HTTP 401.

**Validates: Requirements 4.2, 4.4, 9.2**

---

### Property 6: Блокировка доступа при истёкшей подписке

*For any* workspace, у которого `subscription_until` меньше текущей даты, любой API-запрос с его токеном должен быть отклонён (HTTP 403).

**Validates: Requirements 5.2**

---

### Property 7: Блокировка доступа при suspended статусе

*For any* workspace с `subscription_status = suspended`, любой API-запрос с его токеном должен быть отклонён (HTTP 403).

**Validates: Requirements 5.4**

---

### Property 8: Корректность статистики Dashboard

*For any* workspace с произвольным набором лидов, значения `total`, `paid_count` и `new_count` на Dashboard должны точно соответствовать фактическому количеству лидов с соответствующими статусами в базе данных.

**Validates: Requirements 7.1, 7.2, 7.3**

---

### Property 9: Создание лида — начальный статус и принадлежность

*For any* валидного запроса на создание лида (с name и username), созданный лид должен иметь `status = new` и `workspace_id`, совпадающий с workspace токена.

**Validates: Requirements 6.2, 6.6**

---

### Property 10: Фильтрация лидов по статусу

*For any* запроса на получение лидов с фильтром по статусу S, все возвращённые лиды должны иметь `status = S` и принадлежать текущему workspace.

**Validates: Requirements 6.4**

---

### Property 11: Обновление статуса лида — round trip

*For any* лида и любого валидного нового статуса, после обновления статуса запрос карточки лида должен вернуть новый статус и содержать запись в истории с временной меткой.

**Validates: Requirements 6.3, 6.5**

---

### Property 12: Сортировка задач по due_date

*For any* набора задач в workspace, API `/api/tasks` должен возвращать их отсортированными по `due_date` в порядке возрастания.

**Validates: Requirements 8.4**

---

### Property 13: Просроченные задачи

*For any* задачи, у которой `due_date` меньше текущего времени и `is_completed = false`, поле `is_overdue` должно быть `true`.

**Validates: Requirements 8.2**

---

### Property 14: Персистентность CRM Config

*For any* изменения конфигурации workspace (порядок вкладок, названия, статусы лидов, primary color), чтение `crm_config` после сохранения должно вернуть те же значения, что были записаны.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5**

---

### Property 15: Запрет доступа к чужому workspace

*For any* попытки обратиться к ресурсу (лид, задача), принадлежащему другому workspace, API должен вернуть HTTP 403.

**Validates: Requirements 9.4**

---

## Error Handling

| Ситуация | HTTP код | Описание |
|----------|----------|----------|
| Токен отсутствует | 401 | Заголовок `X-Access-Token` не передан |
| Токен невалиден | 401 | Токен не найден в БД |
| Подписка истекла | 403 | `subscription_until` < now |
| Workspace suspended | 403 | `subscription_status = suspended` |
| Доступ к чужому ресурсу | 403 | `workspace_id` не совпадает |
| Ресурс не найден | 404 | Лид/задача не существует |
| Невалидные данные | 422 | Ошибки валидации входных данных |
| Внутренняя ошибка | 500 | Непредвиденная ошибка сервера |

Все ошибки возвращаются в формате:
```json
{ "error": "Human-readable message", "code": "ERROR_CODE" }
```

Middleware обрабатывает ошибки централизованно — сервисы бросают типизированные ошибки (`AuthError`, `NotFoundError`, `ForbiddenError`), которые Express error handler преобразует в соответствующие HTTP-ответы.

---

## Testing Strategy

### Dual Testing Approach

Используется два уровня тестирования, которые дополняют друг друга:

**Unit / Integration Tests** — конкретные примеры и граничные случаи:
- Проверка каждого API endpoint с валидными и невалидными данными
- Проверка middleware (отсутствие токена, невалидный токен, истёкшая подписка)
- Проверка применения CRM шаблонов при создании workspace
- Проверка наличия всех 4 шаблонов в системе
- Проверка структуры sidebar (все 7 разделов навигации)

**Property-Based Tests** — универсальные свойства для всех входных данных:
- Библиотека: **fast-check** (TypeScript/JavaScript)
- Минимум **100 итераций** на каждый тест
- Каждый тест помечается комментарием: `// Feature: survus-crm-platform, Property N: <text>`

### Property Test Mapping

| Property | Тест | Генераторы |
|----------|------|------------|
| P1: Уникальность токенов | Генерировать N workspace-ов, проверить уникальность токенов | `fc.array(fc.record({name: fc.string()}), {minLength: 2})` |
| P2: Применение шаблона | Для каждого из 4 шаблонов создать workspace, сравнить config с шаблоном | `fc.constantFrom('instagram_sales', 'beauty', 'services', 'simple_sales')` |
| P3: Изоляция шаблона | Создать workspace, изменить шаблон, проверить config не изменился | `fc.record(...)` |
| P4: Workspace Isolation | Создать 2 workspace, запросить данные одного с токеном другого | `fc.uuid(), fc.uuid()` |
| P5: Отклонение невалидного токена | Генерировать случайные строки, проверить 401 | `fc.string()` |
| P6: Блокировка по дате | Генерировать прошедшие даты, проверить 403 | `fc.date({max: new Date()})` |
| P7: Блокировка suspended | Создать suspended workspace, проверить 403 | — |
| P8: Статистика Dashboard | Генерировать лиды с разными статусами, проверить агрегаты | `fc.array(fc.constantFrom('new','replied','paid','canceled'))` |
| P9: Создание лида | Генерировать валидные name/username, проверить status=new и workspace_id | `fc.record({name: fc.string({minLength:1}), username: fc.string({minLength:1})})` |
| P10: Фильтрация лидов | Генерировать лиды, фильтровать, проверить все результаты имеют нужный статус | `fc.constantFrom('new','replied','paid','canceled')` |
| P11: Round trip статуса | Обновить статус, прочитать карточку, проверить статус и историю | `fc.constantFrom('replied','paid','canceled')` |
| P12: Сортировка задач | Генерировать задачи с разными due_date, проверить порядок | `fc.array(fc.date())` |
| P13: Просроченные задачи | Генерировать задачи с прошедшими датами, проверить is_overdue=true | `fc.date({max: new Date()})` |
| P14: Персистентность config | Генерировать конфиги, сохранить, прочитать, сравнить | `fc.record({tabs: fc.array(...), color: fc.hexaString()})` |
| P15: Запрет чужого ресурса | Создать лид в workspace A, запросить с токеном workspace B | `fc.uuid(), fc.uuid()` |

### Test Configuration

```javascript
// fast-check config для всех property тестов
fc.configureGlobal({ numRuns: 100 })
```

Каждый property тест:
```javascript
// Feature: survus-crm-platform, Property 1: Уникальность Access Token
it('all workspace tokens are unique', () => {
  fc.assert(fc.asyncProperty(
    fc.array(fc.record({ name: fc.string({ minLength: 1 }) }), { minLength: 2, maxLength: 20 }),
    async (workspaceInputs) => {
      const tokens = await Promise.all(workspaceInputs.map(w => createWorkspace(w)))
      const tokenSet = new Set(tokens.map(w => w.access_token))
      return tokenSet.size === tokens.length
    }
  ), { numRuns: 100 })
})
```
