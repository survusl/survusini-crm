# Requirements Document

## Introduction

SURVUS — это SaaS CRM-платформа с мультиарендной (multi-tenant) архитектурой, ориентированная на Instagram/Telegram продавцов. Доступ к системе осуществляется через уникальный токен, выдаваемый super admin через административную панель. Платформа предоставляет готовые CRM-шаблоны под разные типы бизнеса и позволяет масштабировать продажи без изменения кода.

## Glossary

- **System**: Платформа SURVUS в целом
- **Super_Admin_Panel**: Административный интерфейс для управления всеми workspace-ами
- **Super_Admin**: Привилегированный пользователь, управляющий платформой через Super_Admin_Panel
- **Workspace**: Изолированная рабочая среда одного клиента (компании) внутри платформы
- **Access_Token**: Уникальный токен, предоставляющий доступ к конкретному Workspace
- **CRM_Template**: Предустановленный шаблон структуры CRM (набор вкладок, статусов, логики)
- **Lead**: Запись о потенциальном клиенте внутри Workspace
- **Lead_Status**: Статус лида: new, replied, paid, canceled
- **Dashboard**: Главная страница Workspace с агрегированной статистикой
- **Subscription**: Подписка Workspace, определяющая срок и статус доступа
- **Token_Auth**: Механизм аутентификации по Access_Token без регистрации
- **Workspace_Isolation**: Принцип строгого разделения данных между Workspace-ами по workspace_id
- **CRM_Config**: Пользовательская конфигурация Workspace на основе выбранного CRM_Template

---

## Requirements

### Requirement 1: Управление Workspace через Super Admin Panel

**User Story:** As a Super_Admin, I want to create and manage workspaces, so that I can onboard new clients and control their access to the platform.

#### Acceptance Criteria

1. THE Super_Admin_Panel SHALL provide an interface for creating a new Workspace with a company name and a selected CRM_Template.
2. WHEN a Super_Admin creates a Workspace, THE System SHALL generate a unique Access_Token for that Workspace.
3. WHEN a Super_Admin creates a Workspace, THE System SHALL apply the selected CRM_Template as the default CRM_Config for that Workspace.
4. THE Super_Admin_Panel SHALL display a list of all Workspaces including: company name, status, CRM_Template name, number of leads, and subscription expiry date.
5. WHEN a Super_Admin selects a Workspace, THE Super_Admin_Panel SHALL allow the Super_Admin to activate, suspend, extend the subscription, or delete that Workspace.
6. THE Super_Admin_Panel SHALL display system-wide statistics including: total number of Workspaces, total number of leads across all Workspaces, and number of active Workspaces.

---

### Requirement 2: CRM Templates

**User Story:** As a Super_Admin, I want to choose from predefined CRM templates when creating a workspace, so that clients get a relevant structure out of the box.

#### Acceptance Criteria

1. THE System SHALL support the following CRM_Template types: `instagram_sales`, `beauty`, `services`, `simple_sales`.
2. WHEN a CRM_Template is applied to a Workspace, THE System SHALL configure the Workspace with the template's predefined tabs, tab order, tab names, Lead_Status values, and base logic.
3. THE System SHALL store each CRM_Template definition independently so that changes to a template do not affect already-created Workspaces.

---

### Requirement 3: No-Code Workspace Customization

**User Story:** As a Super_Admin, I want to customize a workspace's CRM configuration without writing code, so that I can tailor the experience for each client.

#### Acceptance Criteria

1. WHEN a Workspace has been created, THE Super_Admin_Panel SHALL allow the Super_Admin to enable or disable individual tabs in the Workspace's CRM_Config.
2. WHEN a Super_Admin modifies tab order in a Workspace, THE System SHALL persist the new tab order in the Workspace's CRM_Config.
3. WHEN a Super_Admin renames a tab in a Workspace, THE System SHALL persist the new tab name in the Workspace's CRM_Config.
4. WHEN a Super_Admin edits Lead_Status values for a Workspace, THE System SHALL persist the updated statuses in the Workspace's CRM_Config.
5. WHEN a Super_Admin sets a primary color for a Workspace, THE System SHALL apply that color as the Workspace's branding theme.

---

### Requirement 4: Token-Based Access

**User Story:** As a client user, I want to access my workspace using only a token, so that I can start using the CRM without going through a registration process.

#### Acceptance Criteria

1. WHEN a user provides a valid Access_Token, THE Token_Auth SHALL grant the user access to the corresponding Workspace.
2. WHEN a user provides an invalid or expired Access_Token, THE Token_Auth SHALL return an authentication error with HTTP status 401.
3. WHILE a user is authenticated via Access_Token, THE System SHALL restrict the user's data access to the Workspace associated with that token (Workspace_Isolation).
4. THE System SHALL validate the Access_Token on every API request before processing the request.

---

### Requirement 5: Subscription Management

**User Story:** As a Super_Admin, I want to manage workspace subscriptions, so that I can control client access based on their payment status.

#### Acceptance Criteria

1. THE System SHALL store a `subscription_until` date and a `subscription_status` field for each Workspace.
2. WHEN the current date exceeds a Workspace's `subscription_until` date, THE System SHALL block or restrict access to that Workspace.
3. WHEN a Super_Admin extends a Workspace's subscription, THE System SHALL update the `subscription_until` date and set `subscription_status` to active.
4. WHEN a Super_Admin suspends a Workspace, THE System SHALL set the Workspace's `subscription_status` to suspended and deny access to that Workspace.

---

### Requirement 6: Lead Management

**User Story:** As a client user, I want to manage leads inside my workspace, so that I can track potential customers through the sales process.

#### Acceptance Criteria

1. THE System SHALL store each Lead with the following fields: name, username, note, Lead_Status, and creation date.
2. WHEN a user creates a Lead, THE System SHALL assign the Lead to the user's Workspace and set the initial Lead_Status to `new`.
3. WHEN a user updates a Lead's status, THE System SHALL persist the new Lead_Status and record the update timestamp.
4. THE System SHALL allow a user to filter Leads by Lead_Status within their Workspace.
5. WHEN a user views a Lead, THE System SHALL display the Lead's full card including all stored fields and status history.
6. THE System SHALL provide a quick-add interface that allows a user to create a Lead with only name and username as required fields.

---

### Requirement 7: Dashboard

**User Story:** As a client user, I want to see aggregated statistics on my dashboard, so that I can quickly understand the state of my sales pipeline.

#### Acceptance Criteria

1. WHEN a user opens the Dashboard, THE System SHALL display the total number of Leads in the Workspace.
2. WHEN a user opens the Dashboard, THE System SHALL display the number of Leads with Lead_Status `paid`.
3. WHEN a user opens the Dashboard, THE System SHALL display the number of Leads with Lead_Status `new`.
4. WHILE a user is viewing the Dashboard, THE System SHALL reflect the current state of Leads without requiring a page reload (data freshness within 60 seconds).

---

### Requirement 8: Tasks and Reminders

**User Story:** As a client user, I want to create tasks and reminders linked to leads, so that I can follow up with clients at the right time.

#### Acceptance Criteria

1. THE System SHALL allow a user to create a Task with a title, due date, and optional link to a Lead.
2. WHEN a Task's due date is reached, THE System SHALL mark the Task as overdue.
3. THE System SHALL allow a user to mark a Task as completed.
4. THE System SHALL display all Tasks for the current Workspace sorted by due date in ascending order.

---

### Requirement 9: REST API and Workspace Isolation

**User Story:** As a developer, I want a REST API with strict workspace isolation, so that client data is never exposed across tenants.

#### Acceptance Criteria

1. THE System SHALL expose a REST API for all CRM operations (leads, tasks, dashboard statistics).
2. WHEN an API request is received, THE System SHALL validate the Access_Token before executing any data operation.
3. WHEN an API request is received, THE System SHALL scope all database queries to the workspace_id associated with the Access_Token.
4. IF a request attempts to access data outside its workspace_id scope, THEN THE System SHALL return an authorization error with HTTP status 403.
5. THE System SHALL implement the backend using Node.js with Express framework.
6. THE System SHALL use PostgreSQL or SQLite as the primary database.

---

### Requirement 10: Frontend Interface

**User Story:** As a client user, I want a fast and responsive UI, so that I can use the CRM efficiently on any device.

#### Acceptance Criteria

1. THE System SHALL provide a web frontend built with React or a comparable framework.
2. THE System SHALL render a sidebar navigation containing the following sections: Dashboard, Contacts, Leads, Deals, Tasks, Appointments, Reports.
3. THE System SHALL display statistic cards at the top of the Dashboard page.
4. THE System SHALL apply the Workspace's configured primary color as the UI theme color.
5. WHILE a user accesses the frontend on a mobile device, THE System SHALL render a responsive layout adapted to the screen width.
