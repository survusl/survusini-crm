# 🎬 SURVUS Landing Page - Анімації та Ефекти

## ✨ Реалізовані анімації

### 1. Scroll Animations (Intersection Observer)
Всі секції анімуються при скролі з використанням Intersection Observer API:

```javascript
// Автоматично додає клас 'animate-in' коли елемент з'являється
const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in');
      }
    });
  },
  { threshold: 0.1, rootMargin: '0px 0px -100px 0px' }
);
```

**Анімовані секції:**
- Features Section (картки з'являються по черзі)
- Analytics Section (графіки та статистика)
- Why SURVUS (переваги з затримкою)
- Inspired by Discord (порівняння дизайнів)

### 2. Hero Section Animations

**Parallax ефект:**
- Фон рухається повільніше за контент
- CRM preview має 3D перспективу
- Орби плавають з різною швидкістю

```css
transform: translateY(${scrollY * 0.15}px)  /* Hero content */
transform: translateY(${scrollY * 0.1}px)   /* CRM preview */
```

**Анімовані елементи:**
- 3D орби (float animation, 20s)
- Зірки (twinkle animation, 8s)
- Badge dot (pulse, 2s)
- Gradient text (shimmer effect)

### 3. CRM Interface Animations

**Статистичні картки:**
- Hover: translateY(-2px) + border glow
- Icon: scale(1.1) + rotate(5deg)
- Trend badge: pulse animation

**Графіки:**
- Bar chart: barGrow animation (0.6s)
- Line chart: fadeIn + dotPulse (2s)
- Pie chart: segment hover (stroke-width increase)

**Ліди:**
- Slide up animation (0.3s)
- Hover: translateX(4px)
- Avatar: gradient background

### 4. Feature Cards

**Базова анімація:**
```css
.feature-card-discord:hover {
  transform: translateY(-8px) scale(1.02);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}
```

**Icon animation:**
```css
.feature-icon-discord {
  animation: float-icon 4s ease-in-out infinite;
}
```

**Glow effect:**
- Opacity 0 → 1 on hover
- Radial gradient з primary кольором

### 5. Analytics Section

**Mini cards:**
```css
.analytics-mini-card:hover {
  transform: translateY(-6px) rotate(2deg);
}
```

**Line chart:**
- Dots: pulse animation (2s)
- Hover: scale(1.5) + glow increase
- Staggered appearance (80ms delay)

### 6. Discord Comparison Section

**Mockup animations:**
- Hover: translateY(-8px)
- Shadow: 0 30px 80px
- Messages: slide in from left

**Arrow:**
```css
@keyframes arrowPulse {
  0%, 100% { transform: translateX(0); opacity: 0.6; }
  50% { transform: translateX(10px); opacity: 1; }
}
```

**SURVUS bars:**
- Staggered growth (100ms delay)
- Gradient + glow effect
- Smooth cubic-bezier timing

### 7. Why Section

**Cards:**
```css
.why-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 20px 60px rgba(88, 101, 242, 0.2);
}
```

**Number:**
- Gradient text
- Opacity 0.3 (subtle)
- Large font (48px)

### 8. CTA Section

**Glow animation:**
```css
@keyframes glowPulse {
  0%, 100% { opacity: 0.3; transform: scale(1); }
  50% { opacity: 0.5; transform: scale(1.1); }
}
```

**Buttons:**
- Primary: translateY(-2px) + shadow increase
- Secondary: background change + border glow

### 9. Footer

**Links:**
- Hover: color change to primary
- Smooth transition (0.2s)

### 10. Modal (Token Input)

**Overlay:**
- Backdrop blur (8px)
- Fade in (0.15s)

**Modal:**
- Scale in animation (0.22s)
- Cubic-bezier easing

## 🎨 Timing Functions

Всі анімації використовують:
```css
cubic-bezier(0.16, 1, 0.3, 1)  /* Smooth, natural easing */
```

## ⚡ Performance

- CSS transforms (GPU accelerated)
- Will-change для критичних елементів
- Intersection Observer (ліниве завантаження)
- RequestAnimationFrame для scroll

## 📱 Responsive

Анімації адаптуються для:
- Desktop: повні ефекти
- Tablet: зменшені transforms
- Mobile: спрощені анімації

## 🔧 Налаштування

Швидкість анімацій можна змінити в CSS:
```css
:root {
  --animation-speed-fast: 0.2s;
  --animation-speed-normal: 0.4s;
  --animation-speed-slow: 0.8s;
}
```

## 🎯 Ключові особливості

1. **Плавність** - всі переходи smooth
2. **Природність** - cubic-bezier easing
3. **Продуктивність** - GPU acceleration
4. **Адаптивність** - responsive breakpoints
5. **Доступність** - prefers-reduced-motion support

## 📊 Статистика

- Загальна кількість анімацій: 25+
- Keyframe animations: 15
- Transition effects: 30+
- Scroll-triggered: 10+
- Hover effects: 20+
