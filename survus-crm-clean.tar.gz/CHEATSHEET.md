# 📝 SURVUS CRM - Шпаргалка команд

## 🚀 Деплой

```bash
# Автоматичний деплой на Git
./deploy.sh        # macOS/Linux
deploy.bat         # Windows

# Ручний деплой
git add .
git commit -m "Update"
git push
```

## 🔧 Виправлення локального сервера

```bash
# Повне виправлення
./fix-local.sh     # macOS/Linux
fix-local.bat      # Windows

# Швидкий перезапуск
pkill -f node      # Зупинити Node.js
npm start          # Запустити знову
```

## 💻 Локальна розробка

```bash
# Запустити все
npm start

# Окремо
npm run dev:backend   # :3001
npm run dev:frontend  # :5173
npm run dev:admin     # :5174

# Build
npm run build
npm run build:frontend
npm run build:admin
```

## 🗄️ База даних

```bash
# Міграції
npm run migrate
cd backend && node src/migrate.js

# Очистити БД
rm backend/data/survus.db
npm run migrate

# Тестові дані
npm run seed
```

## 📦 Залежності

```bash
# Встановити все
npm install

# Окремо
cd backend && npm install
cd frontend && npm install
cd admin && npm install

# Очистити кеш
npm cache clean --force
rm -rf node_modules
npm install
```

## 🐛 Debugging

```bash
# Перевірити порти
lsof -i :3001      # Backend
lsof -i :5173      # Frontend
lsof -i :5174      # Admin

# Вбити процес
kill -9 <PID>

# Логи
npm run dev:backend  # Дивитись логи backend
```

## 🌐 Railway

```bash
# Після push на GitHub
# Railway автоматично деплоїть!

# Перевірити статус
# https://railway.app/dashboard

# Логи
# Railway Dashboard → Service → Logs
```

## 📁 Структура

```
survus-crm/
├── backend/          # API
│   ├── src/
│   │   ├── routes/   # Маршрути
│   │   ├── services/ # Логіка
│   │   └── migrations/ # БД
│   └── data/         # SQLite
├── frontend/         # CRM
│   └── src/
│       ├── pages/    # Сторінки
│       └── components/ # Компоненти
└── admin/            # Admin Panel
```

## 🔑 Перший вхід

```
1. http://localhost:5174/admin
   Login: admin
   Password: admin123

2. Створити workspace
3. Скопіювати токен
4. http://localhost:5173
5. Вставити токен
```

## 🎨 Кольори теми

```css
--bg: #0a0f0d           /* Фон */
--green-accent: #2d5f4a /* Акцент */
--green-glow: #3dd68c   /* Підсвітка */
```

## 📖 Документація

```
START_HERE_DEPLOY.md    - Почніть тут
QUICK_DEPLOY.md         - 5 хвилин
DEPLOYMENT_GUIDE.md     - Повна інструкція
README.md               - Загальна інфо
```

## ⚡ Швидкі виправлення

```bash
# Не запускається
./fix-local.sh

# Порт зайнятий
lsof -i :3001 | grep LISTEN | awk '{print $2}' | xargs kill -9

# БД пошкоджена
rm backend/data/survus.db && npm run migrate

# Git проблеми
git reset --hard HEAD
git clean -fd
```

## 🎯 Production URLs

```
Frontend: https://your-app.up.railway.app
Admin:    https://your-app.up.railway.app/admin
Backend:  https://your-app.up.railway.app/api
```

---

**SURVUS CRM** 🌿
