# 🚀 SURVUS CRM - Повна інструкція деплою на сервер

## 📋 Зміст
1. [Підготовка проєкту](#підготовка-проєкту)
2. [Створення Git репозиторію](#створення-git-репозиторію)
3. [Деплой на Railway](#деплой-на-railway)
4. [Деплой на Render](#деплой-на-render)
5. [Деплой на Vercel + Railway](#деплой-на-vercel--railway)
6. [Налаштування після деплою](#налаштування-після-деплою)

---

## 1️⃣ Підготовка проєкту

### Перевірте файли:
```bash
# Переконайтеся, що всі файли на місці
ls -la

# Має бути:
# - backend/
# - frontend/
# - admin/
# - package.json
# - railway.json
# - .gitignore
```

### Створіть .env файл для production:
```bash
# backend/.env.production
NODE_ENV=production
PORT=3001
DATABASE_PATH=./data/survus.db
```

---

## 2️⃣ Створення Git репозиторію

### Крок 1: Ініціалізація Git
```bash
# Якщо Git ще не ініціалізований
git init

# Додайте всі файли
git add .

# Зробіть перший коміт
git commit -m "Initial commit: SURVUS CRM Platform"
```

### Крок 2: Створіть репозиторій на GitHub

1. Відкрийте https://github.com/new
2. Назва репозиторію: `survus-crm`
3. Опис: `SURVUS - Modern CRM Platform with Dark Green Theme`
4. Виберіть **Private** (якщо не хочете публічний)
5. **НЕ** додавайте README, .gitignore, license (вони вже є)
6. Натисніть **Create repository**

### Крок 3: Підключіть локальний репозиторій до GitHub
```bash
# Замініть YOUR_USERNAME на ваш GitHub username
git remote add origin https://github.com/YOUR_USERNAME/survus-crm.git

# Відправте код на GitHub
git branch -M main
git push -u origin main
```

---

## 3️⃣ Деплой на Railway (РЕКОМЕНДОВАНО)

Railway - найпростіший спосіб задеплоїти fullstack додаток.

### Крок 1: Створіть акаунт
1. Відкрийте https://railway.app
2. Натисніть **Login with GitHub**
3. Авторизуйтесь через GitHub

### Крок 2: Створіть новий проєкт
1. Натисніть **New Project**
2. Виберіть **Deploy from GitHub repo**
3. Виберіть репозиторій `survus-crm`
4. Railway автоматично виявить `railway.json` та налаштує деплой

### Крок 3: Налаштування змінних середовища
1. Відкрийте проєкт
2. Виберіть сервіс **backend**
3. Перейдіть в **Variables**
4. Додайте:
   ```
   NODE_ENV=production
   PORT=3001
   DATABASE_PATH=/app/data/survus.db
   ```

### Крок 4: Налаштування домену
1. Відкрийте сервіс **frontend**
2. Перейдіть в **Settings** → **Networking**
3. Натисніть **Generate Domain**
4. Скопіюйте URL (наприклад: `survus-crm.up.railway.app`)

### Крок 5: Оновіть API URL
```bash
# Відредагуйте frontend/src/api/client.js
# Замініть baseURL на ваш Railway backend URL
```

### ✅ Готово! Ваш CRM доступний за адресою Railway!

---

## 4️⃣ Деплой на Render

Render - альтернатива Railway з безкоштовним планом.

### Крок 1: Створіть акаунт
1. Відкрийте https://render.com
2. Натисніть **Get Started**
3. Авторизуйтесь через GitHub

### Крок 2: Деплой Backend
1. Натисніть **New +** → **Web Service**
2. Підключіть репозиторій `survus-crm`
3. Налаштування:
   - **Name**: `survus-backend`
   - **Root Directory**: `backend`
   - **Build Command**: `npm install && npm run migrate`
   - **Start Command**: `npm start`
   - **Environment**: Node
4. Додайте змінні:
   ```
   NODE_ENV=production
   PORT=3001
   DATABASE_PATH=/opt/render/project/data/survus.db
   ```
5. Натисніть **Create Web Service**

### Крок 3: Деплой Frontend
1. Натисніть **New +** → **Static Site**
2. Підключіть репозиторій `survus-crm`
3. Налаштування:
   - **Name**: `survus-frontend`
   - **Root Directory**: `frontend`
   - **Build Command**: `npm install && npm run build`
   - **Publish Directory**: `dist`
4. Додайте змінну:
   ```
   VITE_API_URL=https://survus-backend.onrender.com/api
   ```
5. Натисніть **Create Static Site**

### Крок 4: Деплой Admin
1. Повторіть кроки для frontend, але:
   - **Name**: `survus-admin`
   - **Root Directory**: `admin`

### ✅ Готово! Три сервіси задеплоєні!

---

## 5️⃣ Деплой на Vercel + Railway

Комбінація: Frontend на Vercel, Backend на Railway.

### Крок 1: Backend на Railway
Виконайте кроки з розділу 3 (Railway)

### Крок 2: Frontend на Vercel
1. Відкрийте https://vercel.com
2. Натисніть **Add New** → **Project**
3. Імпортуйте `survus-crm` з GitHub
4. Налаштування:
   - **Framework Preset**: Vite
   - **Root Directory**: `frontend`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
5. Додайте змінну:
   ```
   VITE_API_URL=https://your-railway-backend.up.railway.app/api
   ```
6. Натисніть **Deploy**

### ✅ Frontend на Vercel, Backend на Railway!

---

## 6️⃣ Налаштування після деплою

### Перевірте роботу:
1. Відкрийте ваш URL
2. Натисніть **Почати безкоштовно**
3. Введіть токен або email/пароль
4. Перевірте всі сторінки

### Створіть перший workspace (через admin):
```bash
# Відкрийте admin панель
https://your-domain.com/admin

# Логін:
# Username: admin
# Password: admin123

# Створіть workspace та скопіюйте токен
```

### Налаштуйте домен (опціонально):
1. Купіть домен (наприклад, на Namecheap)
2. В Railway/Render/Vercel додайте Custom Domain
3. Налаштуйте DNS записи:
   ```
   Type: CNAME
   Name: @
   Value: your-app.railway.app
   ```

---

## 🔧 Troubleshooting

### Проблема: "Cannot connect to backend"
**Рішення**: Перевірте CORS налаштування в `backend/src/app.js`
```javascript
app.use(cors({
  origin: ['https://your-frontend-domain.com'],
  credentials: true
}))
```

### Проблема: "Database not found"
**Рішення**: Переконайтеся, що міграції виконані:
```bash
npm run migrate
```

### Проблема: "Build failed"
**Рішення**: Перевірте Node.js версію:
```json
// package.json
"engines": {
  "node": ">=18.0.0"
}
```

---

## 📞 Підтримка

Якщо виникли проблеми:
1. Перевірте логи в Railway/Render/Vercel
2. Перевірте змінні середовища
3. Перевірте, чи всі файли закомічені в Git

---

## 🎉 Вітаємо!

Ваш SURVUS CRM тепер доступний онлайн! 🚀

**Наступні кроки:**
- Налаштуйте SSL сертифікат (автоматично на Railway/Vercel)
- Додайте custom домен
- Налаштуйте backup бази даних
- Додайте моніторинг (UptimeRobot)

---

**Створено для SURVUS CRM Platform**
