# Подключение к GitHub

## 1. Создайте репозиторий на GitHub

1. Перейдите на https://github.com/new
2. Название: `survus-crm`
3. Описание: `Premium CRM Platform with Dark Green Theme`
4. Выберите: Private или Public
5. НЕ добавляйте README, .gitignore, license (они уже есть)
6. Нажмите "Create repository"

## 2. Подключите локальный репозиторий

```bash
# Добавьте remote (замените YOUR_USERNAME на ваш GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/survus-crm.git

# Проверьте remote
git remote -v

# Отправьте код на GitHub
git push -u origin main
```

## 3. Если используете SSH

```bash
# Добавьте remote через SSH
git remote add origin git@github.com:YOUR_USERNAME/survus-crm.git

# Отправьте код
git push -u origin main
```

## 4. Если remote уже существует

```bash
# Удалите старый remote
git remote remove origin

# Добавьте новый
git remote add origin https://github.com/YOUR_USERNAME/survus-crm.git

# Отправьте код
git push -u origin main
```

## 5. Дальнейшая работа

```bash
# Проверить статус
git status

# Добавить изменения
git add .

# Создать коммит
git commit -m "feat: описание изменений"

# Отправить на GitHub
git push
```

## Типы коммитов

- `feat:` - новая функция
- `fix:` - исправление бага
- `docs:` - изменения в документации
- `style:` - форматирование кода
- `refactor:` - рефакторинг
- `test:` - добавление тестов
- `chore:` - обновление зависимостей

## Текущее состояние

✅ Git инициализирован
✅ Все файлы добавлены
✅ Создан коммит с изменениями
⏳ Ожидает подключения к GitHub remote

## Коммиты

```
0d5c094 docs: Update README with dark green theme info
80760c6 feat: Dark green theme with Silkscreen font, Contacts & Appointments pages, fixed subscription display
7091feb Initial commit: SURVUS CRM Platform
```
