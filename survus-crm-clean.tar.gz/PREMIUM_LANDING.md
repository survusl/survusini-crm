# 💎 SURVUS Premium Landing Page

## ✨ Що створено

Преміальна, технологічна landing page для SURVUS CRM з акцентом на бізнес-платформу, а не на чат/месенджер.

## 🎨 Дизайн

### Візуальний стиль
- **Темна база**: #0a0b0d (глибокий чорний)
- **Поверхні**: Багатошарові з glassmorphism
- **Градієнти**: Синій → Фіолетовий, Зелений → Синій
- **Свічення**: М'які glow-ефекти навколо елементів
- **Глибина**: Багаторівневі тіні та blur

### Типографіка
- **Заголовки**: 88px, 900 weight, -0.04em letter-spacing
- **Підзаголовки**: 20px, 1.7 line-height
- **Тексти**: Inter font family
- **Акценти**: Gradient text для важливих слів

## 🏗️ Структура

### Hero Section
**Елементи:**
- Анімовані gradient spheres (3 шт)
- Grid overlay для глибини
- Pulse badge "Нове покоління CRM"
- Потужний заголовок з gradient текстом
- 2 CTA кнопки (primary + secondary)
- Premium dashboard preview

**Dashboard Preview містить:**
- Tabs навігація (Dashboard, Аналітика, Клієнти)
- 3 метрики картки:
  - Виручка з анімованим графіком
  - Активні угоди з progress bar
  - Конверсія з ring chart
- Таблиця останніх угод з:
  - Аватари клієнтів
  - Суми угод
  - Статуси (Виграно/В роботі)
  - Progress bars

### Features Section
- 6 карток можливостей:
  - Управління клієнтами
  - Воронка продажів
  - Контроль доходів
  - Розумна аналітика
  - Автоматизація
  - Швидкість роботи

## 🎬 Анімації

### Parallax Effects
```javascript
Hero content: translateY(scrollY * 0.1)
Dashboard: translateY(scrollY * 0.05) + rotateX
```

### Scroll Animations
- Intersection Observer для секцій
- Fade up + translateY(50px → 0)
- Staggered delays для карток

### Hover Effects
**Metric Cards:**
- translateY(-4px)
- Border glow
- Radial gradient overlay

**Feature Cards:**
- translateY(-6px)
- Icon scale(1.1) + rotate(5deg)
- Shadow increase

**Table Rows:**
- translateX(4px)
- Background change
- Border glow

### Micro Animations
- Badge pulse (2s infinite)
- Sphere float (25s infinite)
- Bar grow (0.8s cubic-bezier)
- Progress grow (1s cubic-bezier)

## 🎯 Ключові особливості

### 1. Не чат, а CRM
- Dashboard з метриками
- Таблиця угод
- Графіки аналітики
- Business-focused UI

### 2. Преміальність
- Глибокі тіні
- Glassmorphism
- Gradient overlays
- Smooth animations

### 3. Технологічність
- Grid overlay
- Floating spheres
- Glow effects
- Modern typography

### 4. Професійність
- Чіткі метрики
- Реальні дані
- Business terminology
- Serious tone

## 🎨 Кольорова палітра

```css
Background: #0a0b0d
Surface: #13151a
Elevated: #1a1d24
Border: rgba(255, 255, 255, 0.06)

Primary: #3b82f6 (Blue)
Success: #10b981 (Green)
Warning: #f59e0b (Orange)

Text 1: #f8fafc (White)
Text 2: #cbd5e1 (Light gray)
Text 3: #94a3b8 (Gray)
Text 4: #64748b (Dark gray)
```

## 📐 Spacing System

```css
Padding sections: 140px vertical
Card padding: 36px
Gap between cards: 28px
Border radius: 20px (large), 12px (medium)
```

## 🎭 Timing Functions

```css
Main easing: cubic-bezier(0.16, 1, 0.3, 1)
Duration: 0.3s (fast), 0.8s (normal)
```

## 📱 Responsive

### Desktop (1400px+)
- 3 columns metrics
- Full dashboard preview
- Large typography

### Tablet (768px-1024px)
- 2 columns metrics
- Adjusted dashboard
- Medium typography

### Mobile (<768px)
- 1 column layout
- Stacked buttons
- Smaller dashboard
- Compact spacing

## 🚀 Performance

- CSS transforms (GPU accelerated)
- Intersection Observer (lazy loading)
- Optimized animations
- Minimal repaints

## 💡 Використання

```bash
# Відкрити landing page
http://localhost:5173/

# Після входу перенаправить на
http://localhost:5173/dashboard
```

## 🎨 Customization

Змінити кольори в CSS:
```css
:root {
  --premium-primary: #3b82f6;  /* Основний колір */
  --premium-success: #10b981;  /* Успіх */
}
```

## 📊 Metrics Shown

- Виручка: $127,450 (+24%)
- Активні угоди: 847 (+12)
- Конверсія: 92.4% (+8%)

## 🎯 CTA Strategy

1. Primary: "Почати безкоштовно" (gradient button)
2. Secondary: "Дивитись можливості" (ghost button)

## 🔥 Highlights

- ✅ Не схожий на Discord/чат
- ✅ Фокус на CRM/бізнес
- ✅ Преміальний вигляд
- ✅ Плавні анімації
- ✅ Професійні метрики
- ✅ Технологічний дизайн
- ✅ Glassmorphism
- ✅ Gradient effects
- ✅ Responsive design
- ✅ Performance optimized
