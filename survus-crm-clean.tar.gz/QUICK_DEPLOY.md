# ⚡ ШВИДКИЙ ДЕПЛОЙ - 5 хвилин

## 🎯 Найпростіший спосіб (Railway)

### 1️⃣ Запустіть скрипт деплою

**macOS/Linux:**
```bash
./deploy.sh
```

**Windows:**
```bash
deploy.bat
```

### 2️⃣ Створіть GitHub репозиторій

1. Відкрийте https://github.com/new
2. Назва: `survus-crm`
3. Private або Public
4. **НЕ** додавайте README
5. Створіть репозиторій
6. Скопіюйте URL (наприклад: `https://github.com/username/survus-crm.git`)
7. Вставте URL в скрипт

### 3️⃣ Деплой на Railway

1. Відкрийте https://railway.app
2. Натисніть **Login with GitHub**
3. Натисніть **New Project**
4. Виберіть **Deploy from GitHub repo**
5. Виберіть `survus-crm`
6. Чекайте 2-3 хвилини

### 4️⃣ Отримайте URL

1. Відкрийте проєкт в Railway
2. Виберіть сервіс **frontend**
3. Перейдіть в **Settings** → **Networking**
4. Натисніть **Generate Domain**
5. Скопіюйте URL

### ✅ ГОТОВО!

Ваш CRM доступний за адресою: `https://your-app.up.railway.app`

---

## 🔧 Якщо щось не працює

### Проблема: Локальний сервер не запускається

**Рішення 1: Перезапустіть все**
```bash
# Зупиніть всі процеси (Ctrl+C)

# Видаліть node_modules
rm -rf node_modules backend/node_modules frontend/node_modules admin/node_modules

# Встановіть заново
npm install
cd backend && npm install && cd ..
cd frontend && npm install && cd ..
cd admin && npm install && cd ..

# Запустіть
npm start
```

**Рішення 2: Перевірте порти**
```bash
# Перевірте, чи порти вільні
lsof -i :3001  # Backend
lsof -i :5173  # Frontend
lsof -i :5174  # Admin

# Якщо зайняті, вбийте процеси
kill -9 <PID>
```

**Рішення 3: Очистіть кеш**
```bash
# Видаліть кеш
rm -rf backend/data/*.db-shm backend/data/*.db-wal

# Перезапустіть міграції
cd backend
npm run migrate
cd ..
```

### Проблема: Git не працює

**Встановіть Git:**
- macOS: `brew install git`
- Windows: https://git-scm.com/download/win
- Linux: `sudo apt install git`

### Проблема: Railway не деплоїть

**Перевірте:**
1. Чи є файл `railway.json` в корені проєкту?
2. Чи всі файли закомічені в Git?
3. Чи правильно налаштовані змінні середовища?

---

## 📞 Потрібна допомога?

1. Перевірте логи в Railway Dashboard
2. Відкрийте `DEPLOYMENT_GUIDE.md` для детальної інструкції
3. Перевірте, чи всі залежності встановлені

---

## 🎉 Успіхів!

Ваш SURVUS CRM буде онлайн за 5 хвилин! 🚀
