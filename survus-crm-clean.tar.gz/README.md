# SURVUS CRM Platform

🌿 Професійна CRM система з темно-зеленим дизайном

## 🚀 Швидкий старт (1 команда!)

### macOS / Linux
```bash
./start-all.sh
```

### Windows
```bash
start-all.bat
```

Це автоматично:
- ✅ Встановить всі залежності
- ✅ Запустить міграції бази даних
- ✅ Запустить Backend (порт 3001)
- ✅ Запустить Frontend (порт 5173)
- ✅ Запустить Admin Panel (порт 5174)

### Відкрийте в браузері:
- **CRM**: http://localhost:5173
- **Admin**: http://localhost:5174

## 📝 Перший вхід

1. Відкрийте http://localhost:5173
2. Натисніть **"Почати безкоштовно"**
3. Виберіть спосіб входу:
   - **По токену**: Створіть воркспейс в Admin Panel
   - **По email**: Якщо вас додали до команди

## 🎨 Особливості

- ✨ Темно-зелена тема по всьому інтерфейсу
- 🎯 Професійні SVG іконки (без емодзі)
- 🔤 Silkscreen шрифт для акцентів
- 📊 Інтерактивні графіки та анімації
- 👥 Управління командою (PRO+)
- 🔐 Email/Password автентифікація

## 📦 Структура

```
survus/
├── backend/    # Node.js + Express + SQLite
├── frontend/   # React + Vite (CRM)
├── admin/      # React + Vite (Admin Panel)
└── start-all.* # Скрипти запуску
```

## 🛠️ Ручний запуск (якщо потрібно)

```bash
# 1. Встановити залежності
npm run install:all

# 2. Запустити міграції
npm run migrate

# 3. Запустити все разом
npm run dev
```

## 📚 Документація

- [SETUP.md](./SETUP.md) - Детальна інструкція
- [CHANGELOG.md](./CHANGELOG.md) - Список змін
- [PREMIUM_FEATURES.md](./PREMIUM_FEATURES.md) - PRO функції

## 🐛 Проблеми?

### Backend не запускається
```bash
# Перевірте чи вільний порт 3001
lsof -i :3001  # macOS/Linux
netstat -ano | findstr :3001  # Windows
```

### Frontend не підключається
Перевірте що Backend запущений на http://localhost:3001

### База даних
```bash
cd backend
rm data/survus.db
node src/migrate.js
```

## 💡 Корисні команди

```bash
npm run dev          # Запустити все
npm run dev:backend  # Тільки backend
npm run dev:frontend # Тільки frontend
npm run dev:admin    # Тільки admin
npm run migrate      # Міграції БД
npm run seed         # Тестові дані
```

---

**Версія**: 2.0.0  
**Ліцензія**: Proprietary  
🌿 **SURVUS CRM** - Контроль бізнесу в одному інтерфейсі
