# 🔐 БЕЗПЕЧНИЙ АВТОМАТИЧНИЙ ДЕПЛОЙ

## ✅ Я СТВОРИВ БЕЗПЕЧНИЙ СКРИПТ!

Замість того, щоб давати мені свої дані, використайте цей скрипт - він запитає ваші дані **безпечно** в терміналі, і я їх **НЕ побачу**!

---

## 🚀 ЯК ВИКОРИСТОВУВАТИ:

### macOS / Linux:
```bash
./auto-deploy.sh
```

### Windows:
```bash
auto-deploy.bat
```

---

## 📋 ЩО ЗРОБИТЬ СКРИПТ:

1. ✅ Запитає ваш GitHub username
2. ✅ Запитає назву репозиторію (за замовчуванням: survus-crm)
3. ✅ Запитає Personal Access Token (безпечно!)
4. ✅ Підключить remote до GitHub
5. ✅ Відправить код на GitHub
6. ✅ Видалить токен з історії (для безпеки)

---

## 🔑 ЯК СТВОРИТИ PERSONAL ACCESS TOKEN:

**Personal Access Token** - це безпечніший спосіб автентифікації, ніж пароль!

### Крок 1: Відкрийте GitHub Settings
```
https://github.com/settings/tokens
```

### Крок 2: Створіть новий токен
1. Натисніть **"Generate new token"** → **"Generate new token (classic)"**
2. **Note:** `SURVUS CRM Deploy`
3. **Expiration:** `90 days` (або більше)
4. **Select scopes:** Поставте галочку на **`repo`** (full control of private repositories)
5. Натисніть **"Generate token"**

### Крок 3: Скопіюйте токен
⚠️ **ВАЖЛИВО:** Токен показується тільки раз! Скопіюйте його зараз!

Приклад токену:
```
ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## 🎯 ПОВНА ІНСТРУКЦІЯ:

### 1. Створіть репозиторій на GitHub (СПОЧАТКУ!)

1. Відкрийте https://github.com/new
2. **Repository name:** `survus-crm`
3. Виберіть **Private** або **Public**
4. **НЕ** ставте галочки на README, .gitignore, license
5. Натисніть **"Create repository"**

### 2. Створіть Personal Access Token

Слідуйте інструкціям вище ☝️

### 3. Запустіть скрипт

**macOS/Linux:**
```bash
./auto-deploy.sh
```

**Windows:**
```bash
auto-deploy.bat
```

### 4. Введіть дані коли попросить:

```
GitHub Username: ваш_username
Назва репозиторію: survus-crm (або Enter)
Personal Access Token: вставте_токен
```

### 5. Готово! 🎉

Скрипт автоматично відправить код на GitHub!

---

## 🚀 ПІСЛЯ ДЕПЛОЮ НА GITHUB:

### Деплой на Railway:

1. Відкрийте https://railway.app
2. Натисніть **"Login with GitHub"**
3. Натисніть **"New Project"**
4. Виберіть **"Deploy from GitHub repo"**
5. Виберіть репозиторій `survus-crm`
6. Чекайте 2-3 хвилини
7. Settings → Networking → Generate Domain
8. Скопіюйте URL!

---

## 🔒 БЕЗПЕКА:

### Чому це безпечно:

✅ **Ваші дані вводяться локально** - я їх не бачу  
✅ **Токен видаляється з історії** - не залишається слідів  
✅ **Токен можна відкликати** - в будь-який момент на GitHub  
✅ **Токен має обмежені права** - тільки repo  
✅ **Токен має термін дії** - автоматично закінчується  

### Як відкликати токен після деплою:

1. Відкрийте https://github.com/settings/tokens
2. Знайдіть токен `SURVUS CRM Deploy`
3. Натисніть **"Delete"**
4. Токен більше не працює!

---

## 🐛 TROUBLESHOOTING:

### Помилка: "Repository not found"

**Причина:** Репозиторій ще не створений на GitHub

**Рішення:**
1. Створіть репозиторій на https://github.com/new
2. Запустіть скрипт знову

### Помилка: "Authentication failed"

**Причина:** Неправильний токен або username

**Рішення:**
1. Перевірте username (без @)
2. Створіть новий токен
3. Переконайтеся, що вибрали `repo` scope

### Помилка: "Permission denied"

**Причина:** Токен не має прав на repo

**Рішення:**
1. Створіть новий токен
2. Обов'язково виберіть `repo` scope

---

## 💡 АЛЬТЕРНАТИВА (якщо скрипт не працює):

### Ручний спосіб (2 команди):

```bash
# 1. Додати remote (замініть YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/survus-crm.git

# 2. Push (введіть username та токен коли попросить)
git push -u origin main
```

---

## ✨ ПЕРЕВАГИ АВТОМАТИЧНОГО СКРИПТУ:

- ⚡ Швидше - все автоматично
- 🔒 Безпечніше - токен не залишається в історії
- 🎯 Простіше - не потрібно пам'ятати команди
- ✅ Надійніше - перевіряє помилки

---

## 🎉 ГОТОВО!

Після виконання скрипту ваш код буде на GitHub, і ви зможете задеплоїти на Railway!

**Час виконання:** 2 хвилини  
**Безпека:** Максимальна  
**Складність:** Дуже легко

---

**SURVUS CRM** - Безпечний деплой! 🌿
