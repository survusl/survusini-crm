# SURVUS CRM - Інструкція по запуску

## 🚀 Швидкий старт

### Вимоги
- Node.js 18+ та npm
- Git

### 1. Встановлення залежностей

```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install

# Admin
cd ../admin
npm install
```

### 2. Налаштування бази даних

```bash
cd backend
node src/migrate.js
```

### 3. Запуск проекту

#### Варіант 1: Окремі термінали

```bash
# Термінал 1 - Backend (порт 3001)
cd backend
npm start

# Термінал 2 - Frontend (порт 5173)
cd frontend
npm run dev

# Термінал 3 - Admin (порт 5174)
cd admin
npm run dev
```

#### Варіант 2: Один скрипт (потрібен tmux або screen)

```bash
./start-dev.sh
```

### 4. Відкрийте в браузері

- **Frontend (CRM)**: http://localhost:5173
- **Admin Panel**: http://localhost:5174
- **Backend API**: http://localhost:3001

## 📦 Структура проекту

```
survus/
├── backend/          # Node.js + Express + SQLite
│   ├── src/
│   │   ├── routes/   # API endpoints
│   │   ├── services/ # Business logic
│   │   └── migrations/ # Database migrations
│   └── data/         # SQLite database
├── frontend/         # React + Vite (CRM Interface)
│   └── src/
│       ├── pages/    # Page components
│       ├── components/ # Reusable components
│       └── api/      # API client
└── admin/            # React + Vite (Admin Panel)
    └── src/
        └── pages/    # Admin pages
```

## 🎨 Дизайн система

### Кольори (Dark Green Theme)
- **Primary**: `#3dd68c` (Green Glow)
- **Background**: `#0a0f0d` (Dark Green)
- **Surface**: `#1a221e`
- **Text**: `#f0fdf4`

### Шрифти
- **Основний**: Inter
- **Акценти**: Silkscreen (pixel font)

## 🔑 Перший вхід

### Створення воркспейсу (через Admin Panel)

1. Відкрийте http://localhost:5174
2. Введіть admin пароль (за замовчуванням: `admin123`)
3. Створіть новий воркспейс
4. Скопіюйте згенерований токен

### Вхід в CRM

1. Відкрийте http://localhost:5173
2. Натисніть "Почати безкоштовно"
3. Вставте токен або використайте email/пароль (якщо створили користувача)

## 🛠️ Розробка

### Backend API

```bash
cd backend
npm run dev  # Запуск з nodemon (auto-reload)
```

### Frontend

```bash
cd frontend
npm run dev  # Vite dev server з HMR
```

### Міграції бази даних

```bash
cd backend
node src/migrate.js
```

### Seed даних (тестові дані)

```bash
cd backend
node src/seed.js
```

## 📝 API Endpoints

### Authentication
- `POST /api/auth/validate` - Валідація токену
- `POST /api/auth/login` - Вхід по email/password

### Leads
- `GET /api/leads` - Список лідів
- `POST /api/leads` - Створити ліда
- `GET /api/leads/:id` - Деталі ліда
- `PATCH /api/leads/:id` - Оновити ліда

### Tasks
- `GET /api/tasks` - Список завдань
- `POST /api/tasks` - Створити завдання
- `PATCH /api/tasks/:id/complete` - Виконати завдання

### Dashboard
- `GET /api/dashboard/stats` - Статистика

### Team (PRO+ only)
- `GET /api/team` - Список команди
- `POST /api/team` - Додати учасника
- `PATCH /api/team/:id` - Оновити права
- `DELETE /api/team/:id` - Видалити учасника

## 🐛 Troubleshooting

### Backend не запускається
```bash
# Перевірте порт 3001
lsof -i :3001
# Якщо зайнятий, змініть PORT в backend/.env
```

### Frontend не підключається до API
```bash
# Перевірте VITE_API_URL в frontend/.env
# За замовчуванням: http://localhost:3001
```

### База даних пошкоджена
```bash
cd backend
rm data/survus.db
node src/migrate.js
node src/seed.js
```

## 📚 Додаткова інформація

- [PREMIUM_FEATURES.md](./PREMIUM_FEATURES.md) - Опис PRO/PRO+ функцій
- [ANIMATIONS.md](./ANIMATIONS.md) - Документація анімацій
- [GIT_SETUP.md](./GIT_SETUP.md) - Налаштування Git

## 🎯 Наступні кроки

1. Налаштуйте .env файли для production
2. Додайте SSL сертифікати
3. Налаштуйте CI/CD pipeline
4. Додайте моніторинг та логування

---

**SURVUS CRM** - Професійна CRM система з темно-зеленим дизайном 🌿
