# 🚀 ПОЧНІТЬ ТУТ - ДЕПЛОЙ НА СЕРВЕР

## ⚡ 3 ПРОСТИХ КРОКИ

### 📋 ЩО ВАМ ПОТРІБНО:
- ✅ Акаунт GitHub (безкоштовно)
- ✅ Акаунт Railway (безкоштовно)
- ✅ 5 хвилин часу

---

## КРОК 1: Відправте код на GitHub

### macOS/Linux:
```bash
./deploy.sh
```

### Windows:
```bash
deploy.bat
```

**Що робить скрипт:**
1. Ініціалізує Git (якщо потрібно)
2. Додає всі файли
3. Створює коміт
4. Відправляє на GitHub

**Якщо GitHub репозиторій ще не створений:**
1. Відкрийте https://github.com/new
2. Назва: `survus-crm`
3. Виберіть Private
4. **НЕ** додавайте README
5. Натисніть "Create repository"
6. Скопіюйте URL (наприклад: `https://github.com/username/survus-crm.git`)
7. Вставте в скрипт коли попросить

---

## КРОК 2: Деплой на Railway

### 1. Створіть акаунт:
- Відкрийте https://railway.app
- Натисніть **"Login with GitHub"**
- Авторизуйтесь

### 2. Створіть проєкт:
- Натисніть **"New Project"**
- Виберіть **"Deploy from GitHub repo"**
- Виберіть репозиторій `survus-crm`
- Railway автоматично виявить налаштування!

### 3. Чекайте 2-3 хвилини
Railway автоматично:
- ✅ Встановить залежності
- ✅ Запустить міграції
- ✅ Задеплоїть Backend, Frontend, Admin

---

## КРОК 3: Отримайте URL

### 1. Відкрийте проєкт в Railway
### 2. Виберіть сервіс **"frontend"**
### 3. Перейдіть в **Settings** → **Networking**
### 4. Натисніть **"Generate Domain"**
### 5. Скопіюйте URL

**Приклад:** `https://survus-crm.up.railway.app`

---

## ✅ ГОТОВО!

Ваш SURVUS CRM тепер доступний онлайн! 🎉

### Перший вхід:
1. Відкрийте ваш URL
2. Натисніть **"Почати безкоштовно"**
3. Створіть workspace через Admin Panel:
   - URL: `https://your-url.up.railway.app/admin`
   - Login: `admin`
   - Password: `admin123`

---

## 🔧 ЯКЩО ЩОСь НЕ ПРАЦЮЄ

### Проблема: "Cannot connect to backend"

**Рішення:**
1. Відкрийте Railway Dashboard
2. Перевірте, чи всі 3 сервіси запущені (backend, frontend, admin)
3. Перевірте логи backend сервісу

### Проблема: "Build failed"

**Рішення:**
1. Перевірте, чи всі файли закомічені в Git:
   ```bash
   git status
   git add .
   git commit -m "Fix"
   git push
   ```
2. Railway автоматично перезапустить деплой

### Проблема: Локальний сервер не запускається

**Рішення:**
```bash
# Видаліть node_modules
rm -rf node_modules backend/node_modules frontend/node_modules admin/node_modules

# Встановіть заново
npm install

# Запустіть
npm start
```

---

## 📖 ДОДАТКОВІ РЕСУРСИ

- **Швидкий деплой:** [QUICK_DEPLOY.md](QUICK_DEPLOY.md)
- **Повна інструкція:** [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
- **Локальне налаштування:** [README.md](README.md)

---

## 💡 ПОРАДИ

### Безкоштовний план Railway:
- ✅ 500 годин на місяць
- ✅ Автоматичний SSL
- ✅ Автоматичні деплої з GitHub
- ✅ Достатньо для тестування та малих проєктів

### Налаштуйте custom домен:
1. Купіть домен (Namecheap, GoDaddy)
2. В Railway: Settings → Networking → Custom Domain
3. Додайте CNAME запис в DNS

### Автоматичні деплої:
Railway автоматично деплоїть при кожному push в GitHub!

```bash
# Зробіть зміни
git add .
git commit -m "Update"
git push

# Railway автоматично задеплоїть!
```

---

## 🎉 ВІТАЄМО!

Ваш SURVUS CRM тепер працює 24/7 онлайн! 🚀

**Наступні кроки:**
- 📊 Створіть перший workspace
- 👥 Додайте команду
- 📈 Почніть працювати з лідами
- 🎨 Налаштуйте кольори в Settings

---

**Потрібна допомога?** Перевірте [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

**SURVUS CRM** - Ваш бізнес під контролем! 🌿
