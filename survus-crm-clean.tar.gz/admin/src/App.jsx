import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import AdminLogin from './pages/AdminLogin'
import WorkspaceList from './pages/WorkspaceList'
import WorkspaceForm from './pages/WorkspaceForm'
import WorkspaceDetail from './pages/WorkspaceDetail'

function isAuthed() {
  return !!sessionStorage.getItem('survus_admin_password')
}

function RequireAuth({ children }) {
  return isAuthed() ? children : <Navigate to="/" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AdminLogin />} />
        <Route path="/workspaces" element={<RequireAuth><WorkspaceList /></RequireAuth>} />
        <Route path="/workspaces/new" element={<RequireAuth><WorkspaceForm /></RequireAuth>} />
        <Route path="/workspaces/:id" element={<RequireAuth><WorkspaceDetail /></RequireAuth>} />
      </Routes>
    </BrowserRouter>
  )
}
