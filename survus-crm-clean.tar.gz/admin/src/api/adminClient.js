import axios from 'axios'

const adminClient = axios.create({ baseURL: '/api/admin' })

adminClient.interceptors.request.use(config => {
  const password = sessionStorage.getItem('survus_admin_password')
  if (password) config.headers['X-Admin-Password'] = password
  return config
})

export default adminClient
