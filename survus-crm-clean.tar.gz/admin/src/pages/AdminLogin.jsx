import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import adminClient from '../api/adminClient'

export default function AdminLogin() {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setError(''); setLoading(true)
    try {
      sessionStorage.setItem('survus_admin_password', password)
      await adminClient.get('/stats')
      navigate('/workspaces')
    } catch {
      sessionStorage.removeItem('survus_admin_password')
      setError('Невірний пароль. Спробуйте ще раз.')
    } finally { setLoading(false) }
  }

  return (
    <div style={S.bg}>
      <div style={S.bgBlob1} />
      <div style={S.bgBlob2} />
      <div style={S.card}>
        <div style={S.logoRow}>
          <div style={S.logoIcon}>
            <svg width="24" height="24" viewBox="0 0 28 28" fill="none">
              <rect width="28" height="28" rx="7" fill="#22c55e"/>
              <path d="M8 14l4 4 8-8" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span style={S.logoText}>SURVUS</span>
        </div>
        <h1 style={S.title}>Адмін-панель</h1>
        <p style={S.sub}>Введіть пароль для доступу</p>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <div style={{ position: 'relative' }}>
            <svg style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8', pointerEvents: 'none' }} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            <input type="password" placeholder="Пароль адміністратора" value={password} onChange={e => setPassword(e.target.value)} required autoFocus className="input-base" style={{ paddingLeft: '42px' }} />
          </div>
          {error && <div style={{ padding: '10px 14px', background: '#fef2f2', borderRadius: '8px', color: '#dc2626', fontSize: '13px', display: 'flex', gap: '6px' }}>⚠ {error}</div>}
          <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '12px', fontSize: '15px' }}>
            {loading ? <><span style={{ width: '16px', height: '16px', border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block' }} /> Вхід...</> : 'Увійти'}
          </button>
        </form>
        <p style={{ fontSize: '12px', color: '#94a3b8', textAlign: 'center', marginTop: '20px' }}>SURVUS CRM · Захищений доступ</p>
      </div>
    </div>
  )
}

const S = {
  bg: { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #f0fdf4 0%, #e8f5e9 50%, #f1f5f9 100%)', position: 'relative', overflow: 'hidden' },
  bgBlob1: { position: 'absolute', top: '-100px', right: '-100px', width: '350px', height: '350px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(34,197,94,0.12) 0%, transparent 70%)', pointerEvents: 'none' },
  bgBlob2: { position: 'absolute', bottom: '-80px', left: '-80px', width: '280px', height: '280px', borderRadius: '50%', background: 'radial-gradient(circle, rgba(34,197,94,0.08) 0%, transparent 70%)', pointerEvents: 'none' },
  card: { background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(20px)', borderRadius: '20px', boxShadow: '0 20px 60px rgba(0,0,0,0.10)', padding: '44px 40px', width: '100%', maxWidth: '400px', position: 'relative', zIndex: 1 },
  logoRow: { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', justifyContent: 'center' },
  logoIcon: { display: 'flex' },
  logoText: { fontSize: '22px', fontWeight: '800', color: '#0f172a', letterSpacing: '2px' },
  title: { fontSize: '20px', fontWeight: '700', color: '#0f172a', textAlign: 'center', marginBottom: '6px' },
  sub: { fontSize: '14px', color: '#64748b', textAlign: 'center', marginBottom: '28px' },
}
