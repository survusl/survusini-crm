import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import adminClient from '../api/adminClient'
import Icon from '../components/Icons'

const STATUS_BADGE = { active: 'badge-active', suspended: 'badge-suspended', expired: 'badge-expired' }
const STATUS_LABEL = { active: 'Активний', suspended: 'Призупинено', expired: 'Прострочено' }

function Section({ title, icon, children, action }) {
  return (
    <div className="card" style={{ marginBottom: '14px' }}>
      <div className="card-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {icon && <Icon name={icon} size={15} color="var(--text-3)" />}
          <span className="card-title">{title}</span>
        </div>
        {action}
      </div>
      <div style={{ padding: '18px 20px' }}>{children}</div>
    </div>
  )
}

export default function WorkspaceDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [ws, setWs] = useState(null)
  const [loading, setLoading] = useState(true)
  const [showToken, setShowToken] = useState(false)
  const [tokenCopied, setTokenCopied] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState('')
  const [tabs, setTabs] = useState([])
  const [primaryColor, setPrimaryColor] = useState('#16a34a')
  const [extendDays, setExtendDays] = useState(30)
  const [wsLeads, setWsLeads] = useState(null)

  async function load() {
    setLoading(true)
    try {
      const res = await adminClient.get(`/workspaces/${id}`)
      const data = res.data
      setWs(data)
      const config = typeof data.crm_config === 'string' ? JSON.parse(data.crm_config) : data.crm_config
      if (config?.tabs) setTabs(config.tabs)
      if (config?.primary_color) setPrimaryColor(config.primary_color)
      setWsLeads(data.leads_count ?? null)
    } catch { navigate('/workspaces') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [id])

  async function toggleStatus() {
    const newStatus = ws.subscription_status === 'active' ? 'suspended' : 'active'
    await adminClient.patch(`/workspaces/${id}`, { subscription_status: newStatus })
    load()
  }

  async function extend() {
    const base = ws.subscription_until ? new Date(ws.subscription_until) : new Date()
    base.setDate(base.getDate() + extendDays)
    await adminClient.patch(`/workspaces/${id}`, { subscription_until: base.toISOString(), subscription_status: 'active' })
    load()
  }

  async function saveConfig() {
    setSaving(true); setSaveMsg('')
    try {
      const currentConfig = typeof ws.crm_config === 'string' ? JSON.parse(ws.crm_config) : ws.crm_config
      await adminClient.patch(`/workspaces/${id}`, { crm_config: { ...currentConfig, tabs, primary_color: primaryColor } })
      setSaveMsg('Збережено')
      load()
    } catch { setSaveMsg('Помилка') }
    finally { setSaving(false); setTimeout(() => setSaveMsg(''), 2500) }
  }

  async function deleteWorkspace() {
    if (!confirm(`Видалити воркспейс "${ws.company_name}"? Всі дані будуть втрачені назавжди.`)) return
    await adminClient.delete(`/workspaces/${id}`)
    navigate('/workspaces')
  }

  function copyToken() {
    navigator.clipboard.writeText(ws.access_token)
    setTokenCopied(true)
    setTimeout(() => setTokenCopied(false), 2000)
  }

  if (loading) return <div className="loading-center"><div className="spinner" /></div>
  if (!ws) return null

  const daysLeft = ws.subscription_until
    ? Math.ceil((new Date(ws.subscription_until) - new Date()) / (1000 * 60 * 60 * 24))
    : null

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      {/* Topbar */}
      <div style={{ height: '56px', background: '#fff', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', padding: '0 28px', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button onClick={() => navigate('/workspaces')} className="btn btn-ghost btn-sm">
            <Icon name="arrow_left" size={13} /> Назад
          </button>
          <span style={{ color: 'var(--border)' }}>|</span>
          <span style={{ fontSize: '13.5px', fontWeight: '600', color: 'var(--text)' }}>{ws.company_name}</span>
          <span className={`badge ${STATUS_BADGE[ws.subscription_status] || 'badge-neutral'}`}>{STATUS_LABEL[ws.subscription_status] || ws.subscription_status}</span>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={toggleStatus} className="btn btn-sm" style={{ background: ws.subscription_status === 'active' ? '#fefce8' : '#f0fdf4', color: ws.subscription_status === 'active' ? '#a16207' : '#15803d', border: 'none' }}>
            <Icon name={ws.subscription_status === 'active' ? 'pause' : 'play'} size={12} />
            {ws.subscription_status === 'active' ? 'Призупинити' : 'Активувати'}
          </button>
        </div>
      </div>

      <div style={{ padding: '24px 28px', maxWidth: '800px' }} className="fade-up">
        {/* Info */}
        <Section title="Інформація" icon="building">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0' }}>
            <div>
              <div className="info-row"><span className="info-label">Компанія</span><span className="info-value">{ws.company_name}</span></div>
              <div className="info-row"><span className="info-label">Шаблон</span><span className="info-value"><span style={{ background: 'var(--surface-2)', border: '1px solid var(--border)', padding: '2px 8px', borderRadius: '4px', fontSize: '12px' }}>{ws.template_id || '—'}</span></span></div>
              <div className="info-row"><span className="info-label">Ліди</span><span className="info-value" style={{ fontWeight: '700', fontSize: '16px' }}>{wsLeads ?? '—'}</span></div>
            </div>
            <div>
              <div className="info-row"><span className="info-label">Статус</span><span className="info-value"><span className={`badge ${STATUS_BADGE[ws.subscription_status] || 'badge-neutral'}`}>{STATUS_LABEL[ws.subscription_status] || ws.subscription_status}</span></span></div>
              <div className="info-row">
                <span className="info-label">Підписка до</span>
                <span className="info-value">
                  <div>{ws.subscription_until ? new Date(ws.subscription_until).toLocaleDateString('uk-UA', { day: '2-digit', month: 'long', year: 'numeric' }) : '—'}</div>
                  {daysLeft !== null && (
                    <div style={{ fontSize: '11.5px', color: daysLeft <= 0 ? '#dc2626' : daysLeft <= 7 ? '#b45309' : '#15803d', fontWeight: '600', marginTop: '2px' }}>
                      {daysLeft <= 0 ? 'Прострочено' : `Залишилось ${daysLeft} дн.`}
                    </div>
                  )}
                </span>
              </div>
              <div className="info-row"><span className="info-label">Створено</span><span className="info-value" style={{ fontSize: '12.5px', color: 'var(--text-3)' }}>{ws.created_at ? new Date(ws.created_at).toLocaleDateString('uk-UA') : '—'}</span></div>
            </div>
          </div>
        </Section>

        {/* Subscription management */}
        <Section title="Управління підпискою" icon="credit_card">
          {/* Plan info row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 14px', background: 'var(--surface-2)', borderRadius: 'var(--radius)', border: '1px solid var(--border)', marginBottom: '16px' }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: '11px', color: 'var(--text-3)', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '3px' }}>Поточний план</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontSize: '16px', fontWeight: '800', color: 'var(--text)' }}>
                  {ws.subscription_plan === 'pro_plus' ? 'PRO+' : ws.subscription_plan === 'pro' ? 'PRO' : 'Free'}
                </span>
                {ws.subscription_plan !== 'free' && (
                  <span style={{ fontSize: '12px', color: 'var(--text-3)' }}>
                    · {ws.subscription_plan === 'pro' ? '$20' : '$35'}/міс
                    · ≈ {ws.subscription_plan === 'pro' ? Math.round(20 * 41) : Math.round(35 * 41)} ₴
                  </span>
                )}
              </div>
            </div>
            {daysLeft !== null && (
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '22px', fontWeight: '800', color: daysLeft <= 0 ? '#dc2626' : daysLeft <= 7 ? '#b45309' : '#15803d', lineHeight: 1 }}>{Math.max(0, daysLeft)}</div>
                <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>днів залишилось</div>
              </div>
            )}
          </div>

          {/* Plan selector */}
          <div style={{ marginBottom: '16px' }}>
            <div style={{ fontSize: '12px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '10px' }}>Змінити тариф</div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {[
                { id: 'free',     label: 'Free',  color: '#6b7280' },
                { id: 'pro',      label: 'PRO — $20/міс',  color: '#7c3aed' },
                { id: 'pro_plus', label: 'PRO+ — $35/міс', color: '#f59e0b' },
              ].map(plan => (
                <button key={plan.id}
                  onClick={async () => { await adminClient.post(`/workspaces/${id}/assign-plan`, { plan: plan.id, days: extendDays }); load(); }}
                  className="btn btn-sm"
                  style={{
                    background: ws.subscription_plan === plan.id ? plan.color : 'var(--surface)',
                    color: ws.subscription_plan === plan.id ? '#fff' : 'var(--text)',
                    border: `1.5px solid ${ws.subscription_plan === plan.id ? plan.color : 'var(--border)'}`,
                    fontWeight: ws.subscription_plan === plan.id ? '700' : '500',
                  }}
                >
                  {plan.label}
                </button>
              ))}
            </div>
          </div>

          {/* Days controls */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'var(--surface-2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '6px 10px' }}>
              <span style={{ fontSize: '12.5px', color: 'var(--text-2)', fontWeight: '500' }}>Днів:</span>
              <select value={extendDays} onChange={e => setExtendDays(Number(e.target.value))} style={{ border: 'none', background: 'transparent', fontSize: '13px', fontWeight: '600', color: 'var(--text)', outline: 'none', cursor: 'pointer' }}>
                {[7, 14, 30, 60, 90, 180, 365].map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <button onClick={extend} className="btn btn-primary btn-sm">
              <Icon name="calendar" size={12} /> Продовжити
            </button>
            <button onClick={async () => {
              const days = prompt('Скільки днів зменшити?', '7')
              if (days && !isNaN(days)) { await adminClient.post(`/workspaces/${id}/reduce`, { days: parseInt(days) }); load() }
            }} className="btn btn-sm" style={{ background: '#fff7ed', color: '#c2410c', border: '1px solid #fed7aa' }}>
              <Icon name="minus" size={12} /> Зменшити
            </button>
            <button onClick={async () => { if (confirm('Скасувати підписку?')) { await adminClient.post(`/workspaces/${id}/cancel`); load() } }} className="btn btn-danger btn-sm">
              <Icon name="x" size={12} /> Скасувати
            </button>
            <button onClick={toggleStatus} className="btn btn-sm" style={{ background: ws.subscription_status === 'active' ? '#fefce8' : '#f0fdf4', color: ws.subscription_status === 'active' ? '#a16207' : '#15803d', border: `1px solid ${ws.subscription_status === 'active' ? '#fde68a' : '#bbf7d0'}` }}>
              <Icon name={ws.subscription_status === 'active' ? 'pause' : 'play'} size={12} />
              {ws.subscription_status === 'active' ? 'Призупинити' : 'Активувати'}
            </button>
          </div>
        </Section>

        {/* Access token */}
        <Section title="Токен доступу" icon="key">
          <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginBottom: '12px' }}>Передайте цей токен клієнту для входу в CRM</p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{ flex: 1, background: 'var(--surface-2)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius)', padding: '10px 14px', fontFamily: 'monospace', fontSize: '12.5px', color: 'var(--text)', wordBreak: 'break-all', lineHeight: '1.5' }}>
              {showToken ? ws.access_token : '•'.repeat(36)}
            </div>
            <button onClick={() => setShowToken(v => !v)} className="btn btn-secondary btn-sm btn-icon">
              <Icon name={showToken ? 'eye_off' : 'eye'} size={14} />
            </button>
            <button onClick={copyToken} className={`btn btn-sm ${tokenCopied ? 'btn-secondary' : 'btn-primary'}`}>
              <Icon name={tokenCopied ? 'check' : 'copy'} size={13} />
              {tokenCopied ? 'Скопійовано' : 'Копіювати'}
            </button>
          </div>
          <div style={{ marginTop: '10px', padding: '10px 12px', background: '#eff6ff', borderRadius: 'var(--radius-sm)', fontSize: '12px', color: '#1d4ed8', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Icon name="info" size={12} />
            Посилання для клієнта: <code style={{ fontFamily: 'monospace', background: '#dbeafe', padding: '1px 5px', borderRadius: '3px' }}>https://ваш-домен/?token={ws.access_token.slice(0, 8)}...</code>
          </div>
        </Section>

        {/* CRM Config */}
        <Section title="Налаштування CRM" icon="settings"
          action={
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              {saveMsg && <span style={{ fontSize: '12px', color: saveMsg === 'Збережено' ? '#15803d' : '#dc2626', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '4px' }}>
                <Icon name={saveMsg === 'Збережено' ? 'check' : 'x'} size={12} />
                {saveMsg}
              </span>}
              <button onClick={saveConfig} disabled={saving} className="btn btn-primary btn-sm">
                {saving ? 'Зберігаємо...' : <><Icon name="check" size={12} /> Зберегти</>}
              </button>
            </div>
          }
        >
          {tabs.length > 0 && (
            <div style={{ marginBottom: '20px' }}>
              <div style={{ fontSize: '12px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '10px' }}>Вкладки навігації</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                {tabs.map(tab => (
                  <div key={tab.key} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 12px', background: 'var(--surface-2)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
                    <span style={{ fontSize: '13.5px', color: 'var(--text)', fontWeight: '500' }}>{tab.label}</span>
                    <label className="toggle">
                      <input type="checkbox" checked={!!tab.enabled} onChange={() => setTabs(prev => prev.map(t => t.key === tab.key ? { ...t, enabled: !t.enabled } : t))} />
                      <span className="toggle-slider" />
                    </label>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <div style={{ fontSize: '12px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '10px' }}>Основний колір бренду</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <input type="color" value={primaryColor} onChange={e => setPrimaryColor(e.target.value)} style={{ width: '44px', height: '38px', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)', cursor: 'pointer', padding: '3px' }} />
              <code style={{ fontSize: '13px', fontFamily: 'monospace', color: 'var(--text-2)', background: 'var(--surface-2)', padding: '4px 10px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>{primaryColor}</code>
              <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: primaryColor, border: '1px solid rgba(0,0,0,0.1)' }} />
              <div style={{ display: 'flex', gap: '6px' }}>
                {['#16a34a', '#2563eb', '#7c3aed', '#dc2626', '#d97706', '#0891b2'].map(c => (
                  <div key={c} onClick={() => setPrimaryColor(c)} style={{ width: '22px', height: '22px', borderRadius: '6px', background: c, cursor: 'pointer', border: primaryColor === c ? '2px solid var(--text)' : '2px solid transparent', transition: 'border 0.1s' }} />
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* Danger zone */}
        <div style={{ background: '#fff', borderRadius: 'var(--radius-lg)', border: '1px solid #fecaca', padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
            <Icon name="warning" size={15} color="#dc2626" />
            <span style={{ fontSize: '14px', fontWeight: '700', color: '#dc2626' }}>Небезпечна зона</span>
          </div>
          <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginBottom: '14px' }}>
            Видалення воркспейсу призведе до безповоротної втрати всіх лідів, завдань та налаштувань.
          </p>
          <button onClick={deleteWorkspace} className="btn btn-danger">
            <Icon name="trash" size={13} /> Видалити воркспейс
          </button>
        </div>
      </div>
    </div>
  )
}
