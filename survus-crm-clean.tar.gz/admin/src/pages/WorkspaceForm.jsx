import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import adminClient from '../api/adminClient'
import Icon from '../components/Icons'

const ALL_TABS = [
  { key: 'dashboard', label: 'Дашборд', icon: 'dashboard', required: true, desc: 'Головна сторінка зі статистикою' },
  { key: 'leads',     label: 'Ліди',     icon: 'leads',     required: true, desc: 'Управління лідами та клієнтами' },
  { key: 'tasks',     label: 'Завдання', icon: 'tasks',     required: false, desc: 'Задачі та нагадування' },
  { key: 'reports',   label: 'Звіти',    icon: 'reports',   required: false, desc: 'Аналітика та статистика' },
  { key: 'contacts',  label: 'Контакти', icon: 'contacts',  required: false, desc: 'База контактів' },
  { key: 'deals',     label: 'Угоди',    icon: 'deals',     required: false, desc: 'Воронка продажів' },
  { key: 'appointments', label: 'Зустрічі', icon: 'calendar', required: false, desc: 'Розклад та зустрічі' },
]

const TEMPLATE_PRESETS = {
  instagram_sales: { tabs: ['dashboard','leads','tasks','reports'], color: '#16a34a' },
  beauty:          { tabs: ['dashboard','leads','appointments','tasks','reports'], color: '#db2777' },
  services:        { tabs: ['dashboard','leads','deals','tasks','appointments','reports'], color: '#2563eb' },
  simple_sales:    { tabs: ['dashboard','leads','tasks'], color: '#d97706' },
}

const TEMPLATE_META = {
  instagram_sales: { icon: 'instagram', label: 'Instagram Sales', desc: 'Для продавців в Instagram та Telegram' },
  beauty:          { icon: 'star',      label: 'Beauty & Wellness', desc: 'Салони краси, майстри' },
  services:        { icon: 'settings',  label: 'Services', desc: 'Сервісний бізнес, підрядники' },
  simple_sales:    { icon: 'dollar',    label: 'Simple Sales', desc: 'Мінімальна CRM для продажів' },
}

const COLORS = ['#16a34a','#2563eb','#7c3aed','#db2777','#d97706','#0891b2','#dc2626','#0f172a']

const PLAN_DEFS = [
  { id: 'free',     label: 'Free',  price_usd: 0,  color: '#6b7280', desc: 'Базовий функціонал', features: ['До 100 лідів','Базова аналітика'] },
  { id: 'pro',      label: 'PRO',   price_usd: 20, color: '#7c3aed', desc: 'Для активних продавців', features: ['Необмежені ліди','Розширена аналітика','Кастомні теми','Пріоритетна підтримка'] },
  { id: 'pro_plus', label: 'PRO+',  price_usd: 35, color: '#f59e0b', desc: 'Максимум можливостей', features: ['Все з PRO','AI-інсайти','API доступ','White-label','Персональний менеджер'] },
]

const DURATIONS = [
  { label: '1 місяць', days: 30,  multiplier: 1,  badge: null },
  { label: '1 рік',    days: 365, multiplier: 12, badge: '-17%' },
]

export default function WorkspaceForm() {
  const [step, setStep] = useState(1) // 1=info, 2=template, 3=subscription, 4=customize, 5=done
  const [companyName, setCompanyName] = useState('')
  const [templateId, setTemplateId] = useState('instagram_sales')
  const [enabledTabs, setEnabledTabs] = useState(['dashboard','leads','tasks','reports'])
  const [tabOrder, setTabOrder] = useState(['dashboard','leads','tasks','reports'])
  const [tabLabels, setTabLabels] = useState({})
  const [primaryColor, setPrimaryColor] = useState('#16a34a')
  const [selectedPlan, setSelectedPlan] = useState('pro')
  const [selectedDuration, setSelectedDuration] = useState(0) // index into DURATIONS
  const [uahRate, setUahRate] = useState(41)
  const [loading, setLoading] = useState(false)
  const [created, setCreated] = useState(null)
  const [copied, setCopied] = useState(false)
  const [dragIdx, setDragIdx] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    adminClient.get('/plans').then(r => {
      const pro = r.data.find(p => p.id === 'pro')
      if (pro?.uah_rate) setUahRate(pro.uah_rate)
    }).catch(() => {})
  }, [])

  function applyTemplate(id) {
    setTemplateId(id)
    const preset = TEMPLATE_PRESETS[id]
    if (preset) { setEnabledTabs(preset.tabs); setTabOrder(preset.tabs); setPrimaryColor(preset.color) }
  }

  function toggleTab(key) {
    if (ALL_TABS.find(t => t.key === key)?.required) return
    if (enabledTabs.includes(key)) {
      setEnabledTabs(p => p.filter(k => k !== key)); setTabOrder(p => p.filter(k => k !== key))
    } else {
      setEnabledTabs(p => [...p, key]); setTabOrder(p => [...p, key])
    }
  }

  function moveTab(from, to) {
    const arr = [...tabOrder]; const [item] = arr.splice(from, 1); arr.splice(to, 0, item); setTabOrder(arr)
  }

  async function handleCreate() {
    if (!companyName.trim()) return
    setLoading(true)
    try {
      const dur = DURATIONS[selectedDuration]
      const orderedTabs = tabOrder.map((key, i) => {
        const base = ALL_TABS.find(t => t.key === key)
        return { key, label: tabLabels[key] || base?.label || key, order: i + 1, enabled: enabledTabs.includes(key) }
      })
      ALL_TABS.forEach(t => {
        if (!tabOrder.includes(t.key))
          orderedTabs.push({ key: t.key, label: tabLabels[t.key] || t.label, order: orderedTabs.length + 1, enabled: false })
      })
      const customConfig = { id: templateId, tabs: orderedTabs, primary_color: primaryColor, lead_statuses: ['new','replied','paid','canceled'] }
      const res = await adminClient.post('/workspaces', {
        company_name: companyName.trim(),
        template_id: templateId,
        crm_config: customConfig,
        plan: selectedPlan,
        days: dur.days,
      })
      setCreated(res.data)
      setStep(5)
    } catch (err) {
      alert(err.response?.data?.error || 'Помилка при створенні')
    } finally { setLoading(false) }
  }

  function copyToken() {
    navigator.clipboard.writeText(created.access_token)
    setCopied(true); setTimeout(() => setCopied(false), 2000)
  }

  const orderedEnabled = tabOrder.filter(k => enabledTabs.includes(k))
  const STEPS = ['Інформація','Шаблон','Підписка','Налаштування']

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Topbar onBack={() => navigate('/workspaces')} />
      <div style={{ padding: '28px 32px', maxWidth: '780px', margin: '0 auto' }}>

        {/* Progress */}
        {step < 5 && (
          <div style={{ marginBottom: '28px' }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              {STEPS.map((label, i) => {
                const n = i + 1; const done = step > n; const active = step === n
                return (
                  <div key={n} style={{ display: 'flex', alignItems: 'center', flex: i < STEPS.length - 1 ? 1 : 'none' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '7px', cursor: done ? 'pointer' : 'default' }} onClick={() => done && setStep(n)}>
                      <div style={{ width: '26px', height: '26px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '700', flexShrink: 0, background: done || active ? 'var(--primary)' : 'var(--border)', color: done || active ? '#fff' : 'var(--text-3)', transition: 'all 0.2s' }}>
                        {done ? <Icon name="check" size={11} /> : n}
                      </div>
                      <span style={{ fontSize: '12px', fontWeight: active ? '600' : '400', color: active ? 'var(--text)' : done ? 'var(--primary)' : 'var(--text-3)', whiteSpace: 'nowrap' }}>{label}</span>
                    </div>
                    {i < STEPS.length - 1 && <div style={{ flex: 1, height: '1px', background: done ? 'var(--primary)' : 'var(--border)', margin: '0 10px', transition: 'background 0.3s' }} />}
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Step 1: Info */}
        {step === 1 && (
          <div className="card scale-in" style={{ padding: '28px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text)', marginBottom: '4px' }}>Інформація про компанію</h2>
            <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginBottom: '24px' }}>Введіть назву компанії для нового воркспейсу</p>
            <div className="form-group" style={{ marginBottom: '24px' }}>
              <label className="form-label">Назва компанії <span className="form-required">*</span></label>
              <input value={companyName} onChange={e => setCompanyName(e.target.value)} placeholder="Наприклад: Магазин Аліни" className="input" autoFocus onKeyDown={e => e.key === 'Enter' && companyName.trim() && setStep(2)} />
              <span className="form-hint">Ця назва буде відображатись у CRM клієнта</span>
            </div>
            <button onClick={() => setStep(2)} disabled={!companyName.trim()} className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center' }}>
              Далі <Icon name="chevron_right" size={14} />
            </button>
          </div>
        )}

        {/* Step 2: Template */}
        {step === 2 && (
          <div className="scale-in">
            <h2 style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text)', marginBottom: '4px' }}>Оберіть шаблон CRM</h2>
            <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginBottom: '20px' }}>Шаблон визначає початкову структуру. Ви зможете налаштувати її далі.</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '20px' }}>
              {Object.entries(TEMPLATE_META).map(([id, meta]) => {
                const preset = TEMPLATE_PRESETS[id]; const isSelected = templateId === id
                return (
                  <div key={id} onClick={() => applyTemplate(id)} style={{ padding: '18px 20px', borderRadius: 'var(--radius-lg)', cursor: 'pointer', border: `2px solid ${isSelected ? 'var(--primary)' : 'var(--border)'}`, background: isSelected ? 'var(--primary-light)' : 'var(--surface)', transition: 'all 0.15s', position: 'relative' }}>
                    {isSelected && <div style={{ position: 'absolute', top: '12px', right: '12px', width: '18px', height: '18px', borderRadius: '50%', background: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="check" size={10} color="#fff" /></div>}
                    <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: preset.color + '18', color: preset.color, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px' }}><Icon name={meta.icon} size={17} /></div>
                    <div style={{ fontSize: '14px', fontWeight: '700', color: 'var(--text)', marginBottom: '4px' }}>{meta.label}</div>
                    <div style={{ fontSize: '12px', color: 'var(--text-3)', marginBottom: '10px', lineHeight: '1.5' }}>{meta.desc}</div>
                    <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                      {preset.tabs.map(t => <span key={t} style={{ fontSize: '10px', fontWeight: '600', color: preset.color, background: preset.color + '15', padding: '2px 6px', borderRadius: '4px' }}>{ALL_TABS.find(tab => tab.key === t)?.label || t}</span>)}
                    </div>
                  </div>
                )
              })}
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => setStep(1)} className="btn btn-secondary" style={{ flex: 1, justifyContent: 'center' }}><Icon name="arrow_left" size={13} /> Назад</button>
              <button onClick={() => setStep(3)} className="btn btn-primary" style={{ flex: 2, justifyContent: 'center' }}>Підписка <Icon name="chevron_right" size={14} /></button>
            </div>
          </div>
        )}

        {/* Step 3: Subscription */}
        {step === 3 && (
          <div className="scale-in">
            <h2 style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text)', marginBottom: '4px' }}>Оберіть підписку</h2>
            <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginBottom: '20px' }}>
              Курс НБУ: 1 USD = {uahRate.toFixed(2)} ₴
            </p>

            {/* Duration toggle */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
              {DURATIONS.map((d, i) => (
                <button key={i} type="button" onClick={() => setSelectedDuration(i)} style={{ flex: 1, padding: '10px 16px', borderRadius: 'var(--radius)', border: `2px solid ${selectedDuration === i ? 'var(--primary)' : 'var(--border)'}`, background: selectedDuration === i ? 'var(--primary-light)' : 'var(--surface)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', transition: 'all 0.15s' }}>
                  <span style={{ fontSize: '13px', fontWeight: '600', color: selectedDuration === i ? 'var(--primary)' : 'var(--text)' }}>{d.label}</span>
                  {d.badge && <span style={{ fontSize: '10px', fontWeight: '700', color: '#15803d', background: '#dcfce7', padding: '2px 6px', borderRadius: '4px' }}>{d.badge}</span>}
                </button>
              ))}
            </div>

            {/* Plan cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginBottom: '20px' }}>
              {PLAN_DEFS.map(plan => {
                const dur = DURATIONS[selectedDuration]
                const priceUsd = plan.price_usd === 0 ? 0 : plan.price_usd * dur.multiplier
                const priceUah = Math.round(priceUsd * uahRate)
                const isSelected = selectedPlan === plan.id
                return (
                  <div key={plan.id} onClick={() => setSelectedPlan(plan.id)} style={{ padding: '18px', borderRadius: 'var(--radius-lg)', cursor: 'pointer', border: `2px solid ${isSelected ? plan.color : 'var(--border)'}`, background: isSelected ? plan.color + '0d' : 'var(--surface)', transition: 'all 0.15s', position: 'relative' }}>
                    {isSelected && <div style={{ position: 'absolute', top: '10px', right: '10px', width: '16px', height: '16px', borderRadius: '50%', background: plan.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="check" size={9} color="#fff" /></div>}
                    <div style={{ fontSize: '13px', fontWeight: '800', color: plan.color, marginBottom: '6px', letterSpacing: '0.02em' }}>{plan.label}</div>
                    {plan.price_usd === 0 ? (
                      <div style={{ fontSize: '18px', fontWeight: '800', color: 'var(--text)', marginBottom: '2px' }}>Безкоштовно</div>
                    ) : (
                      <>
                        <div style={{ fontSize: '22px', fontWeight: '800', color: 'var(--text)', lineHeight: 1 }}>${priceUsd}</div>
                        <div style={{ fontSize: '12px', color: 'var(--text-3)', marginBottom: '2px' }}>≈ {priceUah.toLocaleString('uk-UA')} ₴</div>
                        <div style={{ fontSize: '10.5px', color: 'var(--text-4)' }}>за {dur.label.toLowerCase()}</div>
                      </>
                    )}
                    <div style={{ marginTop: '12px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
                      {plan.features.map(f => (
                        <div key={f} style={{ display: 'flex', alignItems: 'center', gap: '5px', fontSize: '11px', color: 'var(--text-2)' }}>
                          <Icon name="check" size={12} color={plan.color} /> {f}
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => setStep(2)} className="btn btn-secondary" style={{ flex: 1, justifyContent: 'center' }}><Icon name="arrow_left" size={13} /> Назад</button>
              <button onClick={() => setStep(4)} className="btn btn-primary" style={{ flex: 2, justifyContent: 'center' }}>Налаштування <Icon name="chevron_right" size={14} /></button>
            </div>
          </div>
        )}

        {/* Step 4: Customize */}
        {step === 4 && (
          <div className="scale-in">
            <h2 style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text)', marginBottom: '4px' }}>Налаштування CRM</h2>
            <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginBottom: '20px' }}>Оберіть вкладки, їх порядок та колір бренду</p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '14px' }}>
              <div className="card" style={{ padding: '18px' }}>
                <div style={{ fontSize: '12px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '12px' }}>Вкладки</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                  {ALL_TABS.map(tab => {
                    const enabled = enabledTabs.includes(tab.key)
                    return (
                      <div key={tab.key} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px 10px', borderRadius: '8px', background: enabled ? 'var(--primary-light)' : 'var(--surface-2)', border: `1px solid ${enabled ? 'var(--primary-border)' : 'var(--border)'}`, transition: 'all 0.12s' }}>
                        <span style={{ color: enabled ? 'var(--primary)' : 'var(--text-3)', display: 'flex' }}><Icon name={tab.icon} size={13} /></span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: '12.5px', fontWeight: '600', color: enabled ? 'var(--text)' : 'var(--text-3)' }}>{tab.label}</div>
                          <div style={{ fontSize: '10.5px', color: 'var(--text-3)' }}>{tab.desc}</div>
                        </div>
                        {tab.required
                          ? <span style={{ fontSize: '10px', color: 'var(--primary)', fontWeight: '600', background: 'var(--primary-light)', padding: '1px 5px', borderRadius: '3px' }}>обов.</span>
                          : <label className="toggle" style={{ width: '34px', height: '19px' }}><input type="checkbox" checked={enabled} onChange={() => toggleTab(tab.key)} /><span className="toggle-slider" /></label>
                        }
                      </div>
                    )
                  })}
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <div className="card" style={{ padding: '18px' }}>
                  <div style={{ fontSize: '12px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '12px' }}>Порядок вкладок</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                    {orderedEnabled.map((key, i) => {
                      const tab = ALL_TABS.find(t => t.key === key)
                      return (
                        <div key={key} draggable onDragStart={() => setDragIdx(i)} onDragOver={e => { e.preventDefault(); if (dragIdx !== null && dragIdx !== i) moveTab(dragIdx, i) }} onDragEnd={() => setDragIdx(null)} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '7px 10px', borderRadius: '7px', background: 'var(--surface-2)', border: '1px solid var(--border)', cursor: 'grab', opacity: dragIdx === i ? 0.5 : 1 }}>
                          <Icon name="filter" size={11} color="var(--text-4)" />
                          <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-4)', width: '14px' }}>{i + 1}</span>
                          <span style={{ color: 'var(--primary)', display: 'flex' }}><Icon name={tab?.icon || 'info'} size={12} /></span>
                          <input value={tabLabels[key] ?? tab?.label ?? key} onChange={e => setTabLabels(p => ({ ...p, [key]: e.target.value }))} style={{ border: 'none', background: 'transparent', outline: 'none', fontSize: '12.5px', fontWeight: '500', color: 'var(--text)', flex: 1 }} onClick={e => e.stopPropagation()} />
                        </div>
                      )
                    })}
                  </div>
                </div>
                <div className="card" style={{ padding: '18px' }}>
                  <div style={{ fontSize: '12px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '12px' }}>Колір бренду</div>
                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '10px' }}>
                    {COLORS.map(c => <div key={c} onClick={() => setPrimaryColor(c)} style={{ width: '24px', height: '24px', borderRadius: '6px', background: c, cursor: 'pointer', border: primaryColor === c ? '2px solid var(--text)' : '2px solid transparent', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }} />)}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <input type="color" value={primaryColor} onChange={e => setPrimaryColor(e.target.value)} style={{ width: '36px', height: '32px', border: '1.5px solid var(--border)', borderRadius: '7px', cursor: 'pointer', padding: '2px' }} />
                    <code style={{ fontSize: '12px', color: 'var(--text-2)', background: 'var(--surface-2)', padding: '4px 8px', borderRadius: '5px', border: '1px solid var(--border)' }}>{primaryColor}</code>
                  </div>
                </div>
              </div>
            </div>
            <div className="card" style={{ padding: '14px 18px', marginBottom: '14px', background: 'var(--surface-2)' }}>
              <div style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '10px' }}>Попередній перегляд</div>
              <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                {orderedEnabled.map((key, i) => {
                  const tab = ALL_TABS.find(t => t.key === key); const label = tabLabels[key] || tab?.label || key
                  return <div key={key} style={{ display: 'flex', alignItems: 'center', gap: '5px', padding: '5px 10px', borderRadius: '7px', background: i === 0 ? primaryColor + '18' : 'var(--surface)', border: `1px solid ${i === 0 ? primaryColor + '40' : 'var(--border)'}`, fontSize: '12px', fontWeight: i === 0 ? '600' : '400', color: i === 0 ? primaryColor : 'var(--text-2)' }}><Icon name={tab?.icon || 'info'} size={11} />{label}</div>
                })}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => setStep(3)} className="btn btn-secondary" style={{ flex: 1, justifyContent: 'center' }}><Icon name="arrow_left" size={13} /> Назад</button>
              <button onClick={handleCreate} disabled={loading} className="btn btn-primary" style={{ flex: 2, justifyContent: 'center' }}>
                {loading ? 'Створюємо...' : <><Icon name="building" size={13} /> Створити воркспейс</>}
              </button>
            </div>
          </div>
        )}

        {/* Step 5: Done */}
        {step === 5 && created && (
          <div className="card scale-in" style={{ padding: '32px', textAlign: 'center' }}>
            <div style={{ width: '56px', height: '56px', borderRadius: '16px', background: '#f0fdf4', border: '1px solid #bbf7d0', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <Icon name="check" size={24} color="#16a34a" />
            </div>
            <h2 style={{ fontSize: '20px', fontWeight: '800', color: 'var(--text)', marginBottom: '6px' }}>Воркспейс створено!</h2>
            <p style={{ fontSize: '13px', color: 'var(--text-3)', marginBottom: '8px' }}>{created.company_name}</p>
            <div style={{ display: 'flex', gap: '6px', justifyContent: 'center', marginBottom: '24px' }}>
              <span style={{ fontSize: '11px', fontWeight: '700', padding: '3px 10px', borderRadius: '20px', background: PLAN_DEFS.find(p => p.id === selectedPlan)?.color + '18', color: PLAN_DEFS.find(p => p.id === selectedPlan)?.color }}>{PLAN_DEFS.find(p => p.id === selectedPlan)?.label}</span>
              <span style={{ fontSize: '11px', fontWeight: '600', padding: '3px 10px', borderRadius: '20px', background: 'var(--surface-2)', color: 'var(--text-3)' }}>{DURATIONS[selectedDuration].label}</span>
            </div>
            <div style={{ background: 'var(--surface-2)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius)', padding: '14px 16px', marginBottom: '8px', textAlign: 'left' }}>
              <div style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '8px' }}>Токен доступу</div>
              <div style={{ fontFamily: 'monospace', fontSize: '12.5px', color: 'var(--text)', wordBreak: 'break-all', lineHeight: '1.6' }}>{created.access_token}</div>
            </div>
            <p style={{ fontSize: '11.5px', color: 'var(--text-3)', marginBottom: '20px' }}>Збережіть токен — він більше не буде показаний повністю</p>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={copyToken} className={`btn ${copied ? 'btn-secondary' : 'btn-primary'}`} style={{ flex: 1, justifyContent: 'center' }}>
                <Icon name={copied ? 'check' : 'copy'} size={13} />{copied ? 'Скопійовано!' : 'Копіювати токен'}
              </button>
              <button onClick={() => navigate('/workspaces')} className="btn btn-secondary" style={{ flex: 1, justifyContent: 'center' }}>До списку</button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function Topbar({ onBack }) {
  return (
    <div style={{ height: '56px', background: '#fff', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', padding: '0 28px', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div style={{ width: '26px', height: '26px', borderRadius: '7px', background: 'var(--primary-light)', border: '1px solid var(--primary-border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" fill="#16a34a"/><circle cx="12" cy="12" r="1.5" fill="#fff"/></svg>
        </div>
        <span style={{ fontSize: '13px', fontWeight: '800', color: 'var(--text)', letterSpacing: '1px' }}>SURVUS</span>
        <span style={{ fontSize: '9px', fontWeight: '700', color: 'var(--primary)', background: 'var(--primary-light)', padding: '2px 5px', borderRadius: '3px', letterSpacing: '0.5px' }}>ADMIN</span>
      </div>
      <button onClick={onBack} className="btn btn-ghost btn-sm"><Icon name="arrow_left" size={12} /> Назад</button>
    </div>
  )
}
