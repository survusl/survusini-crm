import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import adminClient from '../api/adminClient'
import Icon from '../components/Icons'

const STATUS_BADGE = { active: 'badge-active', suspended: 'badge-suspended', expired: 'badge-expired' }
const STATUS_LABEL = { active: 'Активний', suspended: 'Призупинено', expired: 'Прострочено' }

function Topbar({ onLogout }) {
  return (
    <div style={{ height: '56px', background: '#fff', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', padding: '0 28px', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: '#f0fdf4', border: '1px solid var(--primary-border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" fill="#16a34a"/>
            <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" stroke="#fff" strokeWidth="1.5" fill="none"/>
            <circle cx="12" cy="12" r="1.5" fill="#fff"/>
          </svg>
        </div>
        <span style={{ fontSize: '14px', fontWeight: '800', color: 'var(--text)', letterSpacing: '1px' }}>SURVUS</span>
        <span style={{ fontSize: '10px', fontWeight: '700', color: 'var(--primary)', background: 'var(--primary-light)', padding: '2px 6px', borderRadius: '4px', letterSpacing: '0.5px' }}>ADMIN</span>
      </div>
      <button onClick={onLogout} className="btn btn-ghost btn-sm" style={{ color: 'var(--text-3)' }}>
        <Icon name="logout" size={13} /> Вийти
      </button>
    </div>
  )
}

export default function WorkspaceList() {
  const [workspaces, setWorkspaces] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const navigate = useNavigate()

  async function load() {
    setLoading(true)
    try {
      const [wsRes, stRes] = await Promise.all([adminClient.get('/workspaces'), adminClient.get('/stats')])
      setWorkspaces(wsRes.data)
      setStats(stRes.data)
    } catch {
      sessionStorage.removeItem('survus_admin_password')
      navigate('/')
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  async function toggleStatus(ws, e) {
    e.stopPropagation()
    const newStatus = ws.subscription_status === 'active' ? 'suspended' : 'active'
    await adminClient.patch(`/workspaces/${ws.id}`, { subscription_status: newStatus })
    load()
  }

  async function extend(ws, e) {
    e.stopPropagation()
    const base = ws.subscription_until ? new Date(ws.subscription_until) : new Date()
    base.setDate(base.getDate() + 30)
    await adminClient.patch(`/workspaces/${ws.id}`, { subscription_until: base.toISOString(), subscription_status: 'active' })
    load()
  }

  async function remove(ws, e) {
    e.stopPropagation()
    if (!confirm(`Видалити воркспейс "${ws.company_name}"? Всі дані будуть втрачені.`)) return
    await adminClient.delete(`/workspaces/${ws.id}`)
    load()
  }

  const filtered = search.trim()
    ? workspaces.filter(w => w.company_name.toLowerCase().includes(search.toLowerCase()) || w.template_id?.toLowerCase().includes(search.toLowerCase()))
    : workspaces

  if (loading) return (
    <div>
      <Topbar onLogout={() => { sessionStorage.removeItem('survus_admin_password'); navigate('/') }} />
      <div className="loading-center"><div className="spinner" /></div>
    </div>
  )

  const expiringSoon = workspaces.filter(w => {
    if (!w.subscription_until) return false
    const days = Math.ceil((new Date(w.subscription_until) - new Date()) / (1000 * 60 * 60 * 24))
    return days <= 7 && days > 0 && w.subscription_status === 'active'
  })

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <Topbar onLogout={() => { sessionStorage.removeItem('survus_admin_password'); navigate('/') }} />

      <div style={{ padding: '24px 28px' }} className="fade-up">
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '22px', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h1 style={{ fontSize: '20px', fontWeight: '700', color: 'var(--text)', letterSpacing: '-0.3px' }}>Воркспейси</h1>
            <p style={{ fontSize: '12.5px', color: 'var(--text-3)', marginTop: '3px' }}>Управління клієнтами та підписками</p>
          </div>
          <button onClick={() => navigate('/workspaces/new')} className="btn btn-primary">
            <Icon name="plus" size={13} /> Новий воркспейс
          </button>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', marginBottom: '22px' }}>
          {[
            { label: 'Всього', value: stats?.total_workspaces ?? 0, icon: 'building', color: '#2563eb', bg: '#eff6ff' },
            { label: 'Активних', value: stats?.active_workspaces ?? 0, icon: 'activity', color: '#15803d', bg: '#f0fdf4' },
            { label: 'Всього лідів', value: stats?.total_leads ?? 0, icon: 'users', color: '#7c3aed', bg: '#f5f3ff' },
            { label: 'Закінчується', value: expiringSoon.length, icon: 'clock', color: '#b45309', bg: '#fffbeb' },
          ].map(s => (
            <div key={s.label} className="stat-card">
              <div className="stat-icon" style={{ background: s.bg, color: s.color }}><Icon name={s.icon} size={16} /></div>
              <div className="stat-value">{s.value}</div>
              <div className="stat-label">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Alert: expiring soon */}
        {expiringSoon.length > 0 && (
          <div style={{ padding: '12px 16px', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 'var(--radius)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Icon name="warning" size={15} color="#b45309" />
            <span style={{ fontSize: '13px', color: '#92400e', fontWeight: '500' }}>
              {expiringSoon.length} воркспейс(ів) закінчується протягом 7 днів: {expiringSoon.map(w => w.company_name).join(', ')}
            </span>
          </div>
        )}

        {/* Search */}
        <div style={{ position: 'relative', maxWidth: '320px', marginBottom: '14px' }}>
          <span style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)', display: 'flex', pointerEvents: 'none' }}>
            <Icon name="search" size={13} />
          </span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Пошук воркспейсів..." className="input" style={{ paddingLeft: '32px' }} />
        </div>

        {/* Table */}
        <div className="card" style={{ overflow: 'hidden' }}>
          <div className="card-header">
            <span className="card-title">Всі воркспейси</span>
            <span style={{ fontSize: '12px', color: 'var(--text-3)' }}>{filtered.length} з {workspaces.length}</span>
          </div>
          <table>
            <thead>
              <tr>
                <th>Компанія</th>
                <th>Статус</th>
                <th>Шаблон</th>
                <th>Ліди</th>
                <th>Підписка до</th>
                <th>Дії</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: '48px', color: 'var(--text-3)' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                    <Icon name="building" size={28} color="var(--text-4)" />
                    <span>Воркспейсів не знайдено</span>
                  </div>
                </td></tr>
              ) : filtered.map(ws => {
                const daysLeft = ws.subscription_until
                  ? Math.ceil((new Date(ws.subscription_until) - new Date()) / (1000 * 60 * 60 * 24))
                  : null
                const isExpiringSoon = daysLeft !== null && daysLeft <= 7 && daysLeft > 0
                return (
                  <tr key={ws.id} className="clickable" onClick={() => navigate(`/workspaces/${ws.id}`)}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div style={{ width: '30px', height: '30px', borderRadius: '8px', background: 'var(--primary-light)', color: 'var(--primary)', fontSize: '12px', fontWeight: '700', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                          {ws.company_name[0]?.toUpperCase()}
                        </div>
                        <div>
                          <div style={{ fontWeight: '600', color: 'var(--text)' }}>{ws.company_name}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-3)' }}>ID: {ws.id.slice(0, 8)}...</div>
                        </div>
                      </div>
                    </td>
                    <td><span className={`badge ${STATUS_BADGE[ws.subscription_status] || 'badge-neutral'}`}>{STATUS_LABEL[ws.subscription_status] || ws.subscription_status}</span></td>
                    <td>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                        <span style={{ fontSize: '12.5px', color: 'var(--text-2)', background: 'var(--surface-2)', padding: '2px 8px', borderRadius: '4px', border: '1px solid var(--border)', width: 'fit-content' }}>
                          {ws.template_id || '—'}
                        </span>
                        {ws.subscription_plan && ws.subscription_plan !== 'free' && (
                          <span style={{ fontSize: '10.5px', fontWeight: '700', padding: '1px 6px', borderRadius: '4px', width: 'fit-content', background: ws.subscription_plan === 'pro_plus' ? '#fef3c7' : '#ede9fe', color: ws.subscription_plan === 'pro_plus' ? '#b45309' : '#6d28d9' }}>
                            {ws.subscription_plan === 'pro_plus' ? 'PRO+' : 'PRO'}
                          </span>
                        )}
                      </div>
                    </td>
                    <td><span style={{ fontWeight: '600' }}>{ws.leads_count ?? 0}</span></td>
                    <td>
                      <div>
                        <div style={{ fontSize: '13px', color: isExpiringSoon ? '#b45309' : 'var(--text-2)', fontWeight: isExpiringSoon ? '600' : '400' }}>
                          {ws.subscription_until ? new Date(ws.subscription_until).toLocaleDateString('uk-UA') : '—'}
                        </div>
                        {daysLeft !== null && (
                          <div style={{ fontSize: '11px', color: daysLeft <= 0 ? '#dc2626' : daysLeft <= 7 ? '#b45309' : 'var(--text-3)' }}>
                            {daysLeft <= 0 ? 'Прострочено' : `${daysLeft} дн.`}
                          </div>
                        )}
                      </div>
                    </td>
                    <td onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'flex', gap: '5px' }}>
                        <button onClick={e => toggleStatus(ws, e)} className="btn btn-sm" style={{ background: ws.subscription_status === 'active' ? '#fefce8' : '#f0fdf4', color: ws.subscription_status === 'active' ? '#a16207' : '#15803d', border: 'none' }}>
                          <Icon name={ws.subscription_status === 'active' ? 'pause' : 'play'} size={11} />
                          {ws.subscription_status === 'active' ? 'Призупинити' : 'Активувати'}
                        </button>
                        <button onClick={e => extend(ws, e)} className="btn btn-sm" style={{ background: '#eff6ff', color: '#2563eb', border: 'none' }}>
                          <Icon name="calendar" size={11} /> +30д
                        </button>
                        <button onClick={e => remove(ws, e)} className="btn btn-sm btn-danger">
                          <Icon name="trash" size={11} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
