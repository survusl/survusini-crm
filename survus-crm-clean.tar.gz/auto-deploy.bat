@echo off
REM 🚀 SURVUS CRM - Автоматичний деплой (Windows)
REM Безпечний скрипт - ваші дані не зберігаються

echo 🚀 SURVUS CRM - Автоматичний деплой на GitHub
echo ==============================================
echo.
echo ⚠️  ВАЖЛИВО: Ваші дані будуть використані тільки для цього деплою
echo    і НЕ будуть збережені ніде!
echo.

REM Перевірка Git
where git >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ Git не встановлено
    pause
    exit /b 1
)

REM Запит даних
echo 📝 Введіть ваші дані GitHub:
echo.
set /p github_username="GitHub Username: "
set /p repo_name="Назва репозиторію (Enter для 'survus-crm'): "
if "%repo_name%"=="" set repo_name=survus-crm

echo.
echo 🔐 Для автентифікації потрібен Personal Access Token
echo    (НЕ пароль! Токен безпечніший)
echo.
echo Як створити токен:
echo 1. Відкрийте: https://github.com/settings/tokens
echo 2. Generate new token (classic)
echo 3. Виберіть 'repo' (full control)
echo 4. Generate token
echo 5. Скопіюйте токен
echo.
set /p github_token="Personal Access Token: "
echo.

REM Перевірка чи існує remote
git remote | findstr origin >nul
if %ERRORLEVEL% EQU 0 (
    echo ⚠️  Remote 'origin' вже існує. Видаляю...
    git remote remove origin
)

REM Додавання remote
echo 📡 Підключення до GitHub...
git remote add origin https://%github_username%:%github_token%@github.com/%github_username%/%repo_name%.git

REM Push
echo 📤 Відправка коду на GitHub...
git push -u origin main 2>&1 | findstr "Repository not found" >nul
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ❌ Репозиторій не знайдено!
    echo.
    echo Створіть репозиторій вручну:
    echo 1. Відкрийте: https://github.com/new
    echo 2. Назва: %repo_name%
    echo 3. Private або Public
    echo 4. НЕ додавайте README
    echo 5. Create repository
    echo.
    echo Потім запустіть скрипт знову
    git remote remove origin
    pause
    exit /b 1
)

REM Очищення токену з URL (для безпеки)
git remote set-url origin https://github.com/%github_username%/%repo_name%.git

echo.
echo 🎉 Успішно відправлено на GitHub!
echo.
echo 📋 Ваш репозиторій:
echo    https://github.com/%github_username%/%repo_name%
echo.
echo 🚀 Наступні кроки:
echo 1. Відкрийте: https://railway.app
echo 2. Login with GitHub
echo 3. New Project → Deploy from GitHub repo
echo 4. Виберіть: %repo_name%
echo 5. Чекайте 2-3 хвилини
echo 6. Отримайте URL!
echo.
echo ✅ Готово!
pause
