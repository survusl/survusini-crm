#!/bin/bash

# 🚀 SURVUS CRM - Автоматичний деплой
# Безпечний скрипт - ваші дані не зберігаються

echo "🚀 SURVUS CRM - Автоматичний деплой на GitHub"
echo "=============================================="
echo ""
echo "⚠️  ВАЖЛИВО: Ваші дані будуть використані тільки для цього деплою"
echo "   і НЕ будуть збережені ніде!"
echo ""

# Перевірка Git
if ! command -v git &> /dev/null; then
    echo "❌ Git не встановлено"
    exit 1
fi

# Запит даних
echo "📝 Введіть ваші дані GitHub:"
echo ""
read -p "GitHub Username: " github_username
read -p "Назва репозиторію (Enter для 'survus-crm'): " repo_name
repo_name=${repo_name:-survus-crm}

echo ""
echo "🔐 Для автентифікації потрібен Personal Access Token"
echo "   (НЕ пароль! Токен безпечніший)"
echo ""
echo "Як створити токен:"
echo "1. Відкрийте: https://github.com/settings/tokens"
echo "2. Generate new token (classic)"
echo "3. Виберіть 'repo' (full control)"
echo "4. Generate token"
echo "5. Скопіюйте токен"
echo ""
read -sp "Personal Access Token: " github_token
echo ""
echo ""

# Формування URL
repo_url="https://${github_username}:${github_token}@github.com/${github_username}/${repo_name}.git"

# Перевірка чи існує remote
if git remote | grep -q origin; then
    echo "⚠️  Remote 'origin' вже існує. Видаляю..."
    git remote remove origin
fi

# Додавання remote
echo "📡 Підключення до GitHub..."
git remote add origin "$repo_url"

# Push
echo "📤 Відправка коду на GitHub..."
if git push -u origin main 2>&1 | grep -q "Repository not found"; then
    echo ""
    echo "❌ Репозиторій не знайдено!"
    echo ""
    echo "Створіть репозиторій вручну:"
    echo "1. Відкрийте: https://github.com/new"
    echo "2. Назва: $repo_name"
    echo "3. Private або Public"
    echo "4. НЕ додавайте README"
    echo "5. Create repository"
    echo ""
    echo "Потім запустіть скрипт знову"
    git remote remove origin
    exit 1
fi

# Очищення токену з URL (для безпеки)
git remote set-url origin "https://github.com/${github_username}/${repo_name}.git"

echo ""
echo "🎉 Успішно відправлено на GitHub!"
echo ""
echo "📋 Ваш репозиторій:"
echo "   https://github.com/${github_username}/${repo_name}"
echo ""
echo "🚀 Наступні кроки:"
echo "1. Відкрийте: https://railway.app"
echo "2. Login with GitHub"
echo "3. New Project → Deploy from GitHub repo"
echo "4. Виберіть: ${repo_name}"
echo "5. Чекайте 2-3 хвилини"
echo "6. Отримайте URL!"
echo ""
echo "✅ Готово!"
