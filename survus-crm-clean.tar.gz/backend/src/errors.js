class AuthError extends Error { constructor(msg) { super(msg); this.name = 'AuthError'; } }
class ForbiddenError extends Error { constructor(msg) { super(msg); this.name = 'ForbiddenError'; } }
class NotFoundError extends Error { constructor(msg) { super(msg); this.name = 'NotFoundError'; } }
class ValidationError extends Error { constructor(msg) { super(msg); this.name = 'ValidationError'; } }
module.exports = { AuthError, ForbiddenError, NotFoundError, ValidationError };
