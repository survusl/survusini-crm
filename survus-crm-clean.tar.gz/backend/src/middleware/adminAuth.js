const { AuthError } = require('../errors');

function adminAuthMiddleware(req, res, next) {
  const password = req.headers['x-admin-password'];
  if (!password || password !== process.env.ADMIN_PASSWORD) {
    return next(new AuthError('Invalid admin password'));
  }
  next();
}

module.exports = adminAuthMiddleware;
