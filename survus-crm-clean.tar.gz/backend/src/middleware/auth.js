const db = require('../db');
const { AuthError, ForbiddenError } = require('../errors');

function authMiddleware(req, res, next) {
  try {
    const token = req.headers['x-access-token'];
    if (!token) return next(new AuthError('No access token provided'));

    const workspace = db.prepare('SELECT * FROM workspaces WHERE access_token = ?').get(token);
    if (!workspace) return next(new AuthError('Invalid access token'));

    if (workspace.subscription_status === 'suspended') {
      return next(new ForbiddenError('Workspace is suspended'));
    }

    const now = new Date();
    const until = new Date(workspace.subscription_until);
    if (now > until) {
      return next(new ForbiddenError('Subscription expired'));
    }

    req.workspaceId = workspace.id;
    req.workspace = workspace;
    
    // Try to get user from Authorization header (for email/password auth)
    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const userId = parseInt(authHeader.split(' ')[1]);
      if (!isNaN(userId)) {
        const user = db.prepare('SELECT * FROM workspace_users WHERE id = ? AND workspace_id = ?').get(userId, workspace.id);
        if (user) {
          req.user = user;
        }
      }
    }
    
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = authMiddleware;
