const { AuthError, ForbiddenError, NotFoundError, ValidationError } = require('../errors');

function errorHandler(err, req, res, next) {
  if (err instanceof AuthError) {
    return res.status(401).json({ error: err.message, code: 'UNAUTHORIZED' });
  }
  if (err instanceof ForbiddenError) {
    return res.status(403).json({ error: err.message, code: 'FORBIDDEN' });
  }
  if (err instanceof NotFoundError) {
    return res.status(404).json({ error: err.message, code: 'NOT_FOUND' });
  }
  if (err instanceof ValidationError) {
    return res.status(422).json({ error: err.message, code: 'VALIDATION_ERROR' });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error', code: 'INTERNAL_ERROR' });
}

module.exports = errorHandler;
