const path = require('path');
const fs = require('fs');
const db = require('./db');

function columnExists(table, column) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  return cols.some(c => c.name === column);
}

function migrate() {
  const migrationsDir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();
  for (const file of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    try {
      db.exec(sql);
      console.log(`Migration applied: ${file}`);
    } catch (err) {
      if (err.message && err.message.includes('already exists')) {
        console.log(`Migration skipped (already applied): ${file}`);
      } else {
        throw err;
      }
    }
  }

  // Safe ALTER TABLE additions
  if (!columnExists('workspaces', 'subscription_plan')) {
    db.exec(`ALTER TABLE workspaces ADD COLUMN subscription_plan TEXT NOT NULL DEFAULT 'free'`);
    console.log('Added column: workspaces.subscription_plan');
  }
  if (!columnExists('workspaces', 'subscription_days_remaining')) {
    db.exec(`ALTER TABLE workspaces ADD COLUMN subscription_days_remaining INTEGER NOT NULL DEFAULT 0`);
    console.log('Added column: workspaces.subscription_days_remaining');
  }
  if (!columnExists('leads', 'amount')) {
    db.exec(`ALTER TABLE leads ADD COLUMN amount REAL DEFAULT 0`);
    console.log('Added column: leads.amount');
  }
  if (!columnExists('leads', 'lost_at')) {
    db.exec(`ALTER TABLE leads ADD COLUMN lost_at TEXT`);
    console.log('Added column: leads.lost_at');
  }
  if (!columnExists('leads', 'lost_reason')) {
    db.exec(`ALTER TABLE leads ADD COLUMN lost_reason TEXT`);
    console.log('Added column: leads.lost_reason');
  }
}

module.exports = migrate;
