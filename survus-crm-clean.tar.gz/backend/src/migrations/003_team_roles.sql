-- Team members table for PRO+ multi-account feature
CREATE TABLE IF NOT EXISTS team_members (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT,
  role TEXT NOT NULL DEFAULT 'helper', -- owner | admin | helper
  invite_token TEXT UNIQUE,
  permissions TEXT NOT NULL DEFAULT '{}',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_team_workspace ON team_members(workspace_id);
CREATE INDEX IF NOT EXISTS idx_team_invite ON team_members(invite_token);
