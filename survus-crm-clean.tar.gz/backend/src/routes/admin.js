const express = require('express');
const router = express.Router();
const adminAuthMiddleware = require('../middleware/adminAuth');
const { createWorkspace, listWorkspaces, getWorkspaceById, updateWorkspace, deleteWorkspace, getSystemStats } = require('../services/workspaceService');
const { listTemplates } = require('../services/templateService');
const { assignPlan, extendSubscription, reduceDays, cancelSubscription, getPlans } = require('../services/subscriptionService');
const { ValidationError } = require('../errors');

router.use(adminAuthMiddleware);

router.get('/workspaces', (req, res, next) => {
  try { res.json(listWorkspaces()); } catch (err) { next(err); }
});

router.post('/workspaces', (req, res, next) => {
  try {
    const { company_name, template_id, crm_config, plan, days } = req.body;
    if (!company_name) return next(new ValidationError('company_name is required'));
    if (!template_id) return next(new ValidationError('template_id is required'));
    const options = { plan: plan || 'free', days: days !== undefined ? Number(days) : 30 };
    res.status(201).json(createWorkspace(company_name, template_id, crm_config, options));
  } catch (err) { next(err); }
});

router.get('/workspaces/:id', (req, res, next) => {
  try { res.json(getWorkspaceById(req.params.id)); } catch (err) { next(err); }
});

router.patch('/workspaces/:id', (req, res, next) => {
  try { res.json(updateWorkspace(req.params.id, req.body)); } catch (err) { next(err); }
});

router.delete('/workspaces/:id', (req, res, next) => {
  try { deleteWorkspace(req.params.id); res.status(204).send(); } catch (err) { next(err); }
});

router.get('/stats', (req, res, next) => {
  try { res.json(getSystemStats()); } catch (err) { next(err); }
});

router.get('/templates', (req, res, next) => {
  try { res.json(listTemplates()); } catch (err) { next(err); }
});

router.get('/plans', async (req, res, next) => {
  try {
    const { getPlansWithPrices, getUahRate } = require('../services/subscriptionService');
    await getUahRate(); // refresh cache
    res.json(getPlansWithPrices());
  } catch (err) { next(err); }
});

router.post('/workspaces/:id/assign-plan', (req, res, next) => {
  try {
    const { plan, days } = req.body;
    if (!plan) return next(new ValidationError('plan is required'));
    if (days === undefined) return next(new ValidationError('days is required'));
    res.json(assignPlan(req.params.id, plan, days));
  } catch (err) { next(err); }
});

router.post('/workspaces/:id/extend', (req, res, next) => {
  try {
    const { days } = req.body;
    if (days === undefined) return next(new ValidationError('days is required'));
    res.json(extendSubscription(req.params.id, days));
  } catch (err) { next(err); }
});

router.post('/workspaces/:id/reduce', (req, res, next) => {
  try {
    const { days } = req.body;
    if (days === undefined) return next(new ValidationError('days is required'));
    res.json(reduceDays(req.params.id, days));
  } catch (err) { next(err); }
});

router.post('/workspaces/:id/cancel', (req, res, next) => {
  try {
    res.json(cancelSubscription(req.params.id));
  } catch (err) { next(err); }
});

module.exports = router;
