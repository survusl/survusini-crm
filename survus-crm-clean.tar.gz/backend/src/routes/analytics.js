const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const analyticsService = require('../services/analyticsService');

router.use(authMiddleware);

router.get('/growth', async (req, res, next) => {
  try {
    const period = parseInt(req.query.period) || 30;
    const metrics = analyticsService.getGrowthMetrics(req.workspaceId, period);
    res.json(metrics);
  } catch (err) {
    next(err);
  }
});

router.get('/daily/:date', async (req, res, next) => {
  try {
    const stats = analyticsService.getDailyStats(req.workspaceId, req.params.date);
    res.json(stats);
  } catch (err) {
    next(err);
  }
});

router.get('/revenue', async (req, res, next) => {
  try {
    const breakdown = analyticsService.getRevenueBreakdown(req.workspaceId);
    res.json(breakdown);
  } catch (err) {
    next(err);
  }
});

router.get('/lost-clients', async (req, res, next) => {
  try {
    const period = parseInt(req.query.period) || 30;
    const analysis = analyticsService.getLostClientsAnalysis(req.workspaceId, period);
    res.json(analysis);
  } catch (err) {
    next(err);
  }
});

router.get('/range', async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;
    const data = analyticsService.getAnalytics(req.workspaceId, startDate, endDate);
    res.json(data);
  } catch (err) {
    next(err);
  }
});

router.post('/snapshot', async (req, res, next) => {
  try {
    const snapshot = analyticsService.captureSnapshot(req.workspaceId);
    res.json(snapshot);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
