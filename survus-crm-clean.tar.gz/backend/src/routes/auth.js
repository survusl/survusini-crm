const express = require('express')
const router = express.Router()
const workspaceService = require('../services/workspaceService')
const userService = require('../services/userService')

// Валидация токена (существующий метод)
router.post('/validate', (req, res, next) => {
  try {
    const token = req.headers['x-access-token']
    if (!token) {
      return res.status(401).json({ error: 'Токен не надано' })
    }
    
    const workspace = workspaceService.getByToken(token)
    if (!workspace) {
      return res.status(401).json({ error: 'Невірний токен' })
    }
    
    res.json(workspace)
  } catch (err) {
    next(err)
  }
})

// Вход по email/password
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email та пароль обов\'язкові' })
    }
    
    const userData = await userService.authenticateUser(email, password)
    
    // Возвращаем данные workspace + user info
    res.json({
      id: userData.workspace_id,
      company_name: userData.company_name,
      access_token: userData.access_token,
      subscription_plan: userData.subscription_plan,
      subscription_until: userData.subscription_until,
      user: {
        id: userData.id,
        email: userData.email,
        name: userData.name,
        role: userData.role,
        permissions: JSON.parse(userData.permissions || '{}')
      }
    })
  } catch (err) {
    if (err.message.includes('Невірний')) {
      return res.status(401).json({ error: err.message })
    }
    next(err)
  }
})

module.exports = router
