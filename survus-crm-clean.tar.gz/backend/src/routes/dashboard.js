const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { getStats } = require('../services/dashboardService');

router.use(authMiddleware);

router.get('/stats', (req, res, next) => {
  try {
    res.json(getStats(req.workspaceId));
  } catch (err) { next(err); }
});

module.exports = router;
