const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { createLead, listLeads, getLeadById, updateLeadStatus, updateLeadAmount, markLeadAsLost } = require('../services/leadService');

router.use(authMiddleware);

router.get('/', (req, res, next) => {
  try {
    const { status } = req.query;
    const leads = listLeads(req.workspaceId, { status });
    res.json(leads);
  } catch (err) { next(err); }
});

router.post('/', (req, res, next) => {
  try {
    const lead = createLead(req.workspaceId, req.body);
    res.status(201).json(lead);
  } catch (err) { next(err); }
});

router.get('/:id', (req, res, next) => {
  try {
    const lead = getLeadById(req.workspaceId, req.params.id);
    res.json(lead);
  } catch (err) { next(err); }
});

router.patch('/:id/status', (req, res, next) => {
  try {
    const { status } = req.body;
    const lead = updateLeadStatus(req.workspaceId, req.params.id, status);
    res.json(lead);
  } catch (err) { next(err); }
});

router.patch('/:id/amount', (req, res, next) => {
  try {
    const { amount } = req.body;
    const lead = updateLeadAmount(req.workspaceId, req.params.id, amount);
    res.json(lead);
  } catch (err) { next(err); }
});

router.patch('/:id/lost', (req, res, next) => {
  try {
    const { reason } = req.body;
    const lead = markLeadAsLost(req.workspaceId, req.params.id, reason);
    res.json(lead);
  } catch (err) { next(err); }
});

module.exports = router;
