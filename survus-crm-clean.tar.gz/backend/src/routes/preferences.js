const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const preferencesService = require('../services/preferencesService');

router.use(authMiddleware);

router.get('/', async (req, res, next) => {
  try {
    const prefs = preferencesService.getPreferences(req.workspaceId);
    res.json(prefs);
  } catch (err) {
    next(err);
  }
});

router.patch('/', async (req, res, next) => {
  try {
    const prefs = preferencesService.updatePreferences(req.workspaceId, req.body);
    res.json(prefs);
  } catch (err) {
    next(err);
  }
});

router.get('/template', async (req, res, next) => {
  try {
    const custom = preferencesService.getTemplateCustomization(req.workspaceId);
    res.json(custom);
  } catch (err) {
    next(err);
  }
});

router.patch('/template', async (req, res, next) => {
  try {
    const custom = preferencesService.updateTemplateCustomization(req.workspaceId, req.body);
    res.json(custom);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
