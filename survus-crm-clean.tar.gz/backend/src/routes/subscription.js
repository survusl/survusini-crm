const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const subscriptionService = require('../services/subscriptionService');

router.use(authMiddleware);

router.get('/info', async (req, res, next) => {
  try {
    const info = subscriptionService.getSubscriptionInfo(req.workspaceId);
    res.json(info);
  } catch (err) {
    next(err);
  }
});

router.get('/status', async (req, res, next) => {
  try {
    const status = subscriptionService.getSubscriptionStatus(req.workspaceId);
    res.json(status);
  } catch (err) {
    next(err);
  }
});

router.get('/plans', async (req, res, next) => {
  try {
    await subscriptionService.getUahRate();
    res.json(subscriptionService.getPlansWithPrices());
  } catch (err) { next(err); }
});

module.exports = router;
