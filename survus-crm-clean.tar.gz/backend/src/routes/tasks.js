const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const { createTask, listTasks, completeTask } = require('../services/taskService');

router.use(authMiddleware);

router.get('/', (req, res, next) => {
  try {
    res.json(listTasks(req.workspaceId));
  } catch (err) { next(err); }
});

router.post('/', (req, res, next) => {
  try {
    const task = createTask(req.workspaceId, req.body);
    res.status(201).json(task);
  } catch (err) { next(err); }
});

router.patch('/:id/complete', (req, res, next) => {
  try {
    res.json(completeTask(req.workspaceId, req.params.id));
  } catch (err) { next(err); }
});

module.exports = router;
