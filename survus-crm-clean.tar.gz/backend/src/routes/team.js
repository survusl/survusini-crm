const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const teamService = require('../services/teamService');
const { ValidationError } = require('../errors');

router.use(authMiddleware);

router.get('/', (req, res, next) => {
  try { res.json(teamService.listMembers(req.workspaceId)); } catch (e) { next(e); }
});

router.post('/', (req, res, next) => {
  try {
    const { name, email, role } = req.body;
    res.status(201).json(teamService.addMember(req.workspaceId, { name, email, role }));
  } catch (e) { next(e); }
});

router.patch('/:id', (req, res, next) => {
  try {
    res.json(teamService.updateMember(req.workspaceId, req.params.id, req.body));
  } catch (e) { next(e); }
});

router.delete('/:id', (req, res, next) => {
  try {
    teamService.removeMember(req.workspaceId, req.params.id);
    res.status(204).send();
  } catch (e) { next(e); }
});

module.exports = router;
