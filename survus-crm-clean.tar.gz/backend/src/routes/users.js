const express = require('express')
const router = express.Router()
const userService = require('../services/userService')
const { authenticateToken } = require('../middleware/auth')

// Получить всех пользователей workspace
router.get('/', authenticateToken, async (req, res, next) => {
  try {
    const users = userService.getWorkspaceUsers(req.workspace.id)
    res.json(users)
  } catch (err) {
    next(err)
  }
})

// Создать пользователя
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    const user = await userService.createUser(req.workspace.id, req.body)
    res.status(201).json(user)
  } catch (err) {
    next(err)
  }
})

// Обновить свой профиль (должен быть перед /:id)
router.patch('/me', authenticateToken, async (req, res, next) => {
  try {
    const userId = req.user?.id
    if (!userId) {
      return res.status(401).json({ error: 'Користувача не знайдено' })
    }
    const user = await userService.updateUser(userId, req.workspace.id, req.body)
    res.json(user)
  } catch (err) {
    next(err)
  }
})

// Обновить пользователя
router.patch('/:id', authenticateToken, async (req, res, next) => {
  try {
    const user = await userService.updateUser(parseInt(req.params.id), req.workspace.id, req.body)
    res.json(user)
  } catch (err) {
    next(err)
  }
})

// Удалить пользователя
router.delete('/:id', authenticateToken, async (req, res, next) => {
  try {
    const deleted = userService.deleteUser(parseInt(req.params.id), req.workspace.id)
    if (!deleted) {
      return res.status(404).json({ error: 'Користувача не знайдено' })
    }
    res.json({ success: true })
  } catch (err) {
    next(err)
  }
})

module.exports = router
