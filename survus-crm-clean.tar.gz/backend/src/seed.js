const db = require('./db')

async function seed() {
  console.log('🌱 Seeding database...')
  
  // Проверяем есть ли уже данные
  const workspaceCount = db.prepare('SELECT COUNT(*) as count FROM workspaces').get().count
  
  if (workspaceCount > 0) {
    console.log('✅ Database already seeded')
    return
  }
  
  console.log('✅ Database is ready (empty for new workspaces)')
}

module.exports = { seed }
