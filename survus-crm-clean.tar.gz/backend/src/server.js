require('dotenv').config();
const app = require('./app');
const migrate = require('./migrate');

const PORT = process.env.PORT || 3000;

migrate();
app.listen(PORT, () => {
  console.log(`SURVUS Backend running on port ${PORT}`);
});
