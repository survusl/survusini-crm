const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { NotFoundError, ValidationError } = require('../errors');

function captureSnapshot(workspaceId) {
  const stats = db.prepare(`
    SELECT 
      COUNT(*) as total_leads,
      SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as new_leads,
      SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid_leads,
      SUM(CASE WHEN status = 'canceled' OR lost_at IS NOT NULL THEN 1 ELSE 0 END) as lost_leads,
      SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as total_revenue,
      SUM(CASE WHEN status = 'canceled' OR lost_at IS NOT NULL THEN amount ELSE 0 END) as lost_revenue
    FROM leads
    WHERE workspace_id = ?
  `).get(workspaceId);

  const id = uuidv4();
  const today = new Date().toISOString().split('T')[0];

  db.prepare(`
    INSERT INTO analytics_snapshots 
    (id, workspace_id, date, total_leads, new_leads, paid_leads, lost_leads, total_revenue, lost_revenue)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    workspaceId,
    today,
    stats.total_leads || 0,
    stats.new_leads || 0,
    stats.paid_leads || 0,
    stats.lost_leads || 0,
    stats.total_revenue || 0,
    stats.lost_revenue || 0
  );

  return db.prepare('SELECT * FROM analytics_snapshots WHERE id = ?').get(id);
}

function getAnalytics(workspaceId, startDate, endDate) {
  let query = `
    SELECT * FROM analytics_snapshots 
    WHERE workspace_id = ?
  `;
  const params = [workspaceId];

  if (startDate) {
    query += ' AND date >= ?';
    params.push(startDate);
  }

  if (endDate) {
    query += ' AND date <= ?';
    params.push(endDate);
  }

  query += ' ORDER BY date ASC';

  return db.prepare(query).all(...params);
}

function getGrowthMetrics(workspaceId, period = 30) {
  const snapshots = db.prepare(`
    SELECT * FROM analytics_snapshots 
    WHERE workspace_id = ? 
    AND date >= date('now', '-' || ? || ' days')
    ORDER BY date ASC
  `).all(workspaceId, period);

  if (snapshots.length < 2) {
    return {
      revenue_growth: 0,
      leads_growth: 0,
      conversion_rate: 0,
      lost_clients: 0,
      lost_revenue: 0
    };
  }

  const first = snapshots[0];
  const last = snapshots[snapshots.length - 1];

  const revenueGrowth = last.total_revenue - first.total_revenue;
  const leadsGrowth = last.total_leads - first.total_leads;
  const conversionRate = last.total_leads > 0 ? (last.paid_leads / last.total_leads) * 100 : 0;

  return {
    revenue_growth: revenueGrowth,
    leads_growth: leadsGrowth,
    conversion_rate: conversionRate.toFixed(2),
    lost_clients: last.lost_leads,
    lost_revenue: last.lost_revenue,
    snapshots
  };
}

function getDailyStats(workspaceId, date) {
  const snapshot = db.prepare(`
    SELECT * FROM analytics_snapshots 
    WHERE workspace_id = ? AND date = ?
  `).get(workspaceId, date);

  if (!snapshot) {
    return captureSnapshot(workspaceId);
  }

  return snapshot;
}

function getRevenueBreakdown(workspaceId) {
  const breakdown = db.prepare(`
    SELECT 
      status,
      COUNT(*) as count,
      SUM(amount) as total_amount,
      AVG(amount) as avg_amount
    FROM leads
    WHERE workspace_id = ?
    GROUP BY status
  `).all(workspaceId);

  return breakdown;
}

function getLostClientsAnalysis(workspaceId, period = 30) {
  const lostClients = db.prepare(`
    SELECT 
      id, name, username, amount, lost_at, lost_reason, status
    FROM leads
    WHERE workspace_id = ? 
    AND (lost_at IS NOT NULL OR status = 'canceled')
    AND lost_at >= date('now', '-' || ? || ' days')
    ORDER BY lost_at DESC
  `).all(workspaceId, period);

  const totalLost = lostClients.reduce((sum, client) => sum + (client.amount || 0), 0);

  return {
    lost_clients: lostClients,
    total_lost_count: lostClients.length,
    total_lost_revenue: totalLost
  };
}

module.exports = {
  captureSnapshot,
  getAnalytics,
  getGrowthMetrics,
  getDailyStats,
  getRevenueBreakdown,
  getLostClientsAnalysis
};
