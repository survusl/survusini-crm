const db = require('../db');

function getStats(workspaceId) {
  const total = db.prepare('SELECT COUNT(*) as count FROM leads WHERE workspace_id = ?').get(workspaceId).count;
  const paid = db.prepare("SELECT COUNT(*) as count FROM leads WHERE workspace_id = ? AND status = 'paid'").get(workspaceId).count;
  const newCount = db.prepare("SELECT COUNT(*) as count FROM leads WHERE workspace_id = ? AND status = 'new'").get(workspaceId).count;
  const replied = db.prepare("SELECT COUNT(*) as count FROM leads WHERE workspace_id = ? AND status = 'replied'").get(workspaceId).count;
  const canceled = db.prepare("SELECT COUNT(*) as count FROM leads WHERE workspace_id = ? AND status = 'canceled'").get(workspaceId).count;
  return { total, paid_count: paid, new_count: newCount, replied_count: replied, canceled_count: canceled };
}

module.exports = { getStats };
