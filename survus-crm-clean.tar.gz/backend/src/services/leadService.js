const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { NotFoundError, ValidationError, ForbiddenError } = require('../errors');

const VALID_STATUSES = ['new', 'replied', 'paid', 'canceled'];

function createLead(workspaceId, { name, username, note, amount }) {
  if (!name || !name.trim()) throw new ValidationError('name is required');
  if (!username || !username.trim()) throw new ValidationError('username is required');

  const id = uuidv4();
  db.prepare(`
    INSERT INTO leads (id, workspace_id, name, username, note, amount, status)
    VALUES (?, ?, ?, ?, ?, ?, 'new')
  `).run(id, workspaceId, name.trim(), username.trim(), note || null, amount || 0);

  return db.prepare('SELECT * FROM leads WHERE id = ?').get(id);
}

function listLeads(workspaceId, { status } = {}) {
  if (status) {
    return db.prepare('SELECT * FROM leads WHERE workspace_id = ? AND status = ? ORDER BY created_at DESC').all(workspaceId, status);
  }
  return db.prepare('SELECT * FROM leads WHERE workspace_id = ? ORDER BY created_at DESC').all(workspaceId);
}

function getLeadById(workspaceId, leadId) {
  const lead = db.prepare('SELECT * FROM leads WHERE id = ? AND workspace_id = ?').get(leadId, workspaceId);
  if (!lead) throw new NotFoundError(`Lead ${leadId} not found`);

  const history = db.prepare('SELECT * FROM lead_status_history WHERE lead_id = ? ORDER BY changed_at ASC').all(leadId);
  return { ...lead, status_history: history };
}

function updateLeadStatus(workspaceId, leadId, newStatus) {
  if (!VALID_STATUSES.includes(newStatus)) {
    throw new ValidationError(`Invalid status: ${newStatus}. Must be one of: ${VALID_STATUSES.join(', ')}`);
  }

  const lead = db.prepare('SELECT * FROM leads WHERE id = ? AND workspace_id = ?').get(leadId, workspaceId);
  if (!lead) throw new NotFoundError(`Lead ${leadId} not found`);

  const historyId = uuidv4();
  db.prepare(`
    INSERT INTO lead_status_history (id, lead_id, workspace_id, old_status, new_status)
    VALUES (?, ?, ?, ?, ?)
  `).run(historyId, leadId, workspaceId, lead.status, newStatus);

  db.prepare('UPDATE leads SET status = ?, updated_at = datetime(\'now\') WHERE id = ?').run(newStatus, leadId);

  return getLeadById(workspaceId, leadId);
}

function updateLeadAmount(workspaceId, leadId, amount) {
  const lead = db.prepare('SELECT * FROM leads WHERE id = ? AND workspace_id = ?').get(leadId, workspaceId);
  if (!lead) throw new NotFoundError(`Lead ${leadId} not found`);

  db.prepare('UPDATE leads SET amount = ?, updated_at = datetime(\'now\') WHERE id = ?').run(amount, leadId);

  return getLeadById(workspaceId, leadId);
}

function markLeadAsLost(workspaceId, leadId, reason) {
  const lead = db.prepare('SELECT * FROM leads WHERE id = ? AND workspace_id = ?').get(leadId, workspaceId);
  if (!lead) throw new NotFoundError(`Lead ${leadId} not found`);

  db.prepare(`
    UPDATE leads 
    SET lost_at = datetime('now'), 
        lost_reason = ?,
        status = 'canceled',
        updated_at = datetime('now') 
    WHERE id = ?
  `).run(reason || null, leadId);

  return getLeadById(workspaceId, leadId);
}

module.exports = { createLead, listLeads, getLeadById, updateLeadStatus, updateLeadAmount, markLeadAsLost };
