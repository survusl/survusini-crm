const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { NotFoundError } = require('../errors');

function getPreferences(workspaceId) {
  let prefs = db.prepare('SELECT * FROM user_preferences WHERE workspace_id = ?').get(workspaceId);
  
  if (!prefs) {
    const id = uuidv4();
    db.prepare(`
      INSERT INTO user_preferences (id, workspace_id, theme_color, sidebar_layout, enabled_features, custom_config)
      VALUES (?, ?, '#22c55e', 'default', '[]', '{}')
    `).run(id, workspaceId);
    
    prefs = db.prepare('SELECT * FROM user_preferences WHERE id = ?').get(id);
  }

  return {
    ...prefs,
    enabled_features: JSON.parse(prefs.enabled_features),
    custom_config: JSON.parse(prefs.custom_config)
  };
}

function updatePreferences(workspaceId, updates) {
  const prefs = getPreferences(workspaceId);
  
  const allowed = ['theme_color', 'sidebar_layout', 'enabled_features', 'custom_config'];
  const updateFields = [];
  const values = [];

  for (const key of allowed) {
    if (updates[key] !== undefined) {
      updateFields.push(`${key} = ?`);
      if (key === 'enabled_features' || key === 'custom_config') {
        values.push(JSON.stringify(updates[key]));
      } else {
        values.push(updates[key]);
      }
    }
  }

  if (updateFields.length > 0) {
    updateFields.push('updated_at = datetime(\'now\')');
    values.push(workspaceId);
    
    db.prepare(`
      UPDATE user_preferences 
      SET ${updateFields.join(', ')}
      WHERE workspace_id = ?
    `).run(...values);
  }

  return getPreferences(workspaceId);
}

function getTemplateCustomization(workspaceId) {
  let custom = db.prepare('SELECT * FROM template_customizations WHERE workspace_id = ?').get(workspaceId);
  
  if (!custom) {
    const id = uuidv4();
    db.prepare(`
      INSERT INTO template_customizations (id, workspace_id, tabs_config, blocks_config, layout_config)
      VALUES (?, ?, '[]', '[]', '{}')
    `).run(id, workspaceId);
    
    custom = db.prepare('SELECT * FROM template_customizations WHERE id = ?').get(id);
  }

  return {
    ...custom,
    tabs_config: JSON.parse(custom.tabs_config),
    blocks_config: JSON.parse(custom.blocks_config),
    layout_config: JSON.parse(custom.layout_config)
  };
}

function updateTemplateCustomization(workspaceId, updates) {
  const custom = getTemplateCustomization(workspaceId);
  
  const allowed = ['tabs_config', 'blocks_config', 'layout_config'];
  const updateFields = [];
  const values = [];

  for (const key of allowed) {
    if (updates[key] !== undefined) {
      updateFields.push(`${key} = ?`);
      values.push(JSON.stringify(updates[key]));
    }
  }

  if (updateFields.length > 0) {
    updateFields.push('updated_at = datetime(\'now\')');
    values.push(workspaceId);
    
    db.prepare(`
      UPDATE template_customizations 
      SET ${updateFields.join(', ')}
      WHERE workspace_id = ?
    `).run(...values);
  }

  return getTemplateCustomization(workspaceId);
}

module.exports = {
  getPreferences,
  updatePreferences,
  getTemplateCustomization,
  updateTemplateCustomization
};
