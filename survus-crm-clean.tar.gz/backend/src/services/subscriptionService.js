const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { NotFoundError, ValidationError } = require('../errors');

// Prices in USD
const PLANS = {
  free:     { name: 'Free',  price_usd: 0,  features: ['basic_crm', 'up_to_100_leads', 'basic_analytics'] },
  pro:      { name: 'PRO',   price_usd: 20, features: ['unlimited_leads', 'advanced_analytics', 'custom_themes', 'priority_support', 'export_data'] },
  pro_plus: { name: 'PRO+',  price_usd: 35, features: ['unlimited_leads', 'advanced_analytics', 'custom_themes', 'priority_support', 'export_data', 'ai_insights', 'custom_integrations', 'white_label', 'api_access'] }
};

// Fetch live UAH rate from NBU (cached for 1h)
let _uahRate = null;
let _uahRateTs = 0;
async function getUahRate() {
  const now = Date.now();
  if (_uahRate && now - _uahRateTs < 3600_000) return _uahRate;
  try {
    const res = await fetch('https://bank.gov.ua/NBUStatService/v1/statdataservice/exchange?valcode=USD&json');
    const data = await res.json();
    _uahRate = data[0]?.rate || 41;
  } catch {
    _uahRate = 41; // fallback
  }
  _uahRateTs = now;
  return _uahRate;
}

function getPlans() { return PLANS; }
function getPlanFeatures(planId) { return PLANS[planId] || PLANS.free; }

// Returns prices with UAH conversion (sync, uses cached rate)
function getPlansWithPrices() {
  const rate = _uahRate || 41;
  return Object.entries(PLANS).map(([id, p]) => ({
    id,
    ...p,
    price_uah: Math.round(p.price_usd * rate),
    uah_rate: rate
  }));
}

// Warm up rate on module load
getUahRate().catch(() => {});

function assignPlan(workspaceId, planId, days) {
  if (!PLANS[planId]) throw new ValidationError(`Invalid plan: ${planId}`);
  if (days < 0) throw new ValidationError('Days must be positive');

  const workspace = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
  if (!workspace) throw new NotFoundError(`Workspace ${workspaceId} not found`);

  db.prepare(`
    UPDATE workspaces
    SET subscription_plan = ?,
        subscription_days_remaining = ?,
        subscription_status = 'active',
        subscription_until = datetime('now', '+' || ? || ' days')
    WHERE id = ?
  `).run(planId, days, days, workspaceId);

  return db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
}

function extendSubscription(workspaceId, additionalDays) {
  if (additionalDays < 0) throw new ValidationError('Additional days must be positive');

  const workspace = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
  if (!workspace) throw new NotFoundError(`Workspace ${workspaceId} not found`);

  const newDays = (workspace.subscription_days_remaining || 0) + additionalDays;
  db.prepare(`
    UPDATE workspaces
    SET subscription_days_remaining = ?,
        subscription_status = 'active',
        subscription_until = datetime('now', '+' || ? || ' days')
    WHERE id = ?
  `).run(newDays, newDays, workspaceId);

  return db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
}

function reduceDays(workspaceId, daysToReduce) {
  if (daysToReduce < 0) throw new ValidationError('Days to reduce must be positive');

  const workspace = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
  if (!workspace) throw new NotFoundError(`Workspace ${workspaceId} not found`);

  const newDays = Math.max(0, (workspace.subscription_days_remaining || 0) - daysToReduce);
  db.prepare(`
    UPDATE workspaces
    SET subscription_days_remaining = ?,
        subscription_until = datetime('now', '+' || ? || ' days')
    WHERE id = ?
  `).run(newDays, newDays, workspaceId);

  return db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
}

function cancelSubscription(workspaceId) {
  const workspace = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
  if (!workspace) throw new NotFoundError(`Workspace ${workspaceId} not found`);

  db.prepare(`
    UPDATE workspaces
    SET subscription_status = 'suspended',
        subscription_days_remaining = 0
    WHERE id = ?
  `).run(workspaceId);

  return db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
}

function getSubscriptionInfo(workspaceId) {
  const workspace = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
  if (!workspace) throw new NotFoundError(`Workspace ${workspaceId} not found`);

  const plan = getPlanFeatures(workspace.subscription_plan || 'free');
  const rate = _uahRate || 41;

  return {
    plan: workspace.subscription_plan || 'free',
    planName: plan.name,
    price_usd: plan.price_usd,
    price_uah: Math.round(plan.price_usd * rate),
    uah_rate: rate,
    features: plan.features,
    daysRemaining: workspace.subscription_days_remaining || 0,
    subscriptionUntil: workspace.subscription_until,
    status: workspace.subscription_status
  };
}

function getSubscriptionStatus(workspaceId) {
  const workspace = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(workspaceId);
  if (!workspace) throw new NotFoundError(`Workspace ${workspaceId} not found`);

  const plan = getPlanFeatures(workspace.subscription_plan || 'free');
  const endsAt = workspace.subscription_until;
  
  let daysUntilExpiry = 0;
  let status = 'active';
  
  if (endsAt) {
    const now = new Date();
    const expiryDate = new Date(endsAt);
    const diffTime = expiryDate - now;
    daysUntilExpiry = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry <= 0) {
      status = 'expired';
      daysUntilExpiry = 0;
    }
  }

  return {
    plan: workspace.subscription_plan || 'free',
    planName: plan.name,
    features: plan.features,
    status,
    endsAt,
    daysUntilExpiry
  };
}

module.exports = {
  getPlans,
  getPlansWithPrices,
  getPlanFeatures,
  assignPlan,
  extendSubscription,
  reduceDays,
  cancelSubscription,
  getSubscriptionInfo,
  getSubscriptionStatus,
  getUahRate
};
