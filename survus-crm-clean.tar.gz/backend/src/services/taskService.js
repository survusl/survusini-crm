const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { NotFoundError, ValidationError } = require('../errors');

function createTask(workspaceId, { title, due_date, lead_id }) {
  if (!title || !title.trim()) throw new ValidationError('title is required');
  if (!due_date) throw new ValidationError('due_date is required');

  const id = uuidv4();
  const isOverdue = new Date(due_date) < new Date() ? 1 : 0;

  db.prepare(`
    INSERT INTO tasks (id, workspace_id, title, due_date, lead_id, is_overdue)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(id, workspaceId, title.trim(), due_date, lead_id || null, isOverdue);

  return db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
}

function listTasks(workspaceId) {
  const tasks = db.prepare('SELECT * FROM tasks WHERE workspace_id = ? ORDER BY due_date ASC').all(workspaceId);
  const now = new Date();
  return tasks.map(t => ({
    ...t,
    is_overdue: !t.is_completed && new Date(t.due_date) < now ? 1 : t.is_overdue
  }));
}

function completeTask(workspaceId, taskId) {
  const task = db.prepare('SELECT * FROM tasks WHERE id = ? AND workspace_id = ?').get(taskId, workspaceId);
  if (!task) throw new NotFoundError(`Task ${taskId} not found`);

  db.prepare('UPDATE tasks SET is_completed = 1 WHERE id = ?').run(taskId);
  return db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
}

module.exports = { createTask, listTasks, completeTask };
