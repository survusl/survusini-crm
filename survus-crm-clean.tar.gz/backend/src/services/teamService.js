const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { NotFoundError, ValidationError, ForbiddenError } = require('../errors');

const ROLES = ['owner', 'admin', 'helper'];

const DEFAULT_PERMISSIONS = {
  owner:  { leads: 'edit', tasks: 'edit', reports: 'view', settings: 'edit', team: 'edit' },
  admin:  { leads: 'edit', tasks: 'edit', reports: 'view', settings: 'view', team: 'view' },
  helper: { leads: 'view', tasks: 'edit', reports: 'none', settings: 'none', team: 'none' },
};

function listMembers(workspaceId) {
  return db.prepare('SELECT * FROM team_members WHERE workspace_id = ? ORDER BY created_at ASC').all(workspaceId)
    .map(m => ({ ...m, permissions: JSON.parse(m.permissions) }));
}

function addMember(workspaceId, { name, email, role }) {
  if (!name?.trim()) throw new ValidationError('name is required');
  if (!ROLES.includes(role)) throw new ValidationError(`role must be one of: ${ROLES.join(', ')}`);
  if (role === 'owner') throw new ValidationError('Cannot add another owner');

  const id = uuidv4();
  const inviteToken = uuidv4();
  const permissions = DEFAULT_PERMISSIONS[role] || DEFAULT_PERMISSIONS.helper;

  db.prepare(`
    INSERT INTO team_members (id, workspace_id, name, email, role, invite_token, permissions)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, workspaceId, name.trim(), email || null, role, inviteToken, JSON.stringify(permissions));

  return getMember(workspaceId, id);
}

function getMember(workspaceId, memberId) {
  const m = db.prepare('SELECT * FROM team_members WHERE id = ? AND workspace_id = ?').get(memberId, workspaceId);
  if (!m) throw new NotFoundError('Member not found');
  return { ...m, permissions: JSON.parse(m.permissions) };
}

function updateMember(workspaceId, memberId, updates) {
  const member = getMember(workspaceId, memberId);
  if (member.role === 'owner') throw new ForbiddenError('Cannot modify owner');

  const allowed = ['name', 'email', 'role', 'permissions', 'is_active'];
  const fields = []; const values = [];

  for (const key of allowed) {
    if (updates[key] !== undefined) {
      fields.push(`${key} = ?`);
      values.push(key === 'permissions' ? JSON.stringify(updates[key]) : updates[key]);
    }
  }

  if (fields.length === 0) return member;
  values.push(memberId, workspaceId);
  db.prepare(`UPDATE team_members SET ${fields.join(', ')} WHERE id = ? AND workspace_id = ?`).run(...values);
  return getMember(workspaceId, memberId);
}

function removeMember(workspaceId, memberId) {
  const member = getMember(workspaceId, memberId);
  if (member.role === 'owner') throw new ForbiddenError('Cannot remove owner');
  db.prepare('DELETE FROM team_members WHERE id = ? AND workspace_id = ?').run(memberId, workspaceId);
}

function ensureOwner(workspaceId) {
  const existing = db.prepare("SELECT id FROM team_members WHERE workspace_id = ? AND role = 'owner'").get(workspaceId);
  if (!existing) {
    const id = uuidv4();
    db.prepare(`
      INSERT INTO team_members (id, workspace_id, name, role, permissions)
      VALUES (?, ?, 'Власник', 'owner', ?)
    `).run(id, workspaceId, JSON.stringify(DEFAULT_PERMISSIONS.owner));
  }
}

module.exports = { listMembers, addMember, getMember, updateMember, removeMember, ensureOwner, ROLES, DEFAULT_PERMISSIONS };
