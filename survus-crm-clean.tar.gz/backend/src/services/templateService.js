const path = require('path');
const fs = require('fs');

const TEMPLATES_DIR = path.join(__dirname, '../templates');
const TEMPLATE_IDS = ['instagram_sales', 'beauty', 'services', 'simple_sales'];

function getTemplate(templateId) {
  if (!TEMPLATE_IDS.includes(templateId)) return null;
  const filePath = path.join(TEMPLATES_DIR, `${templateId}.json`);
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function listTemplates() {
  return TEMPLATE_IDS.map(id => getTemplate(id));
}

module.exports = { getTemplate, listTemplates };
