const db = require('../db')
const bcrypt = require('bcryptjs')

// Получить всех пользователей workspace
function getWorkspaceUsers(workspaceId) {
  return db.prepare(`
    SELECT id, workspace_id, email, name, role, permissions, is_active, created_at, last_login
    FROM workspace_users
    WHERE workspace_id = ?
    ORDER BY created_at DESC
  `).all(workspaceId)
}

// Создать пользователя
async function createUser(workspaceId, data) {
  const { email, password, name, role = 'member', permissions = {} } = data
  
  // Проверка существования
  const existing = db.prepare('SELECT id FROM workspace_users WHERE workspace_id = ? AND email = ?').get(workspaceId, email)
  if (existing) {
    throw new Error('Користувач з таким email вже існує')
  }
  
  // Хешируем пароль
  const passwordHash = await bcrypt.hash(password, 10)
  
  const result = db.prepare(`
    INSERT INTO workspace_users (workspace_id, email, password_hash, name, role, permissions)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(workspaceId, email, passwordHash, name, role, JSON.stringify(permissions))
  
  return {
    id: result.lastInsertRowid,
    workspace_id: workspaceId,
    email,
    name,
    role,
    permissions,
    is_active: 1
  }
}

// Обновить пользователя
async function updateUser(userId, workspaceId, data) {
  const { email, password, name, role, permissions, is_active } = data
  
  const user = db.prepare('SELECT * FROM workspace_users WHERE id = ? AND workspace_id = ?').get(userId, workspaceId)
  if (!user) {
    throw new Error('Користувача не знайдено')
  }
  
  const updates = []
  const values = []
  
  if (email !== undefined) {
    updates.push('email = ?')
    values.push(email)
  }
  if (password) {
    const passwordHash = await bcrypt.hash(password, 10)
    updates.push('password_hash = ?')
    values.push(passwordHash)
  }
  if (name !== undefined) {
    updates.push('name = ?')
    values.push(name)
  }
  if (role !== undefined) {
    updates.push('role = ?')
    values.push(role)
  }
  if (permissions !== undefined) {
    updates.push('permissions = ?')
    values.push(JSON.stringify(permissions))
  }
  if (is_active !== undefined) {
    updates.push('is_active = ?')
    values.push(is_active ? 1 : 0)
  }
  
  if (updates.length === 0) return user
  
  values.push(userId, workspaceId)
  
  db.prepare(`
    UPDATE workspace_users
    SET ${updates.join(', ')}
    WHERE id = ? AND workspace_id = ?
  `).run(...values)
  
  return db.prepare('SELECT id, workspace_id, email, name, role, permissions, is_active FROM workspace_users WHERE id = ?').get(userId)
}

// Удалить пользователя
function deleteUser(userId, workspaceId) {
  const result = db.prepare('DELETE FROM workspace_users WHERE id = ? AND workspace_id = ?').run(userId, workspaceId)
  return result.changes > 0
}

// Аутентификация по email/password
async function authenticateUser(email, password) {
  const user = db.prepare(`
    SELECT wu.*, w.company_name, w.access_token, w.subscription_plan, w.subscription_until
    FROM workspace_users wu
    JOIN workspaces w ON wu.workspace_id = w.id
    WHERE wu.email = ? AND wu.is_active = 1
  `).get(email)
  
  if (!user) {
    throw new Error('Невірний email або пароль')
  }
  
  const isValid = await bcrypt.compare(password, user.password_hash)
  if (!isValid) {
    throw new Error('Невірний email або пароль')
  }
  
  // Обновляем last_login
  db.prepare('UPDATE workspace_users SET last_login = datetime("now") WHERE id = ?').run(user.id)
  
  // Возвращаем данные без password_hash
  const { password_hash, ...userData } = user
  return userData
}

module.exports = {
  getWorkspaceUsers,
  createUser,
  updateUser,
  deleteUser,
  authenticateUser
}
