const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const { getTemplate } = require('./templateService');
const { NotFoundError, ValidationError } = require('../errors');

function createWorkspace(name, templateId, customConfig, options = {}) {
  const template = getTemplate(templateId);
  if (!template) throw new ValidationError(`Unknown template: ${templateId}`);

  const id = uuidv4();
  const accessToken = uuidv4();
  const crmConfig = JSON.stringify(customConfig || template);

  const plan = options.plan || 'free';
  const days = options.days !== undefined ? options.days : 30;
  const subscriptionUntil = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();

  db.prepare(`
    INSERT INTO workspaces
      (id, company_name, access_token, template_id, crm_config,
       subscription_status, subscription_until, subscription_plan, subscription_days_remaining)
    VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?)
  `).run(id, name, accessToken, templateId, crmConfig, subscriptionUntil, plan, days);

  return db.prepare('SELECT * FROM workspaces WHERE id = ?').get(id);
}

function getWorkspaceByToken(token) {
  return db.prepare('SELECT * FROM workspaces WHERE access_token = ?').get(token);
}

function getWorkspaceById(id) {
  const ws = db.prepare('SELECT * FROM workspaces WHERE id = ?').get(id);
  if (!ws) throw new NotFoundError(`Workspace ${id} not found`);
  return ws;
}

function listWorkspaces() {
  return db.prepare(`
    SELECT w.*, COUNT(l.id) as leads_count
    FROM workspaces w
    LEFT JOIN leads l ON l.workspace_id = w.id
    GROUP BY w.id
    ORDER BY w.created_at DESC
  `).all();
}

function updateWorkspace(id, data) {
  const ws = getWorkspaceById(id);
  const allowed = [
    'company_name', 'subscription_status', 'subscription_until',
    'crm_config', 'subscription_plan', 'subscription_days_remaining'
  ];
  const updates = [];
  const values = [];

  for (const key of allowed) {
    if (data[key] !== undefined) {
      updates.push(`${key} = ?`);
      values.push(key === 'crm_config' && typeof data[key] === 'object'
        ? JSON.stringify(data[key])
        : data[key]);
    }
  }

  if (updates.length === 0) return ws;
  values.push(id);
  db.prepare(`UPDATE workspaces SET ${updates.join(', ')} WHERE id = ?`).run(...values);
  return db.prepare('SELECT * FROM workspaces WHERE id = ?').get(id);
}

function deleteWorkspace(id) {
  getWorkspaceById(id);
  db.prepare('DELETE FROM workspaces WHERE id = ?').run(id);
}

function getSystemStats() {
  const total    = db.prepare('SELECT COUNT(*) as count FROM workspaces').get().count;
  const active   = db.prepare("SELECT COUNT(*) as count FROM workspaces WHERE subscription_status = 'active'").get().count;
  const totalLeads = db.prepare('SELECT COUNT(*) as count FROM leads').get().count;
  const revenue  = db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM leads WHERE status='paid'").get().total;
  return { total_workspaces: total, active_workspaces: active, total_leads: totalLeads, total_revenue: revenue };
}

module.exports = {
  createWorkspace, getWorkspaceByToken, getWorkspaceById,
  listWorkspaces, updateWorkspace, deleteWorkspace, getSystemStats
};
