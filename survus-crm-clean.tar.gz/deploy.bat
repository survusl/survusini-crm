@echo off
REM 🚀 SURVUS CRM - Quick Deploy Script for Windows
REM Автоматичний деплой на Git та Railway

echo 🚀 SURVUS CRM - Деплой на сервер
echo ==================================
echo.

REM Перевірка Git
where git >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ Git не встановлено. Встановіть Git: https://git-scm.com/
    pause
    exit /b 1
)

echo ✅ Git встановлено
echo.

REM Ініціалізація Git (якщо потрібно)
if not exist .git (
    echo 📦 Ініціалізація Git репозиторію...
    git init
    echo ✅ Git ініціалізовано
) else (
    echo ✅ Git репозиторій вже існує
)

REM Додавання файлів
echo.
echo 📝 Додавання файлів до Git...
git add .

REM Коміт
echo.
set /p commit_message="💬 Введіть повідомлення коміту (Enter для 'Update'): "
if "%commit_message%"=="" set commit_message=Update
git commit -m "%commit_message%"
echo ✅ Коміт створено

REM Перевірка remote
echo.
git remote | findstr origin >nul
if %ERRORLEVEL% EQU 0 (
    echo ✅ Remote 'origin' вже налаштовано
    echo 📤 Відправка на GitHub...
    git push origin main || git push origin master
) else (
    echo ⚠️  Remote 'origin' не налаштовано
    echo.
    echo Створіть репозиторій на GitHub:
    echo 1. Відкрийте https://github.com/new
    echo 2. Створіть новий репозиторій
    echo 3. Скопіюйте URL репозиторію
    echo.
    set /p repo_url="📎 Вставте URL репозиторію (https://github.com/username/repo.git): "
    
    if not "%repo_url%"=="" (
        git remote add origin "%repo_url%"
        git branch -M main
        git push -u origin main
        echo ✅ Код відправлено на GitHub!
    ) else (
        echo ❌ URL не введено
        pause
        exit /b 1
    )
)

echo.
echo 🎉 Деплой завершено!
echo.
echo 📋 Наступні кроки:
echo 1. Відкрийте https://railway.app
echo 2. Натисніть 'New Project' → 'Deploy from GitHub repo'
echo 3. Виберіть ваш репозиторій
echo 4. Railway автоматично задеплоїть проєкт!
echo.
echo 📖 Детальна інструкція: DEPLOYMENT_GUIDE.md
echo.
pause
