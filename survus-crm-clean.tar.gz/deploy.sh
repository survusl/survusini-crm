#!/bin/bash

# 🚀 SURVUS CRM - Quick Deploy Script
# Автоматичний деплой на Git та Railway

echo "🚀 SURVUS CRM - Деплой на сервер"
echo "=================================="
echo ""

# Перевірка Git
if ! command -v git &> /dev/null; then
    echo "❌ Git не встановлено. Встановіть Git: https://git-scm.com/"
    exit 1
fi

echo "✅ Git встановлено"
echo ""

# Ініціалізація Git (якщо потрібно)
if [ ! -d .git ]; then
    echo "📦 Ініціалізація Git репозиторію..."
    git init
    echo "✅ Git ініціалізовано"
else
    echo "✅ Git репозиторій вже існує"
fi

# Додавання файлів
echo ""
echo "📝 Додавання файлів до Git..."
git add .

# Коміт
echo ""
read -p "💬 Введіть повідомлення коміту (Enter для 'Update'): " commit_message
commit_message=${commit_message:-"Update"}
git commit -m "$commit_message"
echo "✅ Коміт створено"

# Перевірка remote
echo ""
if git remote | grep -q origin; then
    echo "✅ Remote 'origin' вже налаштовано"
    echo "📤 Відправка на GitHub..."
    git push origin main || git push origin master
else
    echo "⚠️  Remote 'origin' не налаштовано"
    echo ""
    echo "Створіть репозиторій на GitHub:"
    echo "1. Відкрийте https://github.com/new"
    echo "2. Створіть новий репозиторій"
    echo "3. Скопіюйте URL репозиторію"
    echo ""
    read -p "📎 Вставте URL репозиторію (https://github.com/username/repo.git): " repo_url
    
    if [ -n "$repo_url" ]; then
        git remote add origin "$repo_url"
        git branch -M main
        git push -u origin main
        echo "✅ Код відправлено на GitHub!"
    else
        echo "❌ URL не введено"
        exit 1
    fi
fi

echo ""
echo "🎉 Деплой завершено!"
echo ""
echo "📋 Наступні кроки:"
echo "1. Відкрийте https://railway.app"
echo "2. Натисніть 'New Project' → 'Deploy from GitHub repo'"
echo "3. Виберіть ваш репозиторій"
echo "4. Railway автоматично задеплоїть проєкт!"
echo ""
echo "📖 Детальна інструкція: DEPLOYMENT_GUIDE.md"
echo ""
