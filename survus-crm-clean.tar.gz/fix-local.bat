@echo off
REM 🔧 SURVUS CRM - Fix Local Server (Windows)
REM Виправлення проблем з локальним сервером

echo 🔧 SURVUS CRM - Виправлення локального сервера
echo ==============================================
echo.

REM Зупинити всі процеси Node.js
echo 🛑 Зупинка всіх Node.js процесів...
taskkill /F /IM node.exe 2>nul
timeout /t 2 >nul
echo ✅ Процеси зупинено
echo.

REM Видалити node_modules
echo 🗑️  Видалення node_modules...
if exist node_modules rmdir /s /q node_modules
if exist backend\node_modules rmdir /s /q backend\node_modules
if exist frontend\node_modules rmdir /s /q frontend\node_modules
if exist admin\node_modules rmdir /s /q admin\node_modules
echo ✅ node_modules видалено
echo.

REM Видалити lock файли
echo 🗑️  Видалення lock файлів...
if exist package-lock.json del /f package-lock.json
if exist backend\package-lock.json del /f backend\package-lock.json
if exist frontend\package-lock.json del /f frontend\package-lock.json
if exist admin\package-lock.json del /f admin\package-lock.json
echo ✅ Lock файли видалено
echo.

REM Очистити кеш npm
echo 🧹 Очищення npm кешу...
npm cache clean --force
echo ✅ Кеш очищено
echo.

REM Видалити базу даних
echo 🗑️  Видалення старої бази даних...
if exist backend\data\survus.db del /f backend\data\survus.db
if exist backend\data\survus.db-shm del /f backend\data\survus.db-shm
if exist backend\data\survus.db-wal del /f backend\data\survus.db-wal
if exist data\survus.db del /f data\survus.db
echo ✅ База даних видалена
echo.

REM Встановити залежності
echo 📦 Встановлення залежностей...
echo    Root...
call npm install
echo    Backend...
cd backend
call npm install
cd ..
echo    Frontend...
cd frontend
call npm install
cd ..
echo    Admin...
cd admin
call npm install
cd ..
echo ✅ Залежності встановлено
echo.

REM Запустити міграції
echo 🗄️  Запуск міграцій бази даних...
cd backend
node src\migrate.js
cd ..
echo ✅ Міграції виконано
echo.

echo 🎉 Виправлення завершено!
echo.
echo 📋 Тепер запустіть сервер:
echo    npm start
echo.
echo або окремо:
echo    npm run dev:backend   # Backend на :3001
echo    npm run dev:frontend  # Frontend на :5173
echo    npm run dev:admin     # Admin на :5174
echo.
pause
