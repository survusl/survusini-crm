#!/bin/bash

# 🔧 SURVUS CRM - Fix Local Server
# Виправлення проблем з локальним сервером

echo "🔧 SURVUS CRM - Виправлення локального сервера"
echo "=============================================="
echo ""

# Зупинити всі процеси Node.js
echo "🛑 Зупинка всіх Node.js процесів..."
pkill -f node || true
sleep 2
echo "✅ Процеси зупинено"
echo ""

# Видалити node_modules
echo "🗑️  Видалення node_modules..."
rm -rf node_modules
rm -rf backend/node_modules
rm -rf frontend/node_modules
rm -rf admin/node_modules
echo "✅ node_modules видалено"
echo ""

# Видалити lock файли
echo "🗑️  Видалення lock файлів..."
rm -f package-lock.json
rm -f backend/package-lock.json
rm -f frontend/package-lock.json
rm -f admin/package-lock.json
echo "✅ Lock файли видалено"
echo ""

# Очистити кеш npm
echo "🧹 Очищення npm кешу..."
npm cache clean --force
echo "✅ Кеш очищено"
echo ""

# Видалити базу даних
echo "🗑️  Видалення старої бази даних..."
rm -f backend/data/survus.db
rm -f backend/data/survus.db-shm
rm -f backend/data/survus.db-wal
rm -f data/survus.db
echo "✅ База даних видалена"
echo ""

# Встановити залежності
echo "📦 Встановлення залежностей..."
echo "   Root..."
npm install
echo "   Backend..."
cd backend && npm install && cd ..
echo "   Frontend..."
cd frontend && npm install && cd ..
echo "   Admin..."
cd admin && npm install && cd ..
echo "✅ Залежності встановлено"
echo ""

# Запустити міграції
echo "🗄️  Запуск міграцій бази даних..."
cd backend
node src/migrate.js
cd ..
echo "✅ Міграції виконано"
echo ""

echo "🎉 Виправлення завершено!"
echo ""
echo "📋 Тепер запустіть сервер:"
echo "   npm start"
echo ""
echo "або окремо:"
echo "   npm run dev:backend   # Backend на :3001"
echo "   npm run dev:frontend  # Frontend на :5173"
echo "   npm run dev:admin     # Admin на :5174"
echo ""
