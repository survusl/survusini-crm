import axios from 'axios'

const client = axios.create({ baseURL: '/api' })

client.interceptors.request.use(config => {
  const token = localStorage.getItem('survus_token')
  if (token) config.headers['X-Access-Token'] = token
  
  // Add user id for email/password authenticated users
  try {
    const user = JSON.parse(localStorage.getItem('survus_user') || '{}')
    if (user.id) {
      config.headers['Authorization'] = `Bearer ${user.id}`
    }
  } catch {}
  
  return config
})

export const api = client
export default client
