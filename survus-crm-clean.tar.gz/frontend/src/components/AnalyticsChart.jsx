import { useState, useEffect } from 'react';
import { api } from '../api/client';
import Icon from './Icons';

export default function AnalyticsChart({ period = 30 }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState('revenue');

  useEffect(() => {
    loadData();
  }, [period]);

  async function loadData() {
    try {
      setLoading(true);
      const response = await api.get(`/analytics/growth?period=${period}`);
      setData(response.data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="chart-container">
        <div className="loading-center">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  if (!data || !data.snapshots || data.snapshots.length === 0) {
    return (
      <div className="chart-container">
        <div className="empty-state">
          <div className="empty-icon"><Icon name="bar_chart" size={32} /></div>
          <div className="empty-title">Недостатньо даних</div>
          <div className="empty-sub">Дані аналітики з'являться після накопичення історії</div>
        </div>
      </div>
    );
  }

  const maxValue = Math.max(
    ...data.snapshots.map(s => 
      selectedMetric === 'revenue' ? s.total_revenue : s.total_leads
    )
  );

  const metrics = [
    { key: 'revenue', label: 'Виручка', color: '#16a34a' },
    { key: 'leads', label: 'Ліди', color: '#7c3aed' },
    { key: 'lost', label: 'Втрати', color: '#dc2626' }
  ];

  return (
    <div className="chart-container fade-up">
      <div className="chart-header">
        <div>
          <div className="chart-title">Динаміка бізнесу</div>
          <div style={{ fontSize: '12px', color: 'var(--t4)', marginTop: '4px' }}>
            Останні {period} днів
          </div>
        </div>
        <div className="tabs">
          {metrics.map(m => (
            <button
              key={m.key}
              className={`tab ${selectedMetric === m.key ? 'active' : ''}`}
              onClick={() => setSelectedMetric(m.key)}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ height: '300px', display: 'flex', alignItems: 'flex-end', gap: '4px', padding: '20px 0' }}>
        {data.snapshots.map((snapshot, idx) => {
          const value = selectedMetric === 'revenue' 
            ? snapshot.total_revenue 
            : selectedMetric === 'leads'
            ? snapshot.total_leads
            : snapshot.lost_revenue;
          
          const height = maxValue > 0 ? (value / maxValue) * 100 : 0;
          const color = metrics.find(m => m.key === selectedMetric)?.color || '#16a34a';

          return (
            <div
              key={idx}
              className="tooltip"
              style={{
                flex: 1,
                height: '100%',
                display: 'flex',
                alignItems: 'flex-end',
                position: 'relative'
              }}
            >
              <div
                style={{
                  width: '100%',
                  height: `${height}%`,
                  background: color,
                  borderRadius: '4px 4px 0 0',
                  transition: 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
                  cursor: 'pointer',
                  animation: 'barGrow 0.6s cubic-bezier(0.16, 1, 0.3, 1)',
                  animationDelay: `${idx * 20}ms`,
                  animationFillMode: 'both',
                  transformOrigin: 'bottom'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.opacity = '0.7';
                  e.currentTarget.style.transform = 'scaleY(1.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.opacity = '1';
                  e.currentTarget.style.transform = 'scaleY(1)';
                }}
              />
              <div className="tooltip-content">
                <div>{new Date(snapshot.date).toLocaleDateString('uk-UA', { month: 'short', day: 'numeric' })}</div>
                <div style={{ fontWeight: 700 }}>
                  {selectedMetric === 'revenue' || selectedMetric === 'lost'
                    ? `$${value.toFixed(2)}`
                    : value}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="chart-legend">
        <div className="legend-item">
          <div className="legend-dot" style={{ background: '#16a34a' }}></div>
          <span>Виручка: ${data.snapshots[data.snapshots.length - 1]?.total_revenue.toFixed(2) || 0}</span>
        </div>
        <div className="legend-item">
          <div className="legend-dot" style={{ background: '#7c3aed' }}></div>
          <span>Ліди: {data.snapshots[data.snapshots.length - 1]?.total_leads || 0}</span>
        </div>
        <div className="legend-item">
          <div className="legend-dot" style={{ background: '#dc2626' }}></div>
          <span>Втрачено: ${data.snapshots[data.snapshots.length - 1]?.lost_revenue.toFixed(2) || 0}</span>
        </div>
      </div>
    </div>
  );
}
