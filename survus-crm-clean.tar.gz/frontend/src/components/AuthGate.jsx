import { useState, useEffect } from 'react'
import client from '../api/client'
import t from '../i18n'

export default function AuthGate({ children }) {
  const [status, setStatus] = useState('loading')
  const [tokenInput, setTokenInput] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const urlToken = params.get('token')
    const storedToken = localStorage.getItem('survus_token')
    const token = urlToken || storedToken
    if (token) validate(token)
    else setStatus('unauthenticated')
  }, [])

  async function validate(token) {
    try {
      localStorage.setItem('survus_token', token)
      const res = await client.post('/auth/validate', {}, { headers: { 'X-Access-Token': token } })
      localStorage.setItem('survus_workspace', JSON.stringify(res.data))
      setStatus('authenticated')
      const url = new URL(window.location.href)
      if (url.searchParams.has('token')) {
        url.searchParams.delete('token')
        window.history.replaceState({}, '', url.toString())
      }
    } catch {
      localStorage.removeItem('survus_token')
      localStorage.removeItem('survus_workspace')
      setStatus('unauthenticated')
    }
  }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!tokenInput.trim()) return
    setError('')
    setSubmitting(true)
    try {
      await validate(tokenInput.trim())
    } catch {
      setError(t('auth.error'))
    } finally {
      setSubmitting(false)
    }
  }

  if (status === 'loading') {
    return (
      <div style={S.bg}>
        <div className="spinner" />
      </div>
    )
  }

  if (status === 'authenticated') return children

  return (
    <div style={S.bg}>
      {/* Background decoration */}
      <div style={S.bgCircle1} />
      <div style={S.bgCircle2} />

      <div style={S.card} className="slide-in">
        {/* Logo */}
        <div style={S.logoWrap}>
          <div style={S.logoIcon}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <rect width="28" height="28" rx="8" fill="#22c55e"/>
              <path d="M8 14l4 4 8-8" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span style={S.logoText}>SURVUS</span>
        </div>

        <h1 style={S.title}>{t('auth.title')}</h1>
        <p style={S.subtitle}>{t('auth.subtitle')}</p>

        <form onSubmit={handleSubmit} style={S.form}>
          <div style={S.inputWrap}>
            <svg style={S.inputIcon} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            <input
              type="text"
              value={tokenInput}
              onChange={e => setTokenInput(e.target.value)}
              placeholder={t('auth.placeholder')}
              style={S.input}
              autoFocus
            />
          </div>

          {error && (
            <div style={S.errorBox}>
              <span>⚠</span> {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting || !tokenInput.trim()}
            style={{ ...S.btn, opacity: (submitting || !tokenInput.trim()) ? 0.65 : 1 }}
          >
            {submitting ? (
              <>
                <span style={S.btnSpinner} />
                {t('auth.entering')}
              </>
            ) : t('auth.enter')}
          </button>
        </form>

        <p style={S.hint}>SURVUS CRM · Захищений доступ</p>
      </div>
    </div>
  )
}

const S = {
  bg: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'linear-gradient(135deg, #f0fdf4 0%, #e8f5e9 50%, #f1f5f9 100%)',
    position: 'relative',
    overflow: 'hidden',
  },
  bgCircle1: {
    position: 'absolute', top: '-120px', right: '-120px',
    width: '400px', height: '400px', borderRadius: '50%',
    background: 'radial-gradient(circle, rgba(34,197,94,0.12) 0%, transparent 70%)',
    pointerEvents: 'none',
  },
  bgCircle2: {
    position: 'absolute', bottom: '-80px', left: '-80px',
    width: '300px', height: '300px', borderRadius: '50%',
    background: 'radial-gradient(circle, rgba(34,197,94,0.08) 0%, transparent 70%)',
    pointerEvents: 'none',
  },
  card: {
    background: 'rgba(255,255,255,0.95)',
    backdropFilter: 'blur(20px)',
    borderRadius: '20px',
    boxShadow: '0 20px 60px rgba(0,0,0,0.10), 0 0 0 1px rgba(255,255,255,0.8)',
    padding: '44px 40px',
    width: '100%',
    maxWidth: '420px',
    textAlign: 'center',
    position: 'relative',
    zIndex: 1,
  },
  logoWrap: {
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    gap: '10px', marginBottom: '24px',
  },
  logoIcon: {
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: '10px', overflow: 'hidden',
  },
  logoText: {
    fontSize: '26px', fontWeight: '800', color: '#0f172a', letterSpacing: '3px',
  },
  title: {
    fontSize: '20px', fontWeight: '700', color: '#0f172a', marginBottom: '6px',
  },
  subtitle: {
    fontSize: '14px', color: '#64748b', marginBottom: '28px',
  },
  form: { display: 'flex', flexDirection: 'column', gap: '12px' },
  inputWrap: { position: 'relative' },
  inputIcon: {
    position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)',
    color: '#94a3b8', pointerEvents: 'none',
  },
  input: {
    width: '100%', padding: '12px 14px 12px 42px',
    border: '1.5px solid #e2e8f0', borderRadius: '10px',
    fontSize: '14px', outline: 'none', background: '#fafbfc',
    fontFamily: 'monospace', letterSpacing: '0.5px',
    transition: 'border-color 0.15s, box-shadow 0.15s',
    boxSizing: 'border-box',
  },
  errorBox: {
    display: 'flex', alignItems: 'center', gap: '6px',
    padding: '10px 14px', background: '#fef2f2', borderRadius: '8px',
    color: '#dc2626', fontSize: '13px', fontWeight: '500',
  },
  btn: {
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
    padding: '13px', borderRadius: '10px', border: 'none',
    background: 'linear-gradient(135deg, #22c55e, #16a34a)',
    color: '#fff', fontSize: '15px', fontWeight: '600', cursor: 'pointer',
    boxShadow: '0 4px 14px rgba(34,197,94,0.35)',
    transition: 'all 0.15s',
  },
  btnSpinner: {
    width: '16px', height: '16px',
    border: '2px solid rgba(255,255,255,0.4)', borderTopColor: '#fff',
    borderRadius: '50%', animation: 'spin 0.7s linear infinite',
    display: 'inline-block',
  },
  hint: { fontSize: '12px', color: '#94a3b8', marginTop: '20px' },
}
