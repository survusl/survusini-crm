import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import client from '../api/client'
import Icon from './Icons'

export default function AuthModal({ show, onClose }) {
  const [authMode, setAuthMode] = useState('token') // 'token' or 'email'
  const [token, setToken] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const handleTokenSubmit = async (e) => {
    e.preventDefault()
    if (!token.trim()) return
    
    setLoading(true)
    setError('')
    
    try {
      const response = await client.post('/auth/validate', {}, {
        headers: { 'X-Access-Token': token.trim() }
      })
      
      const data = response.data
      localStorage.setItem('survus_token', token.trim())
      localStorage.setItem('survus_workspace', JSON.stringify(data))
      window.dispatchEvent(new Event('auth-change'))
      navigate('/dashboard')
    } catch (error) {
      console.error('Auth error:', error)
      setError('Невірний токен. Спробуйте ще раз.')
    } finally {
      setLoading(false)
    }
  }

  const handleEmailSubmit = async (e) => {
    e.preventDefault()
    if (!email.trim() || !password.trim()) {
      setError('Введіть email та пароль')
      return
    }
    
    setLoading(true)
    setError('')
    
    try {
      const response = await client.post('/auth/login', {
        email: email.trim(),
        password: password.trim()
      })
      
      const data = response.data
      localStorage.setItem('survus_token', data.access_token)
      localStorage.setItem('survus_workspace', JSON.stringify(data))
      localStorage.setItem('survus_user', JSON.stringify(data.user))
      window.dispatchEvent(new Event('auth-change'))
      navigate('/dashboard')
    } catch (error) {
      console.error('Login error:', error)
      setError(error.response?.data?.error || 'Помилка входу. Спробуйте ще раз.')
    } finally {
      setLoading(false)
    }
  }

  if (!show) return null

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal dark-green" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="modal-title">Вхід до SURVUS</div>
            <div className="modal-subtitle">Виберіть спосіб входу</div>
          </div>
          <button className="btn-icon" onClick={onClose}><Icon name="x" size={16} /></button>
        </div>
        <div className="modal-body">
          {/* Auth Mode Tabs */}
          <div className="tabs" style={{ marginBottom: '24px', width: '100%' }}>
            <button 
              className={`tab ${authMode === 'token' ? 'active' : ''}`} 
              onClick={() => { setAuthMode('token'); setError('') }}
              style={{ flex: 1 }}
            >
              По токену
            </button>
            <button 
              className={`tab ${authMode === 'email' ? 'active' : ''}`} 
              onClick={() => { setAuthMode('email'); setError('') }}
              style={{ flex: 1 }}
            >
              По email
            </button>
          </div>

          {error && (
            <div className="form-error" style={{ marginBottom: '16px' }}>
              {error}
            </div>
          )}

          {authMode === 'token' ? (
            <form onSubmit={handleTokenSubmit}>
              <div className="form-group" style={{ marginBottom: '20px' }}>
                <label className="form-label">Токен доступу <span className="form-required">*</span></label>
                <input 
                  type="text" 
                  className="input dark" 
                  placeholder="Вставте ваш токен тут" 
                  value={token} 
                  onChange={(e) => setToken(e.target.value)} 
                  autoFocus 
                  disabled={loading}
                />
                <div className="form-hint">Токен виглядає як: 550e8400-e29b-41d4-a716-446655440000</div>
              </div>
              <div className="form-actions">
                <button type="submit" className="btn-glow" disabled={loading}>
                  {loading ? 'Вхід...' : 'Увійти'}
                </button>
                <button type="button" className="btn-ghost" onClick={onClose} disabled={loading}>
                  Скасувати
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleEmailSubmit}>
              <div className="form-group" style={{ marginBottom: '16px' }}>
                <label className="form-label">Email <span className="form-required">*</span></label>
                <input 
                  type="email" 
                  className="input dark" 
                  placeholder="your@email.com" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  autoFocus 
                  disabled={loading}
                />
              </div>
              <div className="form-group" style={{ marginBottom: '20px' }}>
                <label className="form-label">Пароль <span className="form-required">*</span></label>
                <input 
                  type="password" 
                  className="input dark" 
                  placeholder="Введіть пароль" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  disabled={loading}
                />
              </div>
              <div className="form-actions">
                <button type="submit" className="btn-glow" disabled={loading}>
                  {loading ? 'Вхід...' : 'Увійти'}
                </button>
                <button type="button" className="btn-ghost" onClick={onClose} disabled={loading}>
                  Скасувати
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
