import { useEffect, useState } from 'react'
import Sidebar from './Sidebar'
import QuickAddLead from './QuickAddLead'
import SubscriptionAlert from './SubscriptionAlert'
import { applyTheme } from '../utils/theme'

export default function Layout({ children }) {
  const [showAdd, setShowAdd] = useState(false)

  const workspace = (() => {
    try { return JSON.parse(localStorage.getItem('survus_workspace') || '{}') }
    catch { return {} }
  })()

  useEffect(() => {
    // Always use dark green theme
    applyTheme('#3dd68c')
  }, [])

  return (
    <div style={S.root}>
      <Sidebar companyName={workspace?.company_name} onAddLead={() => setShowAdd(true)} />
      <div style={S.content}>
        <main style={S.main} className="fade-in">
          {children}
        </main>
      </div>
      {showAdd && <QuickAddLead onClose={() => setShowAdd(false)} onAdded={() => setShowAdd(false)} />}
      <SubscriptionAlert />
    </div>
  )
}

const S = {
  root: { display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg)' },
  content: { flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' },
  main: { flex: 1, padding: '28px 32px', overflowY: 'auto' },
}
