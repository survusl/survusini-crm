import { useState, useRef, useEffect } from 'react'
import client from '../api/client'
import Icon from './Icons'

const SOURCES = [
  { id: 'instagram', label: 'Instagram', icon: 'instagram' },
  { id: 'telegram', label: 'Telegram', icon: 'telegram' },
  { id: 'other', label: 'Інше', icon: 'message' },
]

export default function QuickAddLead({ onClose, onAdded }) {
  const [form, setForm] = useState({ name: '', username: '', note: '', source: 'instagram', amount: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const nameRef = useRef(null)

  useEffect(() => { nameRef.current?.focus() }, [])

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const handleSubmit = async e => {
    e.preventDefault()
    if (!form.name.trim()) { setError('Введіть імʼя'); return }
    if (!form.username.trim()) { setError('Введіть нікнейм'); return }
    setLoading(true); setError(null)
    try {
      await client.post('/leads', {
        name: form.name.trim(),
        username: form.username.trim(),
        note: form.note.trim() || undefined,
        amount: form.amount ? parseFloat(form.amount) : 0,
      })
      onAdded()
    } catch (e) {
      setError(e?.response?.data?.error || 'Помилка при додаванні')
    } finally { setLoading(false) }
  }

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: '480px' }} onClick={e => e.stopPropagation()}>
        {/* Header with gradient */}
        <div style={{
          background: 'linear-gradient(135deg, var(--p-light), rgba(22,163,74,0.04))',
          borderBottom: '1px solid var(--b2)',
          padding: '22px 26px 18px',
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: '38px', height: '38px', borderRadius: '11px', background: 'var(--p)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(22,163,74,0.3)' }}>
                <Icon name="plus" size={18} color="#fff" />
              </div>
              <div>
                <div style={{ fontSize: '16px', fontWeight: '800', color: 'var(--t1)', letterSpacing: '-0.02em' }}>Новий лід</div>
                <div style={{ fontSize: '12px', color: 'var(--t4)', marginTop: '1px' }}>Додайте контакт до CRM</div>
              </div>
            </div>
            <button onClick={onClose} className="btn btn-ghost btn-icon-sm" style={{ color: 'var(--t4)', marginTop: '2px' }}>
              <Icon name="x" size={15} />
            </button>
          </div>

          {/* Source selector */}
          <div style={{ display: 'flex', gap: '6px', marginTop: '16px' }}>
            {SOURCES.map(s => (
              <button key={s.id} type="button" onClick={() => set('source', s.id)} style={{
                display: 'flex', alignItems: 'center', gap: '5px',
                padding: '5px 12px', borderRadius: '20px', border: 'none', cursor: 'pointer',
                background: form.source === s.id ? 'var(--p)' : 'rgba(255,255,255,0.7)',
                color: form.source === s.id ? '#fff' : 'var(--t3)',
                fontSize: '12px', fontWeight: '600',
                boxShadow: form.source === s.id ? '0 2px 6px rgba(22,163,74,0.3)' : 'none',
                transition: 'all 0.15s',
              }}>
                <Icon name={s.icon} size={11} />
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} style={{ padding: '22px 26px 24px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            {/* Name */}
            <div className="form-group">
              <label className="form-label">
                Імʼя <span className="form-required">*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--t4)', display: 'flex', pointerEvents: 'none' }}>
                  <Icon name="contacts" size={14} />
                </div>
                <input
                  ref={nameRef}
                  value={form.name}
                  onChange={e => set('name', e.target.value)}
                  placeholder="Повне імʼя клієнта"
                  className="input"
                  style={{ paddingLeft: '36px' }}
                />
              </div>
            </div>

            {/* Username */}
            <div className="form-group">
              <label className="form-label">
                Нікнейм <span className="form-required">*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--t4)', display: 'flex', pointerEvents: 'none' }}>
                  <Icon name={form.source === 'telegram' ? 'telegram' : 'instagram'} size={14} />
                </div>
                <input
                  value={form.username}
                  onChange={e => set('username', e.target.value.replace('@', ''))}
                  placeholder={form.source === 'telegram' ? 'username' : 'instagram_handle'}
                  className="input"
                  style={{ paddingLeft: '36px' }}
                />
                {form.username && (
                  <div style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', fontSize: '11px', color: 'var(--t4)', fontFamily: 'var(--mono)' }}>
                    @{form.username}
                  </div>
                )}
              </div>
            </div>

            {/* Note */}
            <div className="form-group">
              <label className="form-label">Нотатка</label>
              <textarea
                value={form.note}
                onChange={e => set('note', e.target.value)}
                placeholder="Звідки прийшов, що цікавить..."
                rows={2}
                className="input"
                style={{ resize: 'none', lineHeight: '1.5' }}
              />
            </div>

            {/* Amount */}
            <div className="form-group">
              <label className="form-label">Сума оплати</label>
              <div style={{ position: 'relative' }}>
                <div style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--t4)', display: 'flex', pointerEvents: 'none', fontSize: '13px', fontWeight: '600' }}>
                  $
                </div>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.amount}
                  onChange={e => set('amount', e.target.value)}
                  placeholder="0.00"
                  className="input"
                  style={{ paddingLeft: '28px' }}
                />
              </div>
              <span className="form-hint">Можна вказати зараз або змінити пізніше</span>
            </div>

            {error && (
              <div className="form-error">
                <Icon name="warning" size={13} /> {error}
              </div>
            )}
          </div>

          {/* Footer */}
          <div style={{ display: 'flex', gap: '8px', marginTop: '20px' }}>
            <button type="button" onClick={onClose} className="btn btn-secondary" style={{ flex: 1 }} disabled={loading}>
              Скасувати
            </button>
            <button type="submit" className="btn btn-primary" style={{ flex: 2 }} disabled={loading}>
              {loading ? (
                <>
                  <span style={{ width: '14px', height: '14px', border: '2px solid rgba(255,255,255,0.35)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.65s linear infinite', display: 'inline-block' }} />
                  Додаємо...
                </>
              ) : (
                <><Icon name="plus" size={13} /> Додати лід</>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
