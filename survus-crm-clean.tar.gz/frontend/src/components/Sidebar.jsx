import { useLocation, NavLink } from 'react-router-dom'
import Icon from './Icons'

const NAV_PRIMARY = [
  { key: 'dashboard', path: '/', label: 'Дашборд', icon: 'dashboard' },
  { key: 'leads', path: '/leads', label: 'Ліди', icon: 'leads' },
  { key: 'tasks', path: '/tasks', label: 'Завдання', icon: 'tasks' },
  { key: 'reports', path: '/reports', label: 'Звіти', icon: 'reports' },
]

const NAV_SECONDARY = [
  { key: 'contacts', path: '/contacts', label: 'Контакти', icon: 'contacts' },
  { key: 'appointments', path: '/appointments', label: 'Зустрічі', icon: 'calendar' },
]

function NavItem({ item, location }) {
  const isActive = item.path === '/'
    ? location.pathname === '/'
    : location.pathname.startsWith(item.path)
  return (
    <NavLink to={item.path} style={{ textDecoration: 'none' }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: '9px',
        padding: '8px 10px', borderRadius: '9px',
        background: isActive ? 'var(--p-light)' : 'transparent',
        color: isActive ? 'var(--p)' : 'var(--t3)',
        transition: 'all 0.12s', marginBottom: '1px',
        cursor: 'pointer',
      }}
        onMouseEnter={e => { if (!isActive) { e.currentTarget.style.background = 'rgba(61,214,140,0.05)'; e.currentTarget.style.color = 'var(--t2)' } }}
        onMouseLeave={e => { if (!isActive) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'var(--t3)' } }}
      >
        <span style={{ display: 'flex', flexShrink: 0 }}>
          <Icon name={item.icon} size={15} />
        </span>
        <span style={{ fontSize: '13px', fontWeight: isActive ? 600 : 400, color: isActive ? 'var(--p)' : 'var(--t2)', flex: 1 }}>
          {item.label}
        </span>
        {isActive && <div style={{ width: '5px', height: '5px', borderRadius: '50%', background: 'var(--p)', flexShrink: 0 }} />}
      </div>
    </NavLink>
  )
}

export default function Sidebar({ companyName, onAddLead }) {
  const location = useLocation()
  const isSettings = location.pathname === '/settings'

  // Получаем данные workspace
  const workspace = (() => {
    try { 
      const data = JSON.parse(localStorage.getItem('survus_workspace') || '{}')
      console.log('Workspace data:', data) // Для отладки
      return data
    }
    catch { return {} }
  })()

  const subUntil = workspace?.subscription_until
  const plan = workspace?.subscription_plan || 'free'
  
  console.log('Plan:', plan, 'SubUntil:', subUntil) // Для отладки
  
  const daysLeft = subUntil
    ? Math.ceil((new Date(subUntil) - new Date()) / (1000 * 60 * 60 * 24))
    : null
  
  // Правильное определение плана с учетом всех вариантов
  let planLabel = 'Free'
  let planBadgeStyle = {}
  
  if (plan === 'pro_plus' || plan === 'pro-plus') {
    planLabel = 'PRO+'
    planBadgeStyle = { background: 'linear-gradient(135deg,#f59e0b,#d97706)', color: '#fff', padding: '2px 6px', borderRadius: '4px', fontSize: '9px', fontWeight: '700' }
  } else if (plan === 'pro') {
    planLabel = 'PRO'
    planBadgeStyle = { background: 'linear-gradient(135deg,#7c3aed,#4f46e5)', color: '#fff', padding: '2px 6px', borderRadius: '4px', fontSize: '9px', fontWeight: '700' }
  } else if (plan === 'trial') {
    planLabel = 'Trial'
    planBadgeStyle = { background: 'rgba(251,191,36,0.15)', color: '#fbbf24', padding: '2px 6px', borderRadius: '4px', fontSize: '9px', fontWeight: '700' }
  }
  
  const subStatusColor = !daysLeft || daysLeft <= 0 ? '#fca5a5' : daysLeft <= 7 ? '#fbbf24' : 'var(--green-glow)'

  return (
    <aside style={S.sidebar}>
      {/* Logo */}
      <div style={S.logo}>
        <div style={S.logoMark}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M20 7H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z" fill="var(--primary)"/>
            <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2" stroke="var(--primary)" strokeWidth="1.5" fill="none" opacity="0.5"/>
            <circle cx="12" cy="12" r="1.5" fill="#fff"/>
          </svg>
        </div>
        <span style={S.logoText}>SURVUS</span>
        <span style={S.logoBadge}>CRM</span>
      </div>

      {/* Add lead */}
      <div style={{ padding: '10px 12px 6px' }}>
        <button onClick={onAddLead} style={S.addBtn}>
          <Icon name="plus" size={12} />
          Додати лід
        </button>
      </div>

      {/* Nav */}
      <nav style={S.nav}>
        <div style={S.navLabel}>ГОЛОВНЕ</div>
        {NAV_PRIMARY.map(item => <NavItem key={item.key} item={item} location={location} />)}

        <div style={{ ...S.navLabel, marginTop: '14px' }}>ІНШЕ</div>
        {NAV_SECONDARY.map(item => <NavItem key={item.key} item={item} location={location} />)}
      </nav>

      {/* Bottom: subscription + settings */}
      <div style={S.bottom}>
        {/* Subscription warning */}
        {daysLeft !== null && daysLeft <= 7 && daysLeft > 0 && (
          <div style={S.subWarning}>
            <Icon name="warning" size={11} color="#fbbf24" />
            <span style={{ fontSize: '11px', color: '#fbbf24', fontWeight: '500' }}>
              Підписка: {daysLeft} дн.
            </span>
          </div>
        )}

        {/* Settings button */}
        <NavLink to="/settings" style={{ textDecoration: 'none' }}>
          <div style={{
            ...S.settingsBtn,
            background: isSettings ? 'var(--p-light)' : 'var(--s1)',
            borderColor: isSettings ? 'var(--p-border)' : 'var(--b1)',
          }}>
            <div style={S.wsAvatar}>{(companyName || 'W')[0].toUpperCase()}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: '12.5px', fontWeight: '600', color: 'var(--t1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {companyName || 'Workspace'}
              </div>
              <div style={{ fontSize: '10.5px', color: 'var(--t3)', display: 'flex', alignItems: 'center', gap: '6px', marginTop: '2px' }}>
                <div style={{ width: '5px', height: '5px', borderRadius: '50%', background: subStatusColor }} />
                {daysLeft !== null && daysLeft > 0 && <span>{daysLeft} дн.</span>}
                {planLabel !== 'Free' && <span style={planBadgeStyle}>{planLabel}</span>}
                {planLabel === 'Free' && <span>{planLabel}</span>}
              </div>
            </div>
            <Icon name="settings" size={13} color={isSettings ? 'var(--p)' : 'var(--t3)'} />
          </div>
        </NavLink>
      </div>
    </aside>
  )
}

const S = {
  sidebar: {
    width: '240px', minWidth: '240px', height: '100vh',
    background: 'var(--s0)', borderRight: '1px solid var(--b1)',
    display: 'flex', flexDirection: 'column',
    position: 'sticky', top: 0, overflow: 'hidden',
  },
  logo: {
    display: 'flex', alignItems: 'center', gap: '8px',
    padding: '16px 14px 12px', borderBottom: '1px solid var(--b2)',
  },
  logoMark: {
    width: '28px', height: '28px', borderRadius: '8px',
    background: 'var(--p-light)', display: 'flex', alignItems: 'center', justifyContent: 'center',
    border: '1px solid var(--p-border)', flexShrink: 0,
  },
  logoText: { fontSize: '14px', fontWeight: '800', color: 'var(--t1)', letterSpacing: '1.5px' },
  logoBadge: {
    fontSize: '9px', fontWeight: '700', color: 'var(--p)',
    background: 'var(--p-light)', padding: '2px 5px',
    borderRadius: '4px', letterSpacing: '0.5px',
  },
  addBtn: {
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '5px',
    width: '100%', padding: '8px 12px', borderRadius: '8px', border: '1px solid var(--green-glow)',
    background: 'var(--green-accent)', color: '#fff',
    fontSize: '12.5px', fontWeight: '600', cursor: 'pointer',
    boxShadow: '0 1px 4px rgba(61,214,140,0.3), 0 0 20px rgba(61,214,140,0.2)',
    transition: 'all 0.15s',
  },
  nav: { flex: 1, padding: '8px 10px', overflowY: 'auto' },
  navLabel: {
    fontSize: '9.5px', fontWeight: '700', color: 'var(--t4)',
    letterSpacing: '0.1em', padding: '8px 8px 5px',
  },
  bottom: { padding: '10px 12px 14px', borderTop: '1px solid var(--b2)', display: 'flex', flexDirection: 'column', gap: '6px' },
  subWarning: {
    display: 'flex', alignItems: 'center', gap: '5px',
    padding: '6px 10px', background: 'rgba(251,191,36,0.1)', borderRadius: '7px',
    border: '1px solid rgba(251,191,36,0.3)',
  },
  settingsBtn: {
    display: 'flex', alignItems: 'center', gap: '9px',
    padding: '8px 10px', borderRadius: '9px',
    border: '1px solid var(--b1)',
    cursor: 'pointer', transition: 'all 0.12s',
  },
  wsAvatar: {
    width: '28px', height: '28px', borderRadius: '8px', flexShrink: 0,
    background: 'linear-gradient(135deg, var(--green-accent), var(--green-glow))',
    color: '#fff', fontSize: '12px', fontWeight: '700',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
}
