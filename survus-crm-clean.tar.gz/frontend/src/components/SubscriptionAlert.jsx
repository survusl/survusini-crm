import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import client from '../api/client';
import Icon from './Icons';

export default function SubscriptionAlert() {
  const [subscription, setSubscription] = useState(null);
  const [showAlert, setShowAlert] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    checkSubscription();
  }, []);

  const checkSubscription = async () => {
    try {
      const response = await client.get('/subscription/status');
      const data = response.data;
      setSubscription(data);
      
      // Show alert if subscription is expiring soon or expired
      if (data.status === 'expired' || data.daysUntilExpiry <= 7) {
        setShowAlert(true);
      }
    } catch (error) {
      console.error('Failed to check subscription:', error);
    }
  };

  if (!showAlert || !subscription) return null;

  const isExpired = subscription.status === 'expired';
  const daysLeft = subscription.daysUntilExpiry;

  return (
    <div style={styles.overlay}>
      <div style={styles.alert} className="scale-in">
        <div style={styles.icon}>
          <Icon name={isExpired ? 'warning' : 'clock'} size={32} color={isExpired ? '#dc2626' : '#f59e0b'} />
        </div>
        
        <div style={styles.content}>
          <h3 style={styles.title}>
            {isExpired ? 'Підписка закінчилась' : 'Підписка скоро закінчиться'}
          </h3>
          <p style={styles.message}>
            {isExpired 
              ? `Ваша підписка ${subscription.plan} закінчилась ${new Date(subscription.endsAt).toLocaleDateString('uk-UA')}. Продовжіть підписку щоб продовжити користуватись усіма функціями.`
              : `Ваша підписка ${subscription.plan} закінчується через ${daysLeft} ${daysLeft === 1 ? 'день' : daysLeft < 5 ? 'дні' : 'днів'}. Продовжіть зараз щоб не втратити доступ.`
            }
          </p>
          
          {subscription.features && (
            <div style={styles.features}>
              <div style={styles.featuresTitle}>Що ви втратите:</div>
              <ul style={styles.featuresList}>
                {subscription.features.slice(0, 3).map((feature, i) => (
                  <li key={i} style={styles.featureItem}>
                    <Icon name="x" size={12} color="#dc2626" /> {feature}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div style={styles.actions}>
          <button 
            style={styles.btnPrimary}
            onClick={() => {
              setShowAlert(false);
              navigate('/settings');
            }}
          >
            Продовжити підписку
          </button>
          <button 
            style={styles.btnSecondary}
            onClick={() => setShowAlert(false)}
          >
            {isExpired ? 'Продовжити з Free' : 'Нагадати пізніше'}
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    inset: 0,
    background: 'rgba(13, 17, 23, 0.75)',
    backdropFilter: 'blur(8px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
    padding: '20px',
  },
  alert: {
    background: 'var(--s0)',
    borderRadius: 'var(--r5)',
    padding: '32px',
    maxWidth: '520px',
    width: '100%',
    boxShadow: 'var(--sh4)',
    border: '1px solid var(--b1)',
  },
  icon: {
    fontSize: '48px',
    textAlign: 'center',
    marginBottom: '20px',
  },
  content: {
    marginBottom: '24px',
  },
  title: {
    fontSize: '22px',
    fontWeight: '800',
    color: 'var(--t1)',
    marginBottom: '12px',
    textAlign: 'center',
  },
  message: {
    fontSize: '15px',
    lineHeight: '1.6',
    color: 'var(--t2)',
    textAlign: 'center',
    marginBottom: '20px',
  },
  features: {
    background: 'var(--s1)',
    borderRadius: 'var(--r3)',
    padding: '16px',
    border: '1px solid var(--b1)',
  },
  featuresTitle: {
    fontSize: '13px',
    fontWeight: '700',
    color: 'var(--t2)',
    marginBottom: '10px',
  },
  featuresList: {
    listStyle: 'none',
    padding: 0,
    margin: 0,
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
  },
  featureItem: {
    fontSize: '13px',
    color: 'var(--t3)',
  },
  actions: {
    display: 'flex',
    flexDirection: 'column',
    gap: '12px',
  },
  btnPrimary: {
    padding: '14px 24px',
    background: 'linear-gradient(135deg, #7c3aed, #4f46e5)',
    color: 'white',
    border: 'none',
    borderRadius: 'var(--r3)',
    fontSize: '15px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s',
    boxShadow: '0 4px 16px rgba(124, 58, 237, 0.3)',
  },
  btnSecondary: {
    padding: '12px 24px',
    background: 'var(--s0)',
    color: 'var(--t2)',
    border: '1px solid var(--b1)',
    borderRadius: 'var(--r3)',
    fontSize: '14px',
    fontWeight: '600',
    cursor: 'pointer',
    transition: 'all 0.2s',
  },
};
