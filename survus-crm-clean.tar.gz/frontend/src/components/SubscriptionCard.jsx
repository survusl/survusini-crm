import { useState, useEffect } from 'react';
import { api } from '../api/client';
import Icon from './Icons';

export default function SubscriptionCard() {
  const [subscription, setSubscription] = useState(null);
  const [plans, setPlans] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);
      const [subRes, plansRes] = await Promise.all([
        api.get('/subscription/info'),
        api.get('/subscription/plans')
      ]);
      setSubscription(subRes.data);
      setPlans(plansRes.data);
    } catch (err) {
      console.error('Failed to load subscription:', err);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="premium-card" style={{ padding: '32px' }}>
        <div className="loading-center">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  if (!subscription) return null;

  const isPro = subscription.plan === 'pro';
  const isProPlus = subscription.plan === 'pro_plus';
  const isFree = subscription.plan === 'free';

  const planColors = {
    free: { bg: 'var(--s2)', color: 'var(--t3)' },
    pro: { bg: 'linear-gradient(135deg, #7c3aed, #4f46e5)', color: '#fff' },
    pro_plus: { bg: 'linear-gradient(135deg, #f59e0b, #d97706)', color: '#fff' }
  };

  const currentPlanColor = planColors[subscription.plan] || planColors.free;

  return (
    <div className="premium-card fade-up" style={{ padding: '32px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '24px' }}>
        <div>
          <div style={{ fontSize: '14px', color: 'var(--t4)', marginBottom: '8px', fontWeight: 600 }}>
            Поточний тариф
          </div>
          <div style={{ 
            fontSize: '32px', 
            fontWeight: 800, 
            background: currentPlanColor.bg,
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: subscription.plan === 'free' ? 'var(--t1)' : 'transparent',
            backgroundClip: 'text',
            letterSpacing: '-1px'
          }}>
            {subscription.planName}
          </div>
          {subscription.price > 0 && (
            <div style={{ fontSize: '18px', color: 'var(--t3)', marginTop: '4px' }}>
              ${subscription.price}/місяць
            </div>
          )}
        </div>
        
        {(isPro || isProPlus) && (
          <div className={`badge ${isProPlus ? 'badge-pro-plus' : 'badge-pro'}`} style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Icon name="star" size={10} />
            {isProPlus ? 'PRO+' : 'PRO'}
          </div>
        )}
      </div>

      <div className="divider"></div>

      <div style={{ marginBottom: '24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
          <span style={{ fontSize: '13px', color: 'var(--t4)', fontWeight: 600 }}>
            Залишилось днів
          </span>
          <span style={{ fontSize: '24px', fontWeight: 800, color: 'var(--t1)' }}>
            {subscription.daysRemaining}
          </span>
        </div>
        
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ 
              width: `${Math.min((subscription.daysRemaining / 30) * 100, 100)}%`,
              background: currentPlanColor.bg
            }}
          ></div>
        </div>
        
        <div style={{ fontSize: '11px', color: 'var(--t4)', marginTop: '8px' }}>
          Діє до: {new Date(subscription.subscriptionUntil).toLocaleDateString('uk-UA', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      <div className="divider"></div>

      <div>
        <div style={{ fontSize: '13px', fontWeight: 700, color: 'var(--t2)', marginBottom: '12px' }}>
          Можливості тарифу
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {subscription.features.map((feature, idx) => (
            <div 
              key={idx} 
              className="slide-in-right"
              style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '8px',
                fontSize: '12.5px',
                color: 'var(--t2)',
                animationDelay: `${idx * 50}ms`
              }}
            >
              <div style={{ 
                width: '18px', 
                height: '18px', 
                borderRadius: '50%', 
                background: 'var(--p-light)', 
                color: 'var(--p)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '10px',
                fontWeight: 700,
                flexShrink: 0
              }}>
                <Icon name="check" size={10} />
              </div>
              <span>{formatFeatureName(feature)}</span>
            </div>
          ))}
        </div>
      </div>

      {isFree && (
        <div style={{ marginTop: '24px' }}>
          <button className="btn btn-pro" style={{ width: '100%' }}>
            Оновити до PRO
          </button>
        </div>
      )}
    </div>
  );
}

function formatFeatureName(feature) {
  const names = {
    basic_crm: 'Базовий CRM',
    up_to_100_leads: 'До 100 лідів',
    basic_analytics: 'Базова аналітика',
    unlimited_leads: 'Необмежена кількість лідів',
    advanced_analytics: 'Розширена аналітика',
    custom_themes: 'Налаштування тем',
    priority_support: 'Пріоритетна підтримка',
    ai_insights: 'AI-інсайти',
    custom_integrations: 'Кастомні інтеграції',
    white_label: 'White-label',
    api_access: 'API доступ'
  };
  return names[feature] || feature;
}
