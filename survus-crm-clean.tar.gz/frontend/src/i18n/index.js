import uk from './uk'

const translations = { uk }
let currentLang = 'uk'

export function t(path) {
  const keys = path.split('.')
  let val = translations[currentLang]
  for (const k of keys) {
    val = val?.[k]
    if (val === undefined) return path
  }
  return val ?? path
}

export function setLang(lang) {
  if (translations[lang]) currentLang = lang
}

export default t
