import { useState, useEffect } from 'react';
import { api } from '../api/client';
import AnalyticsChart from '../components/AnalyticsChart';
import Icon from '../components/Icons';

export default function AdvancedReports() {
  const [period, setPeriod] = useState(30);
  const [metrics, setMetrics] = useState(null);
  const [lostClients, setLostClients] = useState(null);
  const [revenueBreakdown, setRevenueBreakdown] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [period]);

  async function loadData() {
    try {
      setLoading(true);
      const [metricsRes, lostRes, revenueRes] = await Promise.all([
        api.get(`/analytics/growth?period=${period}`),
        api.get(`/analytics/lost-clients?period=${period}`),
        api.get('/analytics/revenue')
      ]);
      setMetrics(metricsRes.data);
      setLostClients(lostRes.data);
      setRevenueBreakdown(revenueRes.data);
    } catch (err) {
      console.error('Failed to load analytics:', err);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="loading-center">
        <div className="spinner"></div>
      </div>
    );
  }

  const periods = [
    { value: 7, label: '7 днів' },
    { value: 30, label: '30 днів' },
    { value: 90, label: '90 днів' },
    { value: 365, label: 'Рік' }
  ];

  return (
    <div className="fade-up">
      <div className="page-header">
        <div>
          <div className="page-title">Аналітика та звіти</div>
          <div className="page-subtitle">Детальна статистика вашого бізнесу</div>
        </div>
        <div className="filter-pills">
          {periods.map(p => (
            <button
              key={p.value}
              className={`pill ${period === p.value ? 'active' : ''}`}
              onClick={() => setPeriod(p.value)}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="stats-grid stagger" style={{ marginBottom: '24px' }}>
        <div className="metric-card" style={{ '--metric-color': '#16a34a', '--metric-bg': 'rgba(22, 163, 74, 0.1)' }}>
          <div className="metric-header">
            <div className="metric-label">Зростання виручки</div>
            <div className="metric-icon">
              <Icon name="trending_up" size={16} />
            </div>
          </div>
          <div className="metric-value">
            ${metrics?.revenue_growth?.toFixed(2) || '0.00'}
          </div>
          <div className={`metric-change ${metrics?.revenue_growth >= 0 ? 'positive' : 'negative'}`}>
            <Icon name={metrics?.revenue_growth >= 0 ? 'arrow_up' : 'arrow_down'} size={12} />
            {metrics?.revenue_growth >= 0 ? '+' : ''}{metrics?.revenue_growth?.toFixed(2) || 0}
            <span style={{ color: 'var(--t4)', marginLeft: '4px' }}>за період</span>
          </div>
        </div>

        <div className="metric-card" style={{ '--metric-color': '#7c3aed', '--metric-bg': 'rgba(124, 58, 237, 0.1)' }}>
          <div className="metric-header">
            <div className="metric-label">Нові ліди</div>
            <div className="metric-icon">
              <Icon name="users" size={16} />
            </div>
          </div>
          <div className="metric-value">
            {metrics?.leads_growth || 0}
          </div>
          <div className={`metric-change ${metrics?.leads_growth >= 0 ? 'positive' : 'negative'}`}>
            <Icon name={metrics?.leads_growth >= 0 ? 'arrow_up' : 'arrow_down'} size={12} />
            {metrics?.leads_growth >= 0 ? '+' : ''}{metrics?.leads_growth || 0}
            <span style={{ color: 'var(--t4)', marginLeft: '4px' }}>за період</span>
          </div>
        </div>

        <div className="metric-card" style={{ '--metric-color': '#2563eb', '--metric-bg': 'rgba(37, 99, 235, 0.1)' }}>
          <div className="metric-header">
            <div className="metric-label">Конверсія</div>
            <div className="metric-icon">
              <Icon name="target" size={16} />
            </div>
          </div>
          <div className="metric-value">
            {metrics?.conversion_rate || 0}%
          </div>
          <div className="metric-change neutral">
            <Icon name="activity" size={12} />
            Середня конверсія
          </div>
        </div>

        <div className="metric-card" style={{ '--metric-color': '#dc2626', '--metric-bg': 'rgba(220, 38, 38, 0.1)' }}>
          <div className="metric-header">
            <div className="metric-label">Втрачено</div>
            <div className="metric-icon">
              <Icon name="trending_down" size={16} />
            </div>
          </div>
          <div className="metric-value">
            ${metrics?.lost_revenue?.toFixed(2) || '0.00'}
          </div>
          <div className="metric-change negative">
            <Icon name="users" size={12} />
            {metrics?.lost_clients || 0} клієнтів
          </div>
        </div>
      </div>

      {/* Main Chart */}
      <div style={{ marginBottom: '24px' }}>
        <AnalyticsChart period={period} />
      </div>

      {/* Revenue Breakdown */}
      <div className="premium-card fade-up" style={{ padding: '24px', marginBottom: '24px' }}>
        <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--t1)', marginBottom: '20px' }}>
          Розподіл виручки за статусами
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px' }}>
          {revenueBreakdown?.map((item, idx) => {
            const statusColors = {
              new: { bg: '#eff6ff', color: '#2563eb' },
              replied: { bg: '#fffbeb', color: '#b45309' },
              paid: { bg: '#f0fdf4', color: '#15803d' },
              canceled: { bg: '#fef2f2', color: '#dc2626' }
            };
            const colors = statusColors[item.status] || { bg: 'var(--s2)', color: 'var(--t3)' };

            return (
              <div 
                key={idx}
                className="slide-in-right"
                style={{
                  padding: '16px',
                  background: colors.bg,
                  borderRadius: 'var(--r3)',
                  border: `1px solid ${colors.color}20`,
                  animationDelay: `${idx * 80}ms`
                }}
              >
                <div style={{ fontSize: '11px', fontWeight: 600, color: colors.color, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
                  {item.status}
                </div>
                <div style={{ fontSize: '24px', fontWeight: 800, color: colors.color, marginBottom: '4px' }}>
                  ${item.total_amount?.toFixed(2) || '0.00'}
                </div>
                <div style={{ fontSize: '12px', color: colors.color, opacity: 0.7 }}>
                  {item.count} лідів • Середнє: ${item.avg_amount?.toFixed(2) || '0.00'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lost Clients Analysis */}
      {lostClients && lostClients.lost_clients.length > 0 && (
        <div className="premium-card fade-up" style={{ padding: '24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
            <div>
              <div style={{ fontSize: '15px', fontWeight: 700, color: 'var(--t1)' }}>
                Втрачені клієнти
              </div>
              <div style={{ fontSize: '12px', color: 'var(--t4)', marginTop: '4px' }}>
                {lostClients.total_lost_count} клієнтів • ${lostClients.total_lost_revenue.toFixed(2)} втрачено
              </div>
            </div>
            <div className="badge badge-canceled">
              <Icon name="alert" size={10} />
              Потребує уваги
            </div>
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Клієнт</th>
                  <th>Username</th>
                  <th>Сума</th>
                  <th>Дата втрати</th>
                  <th>Причина</th>
                </tr>
              </thead>
              <tbody>
                {lostClients.lost_clients.slice(0, 10).map((client) => (
                  <tr key={client.id}>
                    <td style={{ fontWeight: 600 }}>{client.name}</td>
                    <td style={{ color: 'var(--t3)' }}>@{client.username}</td>
                    <td style={{ fontWeight: 600, color: '#dc2626' }}>
                      ${client.amount?.toFixed(2) || '0.00'}
                    </td>
                    <td style={{ fontSize: '12px', color: 'var(--t4)' }}>
                      {client.lost_at ? new Date(client.lost_at).toLocaleDateString('uk-UA') : '—'}
                    </td>
                    <td style={{ fontSize: '12px', color: 'var(--t3)' }}>
                      {client.lost_reason || 'Не вказано'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
