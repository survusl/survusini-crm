import { useState, useEffect } from 'react'
import Icon from '../components/Icons'

export default function Appointments() {
  const [appointments, setAppointments] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [view, setView] = useState('list') // list or calendar

  useEffect(() => {
    // Для нового воркспейсу зустрічі порожні
    setTimeout(() => {
      setAppointments([])
      setLoading(false)
    }, 300)
  }, [])

  const today = new Date().toISOString().split('T')[0]
  const todayAppointments = appointments.filter(a => a.date === today)
  const upcomingAppointments = appointments.filter(a => a.date > today)

  if (loading) return <div className="loading-center"><div className="spinner" /></div>

  return (
    <div className="fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">Зустрічі</h1>
          <p className="page-subtitle">Календар та планування зустрічей</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <div className="tabs">
            <button className={`tab ${view === 'list' ? 'active' : ''}`} onClick={() => setView('list')}>
              <Icon name="list" size={14} />
              Список
            </button>
            <button className={`tab ${view === 'calendar' ? 'active' : ''}`} onClick={() => setView('calendar')}>
              <Icon name="calendar" size={14} />
              Календар
            </button>
          </div>
          <button className="btn btn-primary" onClick={() => setShowAdd(true)}>
            <Icon name="plus" size={14} />
            Нова зустріч
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(61,214,140,0.15)', color: 'var(--green-glow)' }}>
            <Icon name="calendar" size={16} />
          </div>
          <div className="stat-value">{todayAppointments.length}</div>
          <div className="stat-label">Сьогодні</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(45,95,74,0.15)', color: 'var(--green-accent)' }}>
            <Icon name="clock" size={16} />
          </div>
          <div className="stat-value">{upcomingAppointments.length}</div>
          <div className="stat-label">Заплановано</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon" style={{ background: 'rgba(61,214,140,0.1)', color: 'var(--green-glow)' }}>
            <Icon name="warning" size={16} />
          </div>
          <div className="stat-value">{appointments.filter(a => a.status === 'pending').length}</div>
          <div className="stat-label">Очікують підтвердження</div>
        </div>
      </div>

      {view === 'list' ? (
        <>
          {/* Today */}
          {todayAppointments.length > 0 && (
            <div style={{ marginBottom: '32px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: '700', color: 'var(--t1)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontFamily: 'var(--pixel)', fontSize: '12px', color: 'var(--green-glow)' }}>TODAY</span>
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {todayAppointments.map(apt => (
                  <AppointmentCard key={apt.id} appointment={apt} />
                ))}
              </div>
            </div>
          )}

          {/* Upcoming */}
          {upcomingAppointments.length > 0 && (
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: '700', color: 'var(--t1)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span style={{ fontFamily: 'var(--pixel)', fontSize: '12px', color: 'var(--t4)' }}>UPCOMING</span>
              </h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {upcomingAppointments.map(apt => (
                  <AppointmentCard key={apt.id} appointment={apt} />
                ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="card" style={{ padding: '40px', textAlign: 'center' }}>
          <Icon name="calendar" size={48} color="var(--t4)" />
          <div style={{ fontSize: '16px', fontWeight: '700', color: 'var(--t2)', marginTop: '16px' }}>
            Календар в розробці
          </div>
          <div style={{ fontSize: '13px', color: 'var(--t4)', marginTop: '8px' }}>
            Скоро буде доступний повний календар зустрічей
          </div>
        </div>
      )}

      {/* Add Appointment Modal */}
      {showAdd && (
        <div className="overlay" onClick={() => setShowAdd(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <div className="modal-title">Нова зустріч</div>
                <div className="modal-subtitle">Заплануйте зустріч</div>
              </div>
              <button className="btn btn-ghost btn-icon-sm" onClick={() => setShowAdd(false)}>
                <Icon name="x" size={14} />
              </button>
            </div>
            <div className="modal-body">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div className="form-group">
                  <label className="form-label">Назва <span className="form-required">*</span></label>
                  <input type="text" className="input" placeholder="Назва зустрічі" />
                </div>
                <div className="form-group">
                  <label className="form-label">Контакт</label>
                  <input type="text" className="input" placeholder="Виберіть контакт" />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div className="form-group">
                    <label className="form-label">Дата <span className="form-required">*</span></label>
                    <input type="date" className="input" />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Час <span className="form-required">*</span></label>
                    <input type="time" className="input" />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Тривалість (хв)</label>
                  <input type="number" className="input" placeholder="60" defaultValue="60" />
                </div>
                <div style={{ display: 'flex', gap: '10px', marginTop: '8px' }}>
                  <button className="btn btn-primary" style={{ flex: 1 }}>Створити</button>
                  <button className="btn btn-secondary" onClick={() => setShowAdd(false)}>Скасувати</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function AppointmentCard({ appointment }) {
  const typeIcons = {
    meeting: 'users',
    call: 'phone',
    presentation: 'presentation',
    consultation: 'message'
  }

  const typeColors = {
    meeting: '#60a5fa',
    call: '#fbbf24',
    presentation: '#a78bfa',
    consultation: 'var(--green-glow)'
  }

  return (
    <div className="card card-hover" style={{ padding: '18px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px' }}>
        <div style={{
          width: '56px', height: '56px', borderRadius: '12px',
          background: `${typeColors[appointment.type]}20`,
          border: `1px solid ${typeColors[appointment.type]}40`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0
        }}>
          <Icon name={typeIcons[appointment.type]} size={24} color={typeColors[appointment.type]} />
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '8px' }}>
            <div>
              <div style={{ fontSize: '15px', fontWeight: '700', color: 'var(--t1)', marginBottom: '4px' }}>
                {appointment.title}
              </div>
              <div style={{ fontSize: '13px', color: 'var(--t3)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <Icon name="user" size={12} />
                {appointment.contact}
              </div>
            </div>
            <span className={`badge ${appointment.status === 'confirmed' ? 'badge-paid' : 'badge-replied'}`}>
              {appointment.status === 'confirmed' ? 'Підтверджено' : 'Очікує'}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', fontSize: '13px', color: 'var(--t3)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Icon name="calendar" size={12} />
              {new Date(appointment.date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long' })}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Icon name="clock" size={12} />
              {appointment.time}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontFamily: 'var(--pixel)', fontSize: '10px' }}>
              {appointment.duration} MIN
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: '6px' }}>
          <button className="btn btn-ghost btn-sm">
            <Icon name="edit" size={12} />
          </button>
          <button className="btn btn-ghost btn-sm">
            <Icon name="more" size={12} />
          </button>
        </div>
      </div>
    </div>
  )
}
