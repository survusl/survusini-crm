export default function ComingSoon({ title }) {
  return (
    <div>
      <h1 style={{ fontSize: '22px', fontWeight: '700', color: '#0f172a', marginBottom: '4px' }}>{title}</h1>
      <p style={{ fontSize: '14px', color: '#64748b', marginBottom: '32px' }}>Цей розділ</p>
      <div style={{ background: '#fff', borderRadius: '16px', border: '1px solid #f1f5f9', padding: '64px 32px', textAlign: 'center' }}>
        <div style={{ fontSize: '56px', marginBottom: '16px' }}>🚧</div>
        <h2 style={{ fontSize: '18px', fontWeight: '700', color: '#0f172a', marginBottom: '8px' }}>Незабаром</h2>
        <p style={{ fontSize: '14px', color: '#64748b', maxWidth: '320px', margin: '0 auto' }}>
          Цей розділ знаходиться в розробці. Він буде доступний у наступних оновленнях SURVUS.
        </p>
      </div>
    </div>
  )
}
