import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import Icon from '../components/Icons'

export default function Contacts() {
  const [contacts, setContacts] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [filter, setFilter] = useState('all')
  const navigate = useNavigate()

  useEffect(() => {
    // Для нового воркспейсу контакти порожні
    setTimeout(() => {
      setContacts([])
      setLoading(false)
    }, 300)
  }, [])

  const filtered = contacts.filter(c => filter === 'all' || c.type === filter)

  if (loading) return <div className="loading-center"><div className="spinner" /></div>

  return (
    <div className="fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">Контакти</h1>
          <p className="page-subtitle">Управління базою контактів</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowAdd(true)}>
          <Icon name="plus" size={14} />
          Додати контакт
        </button>
      </div>

      {/* Filters */}
      <div className="filter-pills" style={{ marginBottom: '20px' }}>
        <div className={`pill ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>
          Всі ({contacts.length})
        </div>
        <div className={`pill ${filter === 'client' ? 'active' : ''}`} onClick={() => setFilter('client')}>
          Клієнти ({contacts.filter(c => c.type === 'client').length})
        </div>
        <div className={`pill ${filter === 'lead' ? 'active' : ''}`} onClick={() => setFilter('lead')}>
          Ліди ({contacts.filter(c => c.type === 'lead').length})
        </div>
        <div className={`pill ${filter === 'partner' ? 'active' : ''}`} onClick={() => setFilter('partner')}>
          Партнери ({contacts.filter(c => c.type === 'partner').length})
        </div>
      </div>

      {/* Contacts Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '16px' }}>
        {filtered.map(contact => (
          <div key={contact.id} className="card card-hover" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '16px' }}>
              <div style={{
                width: '48px', height: '48px', borderRadius: '12px',
                background: 'rgba(61,214,140,0.15)', border: '1px solid rgba(61,214,140,0.3)',
                color: 'var(--green-glow)', fontSize: '18px', fontWeight: '700',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0
              }}>
                {contact.name[0]}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '15px', fontWeight: '700', color: 'var(--t1)', marginBottom: '4px' }}>
                  {contact.name}
                </div>
                <span className={`badge badge-${contact.type === 'client' ? 'paid' : contact.type === 'lead' ? 'new' : 'neutral'}`}>
                  {contact.type === 'client' ? 'Клієнт' : contact.type === 'lead' ? 'Лід' : 'Партнер'}
                </span>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--t3)' }}>
                <Icon name="email" size={14} />
                {contact.email}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--t3)' }}>
                <Icon name="phone" size={14} />
                {contact.phone}
              </div>
              {contact.company && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--t3)' }}>
                  <Icon name="building" size={14} />
                  {contact.company}
                </div>
              )}
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button className="btn btn-secondary btn-sm" style={{ flex: 1 }}>
                <Icon name="edit" size={12} />
                Редагувати
              </button>
              <button className="btn btn-ghost btn-sm">
                <Icon name="more" size={12} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon"><Icon name="contacts" size={32} /></div>
          <div className="empty-title">Контактів не знайдено</div>
          <div className="empty-sub">Додайте перший контакт або змініть фільтр</div>
        </div>
      )}

      {/* Add Contact Modal */}
      {showAdd && (
        <div className="overlay" onClick={() => setShowAdd(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <div className="modal-title">Новий контакт</div>
                <div className="modal-subtitle">Додайте інформацію про контакт</div>
              </div>
              <button className="btn btn-ghost btn-icon-sm" onClick={() => setShowAdd(false)}>
                <Icon name="x" size={14} />
              </button>
            </div>
            <div className="modal-body">
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div className="form-group">
                  <label className="form-label">Ім'я <span className="form-required">*</span></label>
                  <input type="text" className="input" placeholder="Введіть ім'я" />
                </div>
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <input type="email" className="input" placeholder="email@example.com" />
                </div>
                <div className="form-group">
                  <label className="form-label">Телефон</label>
                  <input type="tel" className="input" placeholder="+380501234567" />
                </div>
                <div className="form-group">
                  <label className="form-label">Компанія</label>
                  <input type="text" className="input" placeholder="Назва компанії" />
                </div>
                <div style={{ display: 'flex', gap: '10px', marginTop: '8px' }}>
                  <button className="btn btn-primary" style={{ flex: 1 }}>Створити</button>
                  <button className="btn btn-secondary" onClick={() => setShowAdd(false)}>Скасувати</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
