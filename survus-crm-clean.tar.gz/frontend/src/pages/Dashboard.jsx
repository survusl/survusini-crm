import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import client from '../api/client'
import Icon from '../components/Icons'

const STATUS_MAP = {
  new: { label: 'Новий', cls: 'badge-new', color: '#2563eb' },
  replied: { label: 'Відповів', cls: 'badge-replied', color: '#b45309' },
  paid: { label: 'Оплачено', cls: 'badge-paid', color: '#15803d' },
  canceled: { label: 'Скасовано', cls: 'badge-canceled', color: '#dc2626' },
}

function AnimatedNumber({ value }) {
  const [display, setDisplay] = useState(0)
  const ref = useRef(null)
  useEffect(() => {
    if (value === undefined || value === null) return
    const target = Number(value) || 0
    const duration = 600
    const start = Date.now()
    const startVal = 0
    const tick = () => {
      const elapsed = Date.now() - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setDisplay(Math.round(startVal + (target - startVal) * eased))
      if (progress < 1) ref.current = requestAnimationFrame(tick)
    }
    ref.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(ref.current)
  }, [value])
  return <span>{display}</span>
}

function StatCard({ label, icon, color, bg, value, sub, trend, style: extraStyle }) {
  return (
    <div className="stat-card" style={{ '--stat-color': color, ...extraStyle }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div className="stat-icon" style={{ background: bg, color }}>
          <Icon name={icon} size={16} />
        </div>
        {trend !== undefined && (
          <div className={`stat-change ${trend >= 0 ? 'up' : 'down'}`}>
            <Icon name={trend >= 0 ? 'trending_up' : 'trending_down'} size={11} />
            {Math.abs(trend)}%
          </div>
        )}
      </div>
      <div className="stat-value">
        {typeof value === 'string' ? value : <AnimatedNumber value={value} />}
      </div>
      <div className="stat-label">{label}</div>
      {sub && <div style={{ fontSize: '11px', color: 'var(--text-3)', marginTop: '5px' }}>{sub}</div>}
    </div>
  )
}

function SparkLine({ data, color = '#16a34a', height = 36 }) {
  if (!data || data.length < 2) return null
  const max = Math.max(...data, 1)
  const w = 100, h = height
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w
    const y = h - (v / max) * (h - 4) - 2
    return `${x},${y}`
  }).join(' ')
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`sg-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.15" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon
        points={`0,${h} ${pts} ${w},${h}`}
        fill={`url(#sg-${color.replace('#','')})`}
      />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function ProgressRing({ value, max, color, size = 56 }) {
  const r = (size - 6) / 2
  const circ = 2 * Math.PI * r
  const pct = max > 0 ? value / max : 0
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color + '20'} strokeWidth="5" />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="5"
        strokeDasharray={`${pct * circ} ${circ}`}
        strokeDashoffset={circ / 4}
        strokeLinecap="round"
        style={{ transition: 'stroke-dasharray 0.8s cubic-bezier(0.16,1,0.3,1)' }}
      />
      <text x={size/2} y={size/2 + 1} textAnchor="middle" dominantBaseline="middle"
        fontSize="11" fontWeight="800" fill={color} fontFamily="Inter, sans-serif">
        {Math.round(pct * 100)}%
      </text>
    </svg>
  )
}

function formatDate(str) {
  if (!str) return '—'
  return new Date(str).toLocaleDateString('uk-UA', { day: '2-digit', month: 'short' })
}

function formatTime(str) {
  if (!str) return '—'
  return new Date(str).toLocaleString('uk-UA', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
}

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const [leads, setLeads] = useState([])
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  const workspace = (() => {
    try { return JSON.parse(localStorage.getItem('survus_workspace') || '{}') }
    catch { return {} }
  })()

  const plan = workspace?.subscription_plan || 'free'
  const planLabel = plan === 'pro_plus' ? 'PRO+' : plan === 'pro' ? 'PRO' : null
  const subUntil = workspace?.subscription_until
  const daysLeft = subUntil ? Math.ceil((new Date(subUntil) - new Date()) / 86400000) : null

  const fetchAll = async () => {
    try {
      const [sRes, lRes, tRes] = await Promise.all([
        client.get('/dashboard/stats'),
        client.get('/leads'),
        client.get('/tasks'),
      ])
      setStats(sRes.data)
      setLeads(Array.isArray(lRes.data) ? lRes.data : [])
      setTasks(Array.isArray(tRes.data) ? tRes.data : [])
    } catch {}
    finally { setLoading(false) }
  }

  useEffect(() => {
    fetchAll()
    const iv = setInterval(fetchAll, 60000)
    return () => clearInterval(iv)
  }, [])

  if (loading) return <div className="loading-center"><div className="spinner" /></div>

  const total = stats?.total || 0
  const paid = stats?.paid_count || 0
  const newCount = stats?.new_count || 0
  const replied = stats?.replied_count || 0
  const canceled = stats?.canceled_count || 0
  const convRate = total > 0 ? Math.round((paid / total) * 100) : 0
  const recentLeads = leads.slice(0, 5)
  const pendingTasks = tasks.filter(t => !t.is_completed).slice(0, 4)
  const overdueTasks = tasks.filter(t => t.is_overdue && !t.is_completed).length

  // Sparkline data - zero for new workspaces
  const sparkData = total > 0 ? [2, 4, 3, 6, 5, 8, newCount || 3] : [0, 0, 0, 0, 0, 0, 0]

  const greeting = () => {
    const h = new Date().getHours()
    if (h < 12) return 'Доброго ранку'
    if (h < 17) return 'Доброго дня'
    return 'Доброго вечора'
  }

  return (
    <div className="fade-up">
      {/* Hero header */}
      <div style={S.hero}>
        <div style={S.heroLeft}>
          <div style={S.heroGreeting}>{greeting()}</div>
          <h1 style={S.heroTitle}>{workspace.company_name || 'SURVUS CRM'}</h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '5px', flexWrap: 'wrap' }}>
            <p style={{ ...S.heroSub, margin: 0 }}>
              {new Date().toLocaleDateString('uk-UA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </p>
            {planLabel && (
              <span style={{ display: 'inline-flex', alignItems: 'center', padding: '2px 8px', borderRadius: '20px', fontSize: '10.5px', fontWeight: '700', background: plan === 'pro_plus' ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'linear-gradient(135deg,#7c3aed,#4f46e5)', color: '#fff', letterSpacing: '0.02em' }}>
                {planLabel}
              </span>
            )}
            {daysLeft !== null && daysLeft <= 7 && daysLeft > 0 && (
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '3px', padding: '2px 8px', borderRadius: '20px', fontSize: '10.5px', fontWeight: '600', background: '#fef3c7', color: '#b45309' }}>
                <Icon name="clock" size={9} /> {daysLeft} дн.
              </span>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          {overdueTasks > 0 && (
            <div style={S.alertBadge}>
              <Icon name="warning" size={12} />
              {overdueTasks} прострочено
            </div>
          )}
          <button onClick={fetchAll} className="btn btn-secondary btn-sm">
            <Icon name="refresh" size={12} /> Оновити
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <StatCard 
          label="Всього лідів" 
          icon="leads" 
          color="var(--green-glow)" 
          bg="rgba(61,214,140,0.1)" 
          value={total} 
          trend={total > 0 ? 12 : 0} 
        />
        <StatCard 
          label="Нові ліди" 
          icon="plus" 
          color="var(--green-accent)" 
          bg="rgba(45,95,74,0.15)" 
          value={newCount} 
          sub="Очікують обробки" 
        />
        <StatCard 
          label="Оплачено" 
          icon="dollar" 
          color="var(--green-glow)" 
          bg="rgba(61,214,140,0.12)" 
          value={paid} 
          trend={paid > 0 ? 8 : 0} 
        />
        <StatCard 
          label="Конверсія" 
          icon="pie_chart" 
          color="var(--green-accent)" 
          bg="rgba(45,95,74,0.15)" 
          value={`${convRate}%`} 
          sub="Нові → Оплачено" 
        />
      </div>

      {/* Main grid */}
      <div style={S.mainGrid}>
        {/* Left column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {/* Recent leads */}
          <div className="card">
            <div className="card-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--primary)' }} />
                <span className="card-title">Останні ліди</span>
              </div>
              <button onClick={() => navigate('/leads')} className="btn btn-ghost btn-sm" style={{ color: 'var(--primary)', fontSize: '12px' }}>
                Всі ліди <Icon name="chevron_right" size={11} />
              </button>
            </div>
            {recentLeads.length === 0 ? (
              <div className="empty-state" style={{ padding: '40px' }}>
                <div className="empty-icon"><Icon name="leads" size={28} /></div>
                <div className="empty-title">Лідів ще немає</div>
                <div className="empty-sub">Додайте першого ліда через кнопку в меню</div>
              </div>
            ) : recentLeads.map((lead, i) => {
              const s = STATUS_MAP[lead.status] || { label: lead.status, cls: 'badge-neutral', color: 'var(--text-3)' }
              return (
                <div key={lead.id} onClick={() => navigate(`/leads/${lead.id}`)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: '12px',
                    padding: '11px 20px', cursor: 'pointer', transition: 'background 0.1s',
                    borderBottom: i < recentLeads.length - 1 ? '1px solid var(--border-2)' : 'none',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <div style={{ width: '32px', height: '32px', borderRadius: '9px', background: s.color + '15', color: s.color, fontSize: '13px', fontWeight: '700', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    {lead.name[0]?.toUpperCase()}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '13.5px', fontWeight: '600', color: 'var(--text)', marginBottom: '1px' }}>{lead.name}</div>
                    <div style={{ fontSize: '11.5px', color: 'var(--text-3)' }}>@{lead.username}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px' }}>
                    <span className={`badge ${s.cls}`}>{s.label}</span>
                    <span style={{ fontSize: '10.5px', color: 'var(--text-4)' }}>{formatDate(lead.created_at)}</span>
                    {lead.amount > 0 && <span style={{ fontSize: '11px', fontWeight: '700', color: '#15803d' }}>${Number(lead.amount).toFixed(0)}</span>}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Status breakdown */}
          <div className="card">
            <div className="card-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#7c3aed' }} />
                <span className="card-title">Розподіл статусів</span>
              </div>
              <span style={{ fontSize: '11.5px', color: 'var(--text-3)' }}>{total} лідів</span>
            </div>
            <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {[
                { label: 'Нові', value: newCount, color: 'var(--green-accent)' },
                { label: 'Відповіли', value: replied, color: 'var(--green-glow)' },
                { label: 'Оплачено', value: paid, color: 'var(--green-glow)' },
                { label: 'Скасовано', value: canceled, color: '#dc2626' },
              ].map(item => {
                const pct = total > 0 ? (item.value / total) * 100 : 0
                return (
                  <div key={item.label}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
                        <div style={{ width: '8px', height: '8px', borderRadius: '2px', background: item.color }} />
                        <span style={{ fontSize: '12.5px', color: 'var(--text-2)', fontWeight: '500' }}>{item.label}</span>
                      </div>
                      <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                        <span style={{ fontSize: '12.5px', fontWeight: '700', color: item.color }}>{item.value}</span>
                        <span style={{ fontSize: '11px', color: 'var(--text-3)', width: '30px', textAlign: 'right' }}>{Math.round(pct)}%</span>
                      </div>
                    </div>
                    <div style={{ height: '5px', background: 'rgba(61,214,140,0.1)', borderRadius: '3px', overflow: 'hidden' }}>
                      <div style={{ height: '100%', width: `${pct}%`, background: item.color, borderRadius: '3px', transition: 'width 0.8s cubic-bezier(0.16,1,0.3,1)' }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {/* Conversion + sparkline */}
          <div className="card" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
              <div>
                <div style={{ fontSize: '12px', color: 'var(--text-3)', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '4px' }}>Конверсія</div>
                <div style={{ fontSize: '28px', fontWeight: '800', color: 'var(--text)', letterSpacing: '-0.5px' }}>{convRate}%</div>
              </div>
              <ProgressRing value={paid} max={total > 0 ? total : 1} color="var(--green-glow)" size={60} />
            </div>
            <div style={{ marginBottom: '6px' }}>
              <SparkLine data={sparkData} color="var(--green-glow)" height={40} />
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'].map(d => (
                <span key={d} style={{ fontSize: '10px', color: 'var(--text-4)', flex: 1, textAlign: 'center' }}>{d}</span>
              ))}
            </div>
          </div>

          {/* Tasks */}
          <div className="card" style={{ flex: 1 }}>
            <div className="card-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: overdueTasks > 0 ? '#dc2626' : '#16a34a' }} />
                <span className="card-title">Завдання</span>
              </div>
              <button onClick={() => navigate('/tasks')} className="btn btn-ghost btn-sm" style={{ color: 'var(--primary)', fontSize: '12px' }}>
                Всі <Icon name="chevron_right" size={11} />
              </button>
            </div>
            {pendingTasks.length === 0 ? (
              <div className="empty-state" style={{ padding: '32px' }}>
                <div className="empty-icon"><Icon name="tasks" size={24} /></div>
                <div className="empty-title">Завдань немає</div>
              </div>
            ) : pendingTasks.map((task, i) => {
              const overdue = task.is_overdue && !task.is_completed
              return (
                <div key={task.id} style={{
                  display: 'flex', alignItems: 'center', gap: '10px',
                  padding: '10px 20px',
                  borderBottom: i < pendingTasks.length - 1 ? '1px solid var(--border-2)' : 'none',
                  borderLeft: `3px solid ${overdue ? '#dc2626' : 'var(--primary)'}`,
                }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: '13px', fontWeight: '500', color: 'var(--text)', marginBottom: '2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{task.title}</div>
                    <div style={{ fontSize: '11px', color: overdue ? '#dc2626' : 'var(--text-3)', display: 'flex', alignItems: 'center', gap: '3px' }}>
                      <Icon name="clock" size={9} />
                      {overdue ? 'Прострочено · ' : ''}{formatTime(task.due_date)}
                    </div>
                  </div>
                  {overdue && <Icon name="warning" size={13} color="#dc2626" />}
                </div>
              )
            })}
          </div>

          {/* Quick stats */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {[
              { label: 'Відповіли', value: replied, color: 'var(--green-glow)', bg: 'rgba(61,214,140,0.08)', icon: 'message' },
              { label: 'Скасовано', value: canceled, color: '#dc2626', bg: 'rgba(220,38,38,0.08)', icon: 'x' },
            ].map(item => (
              <div key={item.label} style={{ background: item.bg, borderRadius: 'var(--radius)', padding: '14px 16px', border: `1px solid ${item.color}20` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                  <Icon name={item.icon} size={13} color={item.color} />
                  <span style={{ fontSize: '11.5px', color: item.color, fontWeight: '600' }}>{item.label}</span>
                </div>
                <div style={{ fontSize: '24px', fontWeight: '800', color: item.color, letterSpacing: '-0.5px' }}>{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const S = {
  hero: {
    display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
    marginBottom: '24px', flexWrap: 'wrap', gap: '12px',
  },
  heroLeft: {},
  heroGreeting: { fontSize: '12px', fontWeight: '600', color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '4px' },
  heroTitle: { fontSize: '22px', fontWeight: '800', color: 'var(--text)', letterSpacing: '-0.4px', lineHeight: 1.2 },
  heroSub: { fontSize: '12.5px', color: 'var(--text-3)', marginTop: '4px' },
  alertBadge: {
    display: 'flex', alignItems: 'center', gap: '5px',
    padding: '5px 10px', borderRadius: '20px',
    background: '#fef2f2', color: '#dc2626',
    fontSize: '12px', fontWeight: '600',
    border: '1px solid #fecaca',
  },
  mainGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' },
}
