import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthModal from '../components/AuthModal';
import Icon from '../components/Icons';
import '../landing.css';

function AnimatedNumber({ value, prefix = '', suffix = '' }) {
  const [display, setDisplay] = useState(0);
  const ref = useRef(null);
  
  useEffect(() => {
    if (value === undefined || value === null) return;
    const target = Number(value) || 0;
    const duration = 1500;
    const start = Date.now();
    const startVal = 0;
    
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(startVal + (target - startVal) * eased));
      if (progress < 1) ref.current = requestAnimationFrame(tick);
    };
    
    ref.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(ref.current);
  }, [value]);
  
  return <span>{prefix}{display.toLocaleString()}{suffix}</span>;
}

function PixelBadge({ children, pulse = false }) {
  return (
    <span className={`pixel-badge ${pulse ? 'pulse' : ''}`}>
      {children}
    </span>
  );
}

export default function Landing() {
  const [scrollY, setScrollY] = useState(0);
  const [showAuth, setShowAuth] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -80px 0px' }
    );

    const elements = document.querySelectorAll('.scroll-animate');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleGetStarted = () => setShowAuth(true);

  const features = [
    { icon: 'users', title: 'Управління клієнтами', desc: 'Повний контроль над базою, історією взаємодій та статусами в реальному часі' },
    { icon: 'dollar', title: 'Фінансова аналітика', desc: 'Відстежуйте доходи, витрати та прибуток з точністю до копійки' },
    { icon: 'trending_up', title: 'Прогнозування', desc: 'AI-алгоритми для передбачення трендів та оптимізації стратегії' },
    { icon: 'activity', title: 'Автоматизація', desc: 'Розумні workflow, тригери та автоматичний розподіл завдань' },
    { icon: 'bar_chart', title: 'Воронка продажів', desc: 'Візуалізація кожного етапу угоди від контакту до закриття' },
    { icon: 'lock', title: 'Безпека даних', desc: 'Шифрування, резервне копіювання та контроль доступу' }
  ];

  const metrics = [
    { label: 'REVENUE', value: 847250, trend: '+24%', color: 'success' },
    { label: 'CLIENTS', value: 1243, trend: '+18%', color: 'success' },
    { label: 'DEALS', value: 456, trend: '+32%', color: 'success' },
    { label: 'CONVERSION', value: 94, suffix: '%', trend: '+8%', color: 'success' }
  ];

  return (
    <div className="landing-dark-green">
      {/* Animated Background */}
      <div className="bg-animated">
        <div className="gradient-orb orb-1"></div>
        <div className="gradient-orb orb-2"></div>
        <div className="gradient-orb orb-3"></div>
        <div className="noise-overlay"></div>
        <div className="grid-pattern"></div>
      </div>

      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <div className="hero-grid">
            {/* Left: Content */}
            <div className="hero-content">
              <PixelBadge pulse>ONLINE</PixelBadge>
              
              <h1 className="hero-title fade-up">
                Контроль бізнесу<br />
                в одному<br />
                <span className="text-glow">інтерфейсі</span>
              </h1>
              
              <p className="hero-subtitle fade-up" style={{ animationDelay: '0.1s' }}>
                SURVUS — професійна CRM система для управління клієнтами, угодами та аналітикою.
                Бачте реальну картину: зростання, втрати, конверсії. Приймайте рішення на основі даних.
              </p>
              
              <div className="hero-cta fade-up" style={{ animationDelay: '0.2s' }}>
                <button className="btn-glow" onClick={handleGetStarted}>
                  <span>Почати безкоштовно</span>
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
                <button className="btn-ghost" onClick={() => {
                  document.getElementById('analytics').scrollIntoView({ behavior: 'smooth' });
                }}>
                  Дивитись демо
                </button>
              </div>

              {/* Quick Stats */}
              <div className="hero-stats fade-up" style={{ animationDelay: '0.3s' }}>
                {metrics.map((m, i) => (
                  <div key={i} className="stat-mini">
                    <div className="stat-mini-label">{m.label}</div>
                    <div className="stat-mini-value">
                      <AnimatedNumber value={m.value} suffix={m.suffix || ''} />
                    </div>
                    <div className="stat-mini-trend">{m.trend}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Dashboard Preview */}
            <div className="hero-visual fade-up" style={{ animationDelay: '0.2s' }}>
              <div className="dashboard-mockup">
                {/* Header */}
                <div className="mockup-header">
                  <div className="mockup-dots">
                    <span></span><span></span><span></span>
                  </div>
                  <div className="mockup-title">SURVUS CRM</div>
                  <PixelBadge>LIVE</PixelBadge>
                </div>

                {/* Body */}
                <div className="mockup-body">
                  {/* Metrics Grid */}
                  <div className="mockup-metrics">
                    <div className="metric-card">
                      <div className="metric-label">ДОХІД</div>
                      <div className="metric-value">
                        <AnimatedNumber value={847} prefix="$" suffix="K" />
                      </div>
                      <div className="metric-chart">
                        {[40, 55, 48, 65, 72, 68, 85, 92].map((h, i) => (
                          <div key={i} className="chart-bar" style={{ height: `${h}%`, animationDelay: `${i * 0.05}s` }}></div>
                        ))}
                      </div>
                    </div>

                    <div className="metric-card">
                      <div className="metric-label">КЛІЄНТИ</div>
                      <div className="metric-value">
                        <AnimatedNumber value={1243} />
                      </div>
                      <div className="metric-progress">
                        <div className="progress-fill" style={{ width: '78%' }}></div>
                      </div>
                    </div>

                    <div className="metric-card">
                      <div className="metric-label">УГОДИ</div>
                      <div className="metric-value">
                        <AnimatedNumber value={456} />
                      </div>
                      <div className="metric-ring">
                        <svg viewBox="0 0 36 36">
                          <circle cx="18" cy="18" r="16" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="3"/>
                          <circle cx="18" cy="18" r="16" fill="none" stroke="var(--green-glow)" strokeWidth="3"
                            strokeDasharray="75 100" strokeLinecap="round" transform="rotate(-90 18 18)"/>
                        </svg>
                        <span>75%</span>
                      </div>
                    </div>
                  </div>

                  {/* Deals List */}
                  <div className="mockup-deals">
                    <div className="deals-header">
                      <span>Активні угоди</span>
                      <PixelBadge>24</PixelBadge>
                    </div>
                    {[
                      { name: 'Tech Corp', amount: 45000, status: 'active', progress: 85 },
                      { name: 'Digital Agency', amount: 32000, status: 'active', progress: 60 },
                      { name: 'StartUp Inc', amount: 28000, status: 'pending', progress: 40 }
                    ].map((deal, i) => (
                      <div key={i} className="deal-row" style={{ animationDelay: `${i * 0.1}s` }}>
                        <div className="deal-info">
                          <div className="deal-name">{deal.name}</div>
                          <div className="deal-amount">${deal.amount.toLocaleString()}</div>
                        </div>
                        <div className="deal-progress-bar">
                          <div className="deal-progress-fill" style={{ width: `${deal.progress}%` }}></div>
                        </div>
                        <span className={`deal-status status-${deal.status}`}>
                          {deal.status === 'active' ? 'ACTIVE' : 'PENDING'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section scroll-animate">
        <div className="container">
          <div className="section-header">
            <PixelBadge>FEATURES</PixelBadge>
            <h2 className="section-title">Все для управління бізнесом</h2>
            <p className="section-subtitle">
              Потужні інструменти для контролю продажів, клієнтів та аналітики в одній системі
            </p>
          </div>

          <div className="features-grid">
            {features.map((feature, idx) => (
              <div key={idx} className="feature-card scroll-animate" style={{ animationDelay: `${idx * 0.1}s` }}>
                <div className="feature-icon">
                  <Icon name={feature.icon} size={28} color="#fff" />
                </div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-desc">{feature.desc}</p>
                <div className="feature-glow"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Analytics Section */}
      <section id="analytics" className="analytics-section scroll-animate">
        <div className="container">
          <div className="section-header">
            <PixelBadge pulse>DATA</PixelBadge>
            <h2 className="section-title">Аналітика в реальному часі</h2>
            <p className="section-subtitle">
              Відстежуйте ключові метрики, прогнозуйте тренди та приймайте рішення на основі даних
            </p>
          </div>

          <div className="analytics-grid">
            {/* Revenue Chart */}
            <div className="analytics-card large scroll-animate">
              <div className="analytics-header">
                <div>
                  <div className="analytics-label">ДОХІД</div>
                  <div className="analytics-value">
                    <AnimatedNumber value={847250} prefix="$" />
                  </div>
                </div>
                <div className="analytics-trend success">+24.5%</div>
              </div>
              <div className="line-chart">
                <svg viewBox="0 0 400 120" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--green-glow)" stopOpacity="0.3"/>
                      <stop offset="100%" stopColor="var(--green-glow)" stopOpacity="0"/>
                    </linearGradient>
                  </defs>
                  <path
                    d="M 0 80 L 50 70 L 100 75 L 150 55 L 200 60 L 250 40 L 300 35 L 350 20 L 400 15"
                    fill="url(#chartGradient)"
                    stroke="none"
                  />
                  <path
                    d="M 0 80 L 50 70 L 100 75 L 150 55 L 200 60 L 250 40 L 300 35 L 350 20 L 400 15"
                    fill="none"
                    stroke="var(--green-glow)"
                    strokeWidth="2"
                    strokeLinecap="round"
                    className="chart-line"
                  />
                </svg>
                <div className="chart-labels">
                  {['Січ', 'Лют', 'Бер', 'Кві', 'Тра', 'Чер', 'Лип', 'Сер'].map((m, i) => (
                    <span key={i}>{m}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Conversion */}
            <div className="analytics-card scroll-animate" style={{ animationDelay: '0.1s' }}>
              <div className="analytics-label">КОНВЕРСІЯ</div>
              <div className="analytics-value">
                <AnimatedNumber value={94} suffix="%" />
              </div>
              <div className="conversion-ring">
                <svg viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8"/>
                  <circle cx="50" cy="50" r="40" fill="none" stroke="var(--green-glow)" strokeWidth="8"
                    strokeDasharray="235 251" strokeLinecap="round" transform="rotate(-90 50 50)"
                    className="ring-progress"/>
                </svg>
                <div className="ring-center">
                  <PixelBadge>HIGH</PixelBadge>
                </div>
              </div>
            </div>

            {/* Distribution */}
            <div className="analytics-card scroll-animate" style={{ animationDelay: '0.2s' }}>
              <div className="analytics-label">РОЗПОДІЛ</div>
              <div className="distribution-bars">
                {[
                  { label: 'Нові', value: 35, color: 'var(--green-glow)' },
                  { label: 'Активні', value: 48, color: 'var(--green-accent)' },
                  { label: 'Закриті', value: 17, color: 'var(--green-dark)' }
                ].map((item, i) => (
                  <div key={i} className="dist-row" style={{ animationDelay: `${i * 0.1}s` }}>
                    <div className="dist-label">{item.label}</div>
                    <div className="dist-bar">
                      <div className="dist-fill" style={{ width: `${item.value}%`, background: item.color }}></div>
                    </div>
                    <div className="dist-value">{item.value}%</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="benefits-section scroll-animate">
        <div className="container">
          <div className="benefits-grid">
            {[
              { title: 'Швидкість', desc: 'Миттєвий відгук інтерфейсу. Оптимізована продуктивність для роботи з великими обсягами даних.' },
              { title: 'Надійність', desc: 'Шифрування даних, автоматичне резервне копіювання та 99.9% uptime гарантія.' },
              { title: 'Масштабованість', desc: 'Від стартапу до корпорації. Система росте разом з вашим бізнесом без обмежень.' }
            ].map((benefit, i) => (
              <div key={i} className="benefit-card scroll-animate" style={{ animationDelay: `${i * 0.1}s` }}>
                <h3 className="benefit-title">{benefit.title}</h3>
                <p className="benefit-desc">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section scroll-animate">
        <div className="container">
          <div className="cta-content">
            <PixelBadge pulse>START NOW</PixelBadge>
            <h2 className="cta-title">Готові почати?</h2>
            <p className="cta-subtitle">
              Приєднуйтесь до сотень компаній, які вже керують своїм бізнесом через SURVUS
            </p>
            <button className="btn-glow large" onClick={handleGetStarted}>
              <span>Спробувати безкоштовно</span>
              <svg width="20" height="20" viewBox="0 0 16 16" fill="none">
                <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* Auth Modal */}
      <AuthModal show={showAuth} onClose={() => setShowAuth(false)} />
    </div>
  );
}
