import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import client from '../api/client'
import Icon from '../components/Icons'

const STATUS_MAP = {
  new: { label: 'Новий', cls: 'badge-new', color: '#2563eb', bg: '#eff6ff' },
  replied: { label: 'Відповів', cls: 'badge-replied', color: '#b45309', bg: '#fffbeb' },
  paid: { label: 'Оплачено', cls: 'badge-paid', color: '#15803d', bg: '#f0fdf4' },
  canceled: { label: 'Скасовано', cls: 'badge-canceled', color: '#dc2626', bg: '#fef2f2' },
}

const TRANSITIONS = {
  new: ['replied', 'paid', 'canceled'],
  replied: ['paid', 'canceled'],
  paid: [],
  canceled: [],
}

function formatDateTime(str) {
  if (!str) return '—'
  return new Date(str).toLocaleString('uk-UA', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

export default function LeadCard() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [lead, setLead] = useState(null)
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(null)
  const [error, setError] = useState(null)
  const [editNote, setEditNote] = useState(false)
  const [noteVal, setNoteVal] = useState('')
  const [savingNote, setSavingNote] = useState(false)
  const [editAmount, setEditAmount] = useState(false)
  const [amountVal, setAmountVal] = useState('')
  const [savingAmount, setSavingAmount] = useState(false)

  const fetchLead = async () => {
    try {
      const res = await client.get(`/leads/${id}`)
      setLead(res.data)
      setHistory(res.data.status_history || [])
      setNoteVal(res.data.note || '')
      setAmountVal(res.data.amount != null ? String(res.data.amount) : '')
      setError(null)
    } catch { setError('Лід не знайдено') }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchLead() }, [id])

  const handleStatus = async (newStatus) => {
    setUpdating(newStatus)
    try {
      await client.patch(`/leads/${id}/status`, { status: newStatus })
      await fetchLead()
    } catch (e) { setError(e?.response?.data?.error || 'Помилка оновлення') }
    finally { setUpdating(null) }
  }

  if (loading) return <div className="loading-center"><div className="spinner" /></div>

  if (error && !lead) return (
    <div>
      <button onClick={() => navigate('/leads')} className="btn btn-secondary" style={{ marginBottom: '16px' }}>
        <Icon name="arrow_left" size={13} /> Назад
      </button>
      <div className="form-error"><Icon name="warning" size={13} />{error}</div>
    </div>
  )

  const s = STATUS_MAP[lead.status] || { label: lead.status, cls: 'badge-neutral', color: 'var(--text-2)', bg: 'var(--surface-2)' }
  const allowedNext = TRANSITIONS[lead.status] || []

  return (
    <div className="fade-up" style={{ maxWidth: '760px' }}>
      <button onClick={() => navigate('/leads')} className="btn btn-secondary btn-sm" style={{ marginBottom: '18px' }}>
        <Icon name="arrow_left" size={12} /> Назад до лідів
      </button>

      {/* Main card */}
      <div className="card" style={{ marginBottom: '14px' }}>
        {/* Header */}
        <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border-2)', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: s.bg, color: s.color, fontSize: '18px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              {lead.name[0]?.toUpperCase()}
            </div>
            <div>
              <h2 style={{ fontSize: '18px', fontWeight: '700', color: 'var(--text)', margin: '0 0 5px' }}>{lead.name}</h2>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                <span style={{ fontSize: '13px', color: 'var(--text-3)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Icon name="instagram" size={12} /> {lead.username}
                </span>
                <span style={{ color: 'var(--border)' }}>·</span>
                <span className={`badge ${s.cls}`}>{s.label}</span>
              </div>
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '11px', color: 'var(--text-3)', marginBottom: '2px' }}>Створено</div>
            <div style={{ fontSize: '12.5px', fontWeight: '500', color: 'var(--text-2)' }}>{formatDateTime(lead.created_at)}</div>
            {/* Amount display */}
            <div style={{ marginTop: '10px' }}>
              {editAmount ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: '8px', top: '50%', transform: 'translateY(-50%)', fontSize: '13px', fontWeight: '600', color: 'var(--text-3)' }}>$</span>
                    <input
                      type="number" min="0" step="0.01"
                      value={amountVal}
                      onChange={e => setAmountVal(e.target.value)}
                      className="input input-sm"
                      style={{ paddingLeft: '22px', width: '100px', textAlign: 'right' }}
                      autoFocus
                    />
                  </div>
                  <button
                    className="btn btn-primary btn-sm"
                    disabled={savingAmount}
                    onClick={async () => {
                      setSavingAmount(true)
                      try {
                        await client.patch(`/leads/${id}/amount`, { amount: parseFloat(amountVal) || 0 })
                        setEditAmount(false)
                        await fetchLead()
                      } catch {}
                      finally { setSavingAmount(false) }
                    }}
                  >
                    {savingAmount ? '...' : <Icon name="check" size={12} />}
                  </button>
                  <button className="btn btn-ghost btn-sm" onClick={() => { setEditAmount(false); setAmountVal(String(lead.amount || '')) }}>
                    <Icon name="x" size={12} />
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => setEditAmount(true)}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', cursor: 'pointer', padding: '5px 10px', borderRadius: '8px', background: lead.amount > 0 ? '#f0fdf4' : 'var(--surface-2)', border: `1px solid ${lead.amount > 0 ? '#bbf7d0' : 'var(--border)'}`, transition: 'all 0.15s' }}
                  title="Клікніть щоб змінити суму"
                >
                  <span style={{ fontSize: '16px', fontWeight: '800', color: lead.amount > 0 ? '#15803d' : 'var(--text-3)' }}>
                    {lead.amount > 0 ? `$${Number(lead.amount).toFixed(2)}` : '$ —'}
                  </span>
                  <Icon name="edit" size={11} color={lead.amount > 0 ? '#15803d' : 'var(--text-4)'} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Note */}
        <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border-2)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>Нотатка</span>
            <button onClick={() => setEditNote(!editNote)} className="btn btn-ghost btn-sm" style={{ color: 'var(--primary)', fontSize: '12px' }}>
              <Icon name="edit" size={11} /> {editNote ? 'Скасувати' : 'Редагувати'}
            </button>
          </div>
          {editNote ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <textarea value={noteVal} onChange={e => setNoteVal(e.target.value)} rows={3} className="input" style={{ resize: 'vertical' }} placeholder="Додайте нотатку..." />
              <button onClick={async () => { setSavingNote(true); try { await client.patch(`/leads/${id}/status`, { status: lead.status }); setEditNote(false); await fetchLead() } catch {} finally { setSavingNote(false) } }} className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-end' }} disabled={savingNote}>
                {savingNote ? 'Зберігаємо...' : 'Зберегти'}
              </button>
            </div>
          ) : (
            <p style={{ color: lead.note ? 'var(--text-2)' : 'var(--text-3)', fontSize: '13.5px', lineHeight: '1.6', fontStyle: lead.note ? 'normal' : 'italic' }}>
              {lead.note || 'Нотатка відсутня'}
            </p>
          )}
        </div>

        {/* Status change */}
        {allowedNext.length > 0 && (
          <div style={{ padding: '16px 24px' }}>
            <div style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '10px' }}>Змінити статус</div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
              {allowedNext.map(ns => {
                const nm = STATUS_MAP[ns]
                return (
                  <button key={ns} onClick={() => handleStatus(ns)} disabled={!!updating} style={{
                    padding: '8px 18px', borderRadius: 'var(--radius)', cursor: 'pointer',
                    border: `1.5px solid ${nm?.color || 'var(--border)'}`,
                    background: updating === ns ? nm?.bg : 'var(--surface)',
                    color: nm?.color || 'var(--text-2)',
                    fontSize: '13px', fontWeight: '600',
                    opacity: updating && updating !== ns ? 0.5 : 1,
                    transition: 'all 0.15s',
                  }}>
                    {updating === ns ? '...' : nm?.label || ns}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {error && <div className="form-error" style={{ margin: '0 24px 16px' }}><Icon name="warning" size={13} />{error}</div>}
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="card">
          <div className="card-header">
            <span className="card-title">Історія статусів</span>
            <span className="badge badge-neutral">{history.length} змін</span>
          </div>
          <div style={{ padding: '16px 24px' }} className="timeline">
            {history.map((entry, i) => {
              const from = STATUS_MAP[entry.old_status]
              const to = STATUS_MAP[entry.new_status]
              return (
                <div key={entry.id || i} className="timeline-item">
                  <div className="timeline-dot" />
                  {i < history.length - 1 && <div className="timeline-line" />}
                  <div className="timeline-content">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                      <span className={`badge ${from?.cls || 'badge-neutral'}`}>{from?.label || entry.old_status}</span>
                      <Icon name="arrow_right" size={12} color="var(--text-3)" />
                      <span className={`badge ${to?.cls || 'badge-neutral'}`}>{to?.label || entry.new_status}</span>
                    </div>
                    <div style={{ fontSize: '11.5px', color: 'var(--text-3)', marginTop: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Icon name="clock" size={10} />{formatDateTime(entry.changed_at)}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
