import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import client from '../api/client'
import QuickAddLead from '../components/QuickAddLead'
import Icon from '../components/Icons'

const FILTERS = [
  { key: 'All', label: 'Всі' },
  { key: 'New', label: 'Нові' },
  { key: 'Replied', label: 'Відповіли' },
  { key: 'Paid', label: 'Оплачено' },
  { key: 'Canceled', label: 'Скасовано' },
]

const STATUS_MAP = {
  new: { label: 'Новий', cls: 'badge-new' },
  replied: { label: 'Відповів', cls: 'badge-replied' },
  paid: { label: 'Оплачено', cls: 'badge-paid' },
  canceled: { label: 'Скасовано', cls: 'badge-canceled' },
}

function formatDate(str) {
  if (!str) return '—'
  return new Date(str).toLocaleDateString('uk-UA', { day: '2-digit', month: 'short', year: 'numeric' })
}

export default function Leads() {
  const [leads, setLeads] = useState([])
  const [filter, setFilter] = useState('All')
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const navigate = useNavigate()

  const fetchLeads = async (status) => {
    setLoading(true)
    try {
      const params = status !== 'All' ? { status: status.toLowerCase() } : {}
      const res = await client.get('/leads', { params })
      setLeads(Array.isArray(res.data) ? res.data : [])
    } catch { setLeads([]) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchLeads(filter) }, [filter])

  const filtered = search.trim()
    ? leads.filter(l =>
        l.name.toLowerCase().includes(search.toLowerCase()) ||
        l.username.toLowerCase().includes(search.toLowerCase()) ||
        (l.note || '').toLowerCase().includes(search.toLowerCase())
      )
    : leads

  return (
    <div className="fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">Ліди</h1>
          <p className="page-subtitle">{leads.length} лідів · {filtered.length} показано</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn btn-primary">
          <Icon name="plus" size={13} /> Додати лід
        </button>
      </div>

      {/* Search + filters */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '16px', flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: '1', minWidth: '200px', maxWidth: '300px' }}>
          <span style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-3)', display: 'flex', pointerEvents: 'none' }}>
            <Icon name="search" size={13} />
          </span>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Пошук лідів..."
            className="input input-sm"
            style={{ paddingLeft: '32px' }}
          />
        </div>
        <div className="filter-pills">
          {FILTERS.map(f => (
            <button key={f.key} onClick={() => setFilter(f.key)} className={`pill${filter === f.key ? ' active' : ''}`}>
              {f.label}
              {filter === f.key && <span style={{ marginLeft: '4px', fontSize: '11px', opacity: 0.8 }}>({filtered.length})</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Клієнт</th>
              <th>Нікнейм</th>
              <th>Статус</th>
              <th>Сума</th>
              <th>Нотатка</th>
              <th>Дата</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} style={{ textAlign: 'center', padding: '40px' }}>
                <div style={{ display: 'flex', justifyContent: 'center' }}><div className="spinner" /></div>
              </td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7}>
                <div className="empty-state">
                  <div className="empty-icon"><Icon name="leads" size={36} /></div>
                  <div className="empty-title">Лідів не знайдено</div>
                  <div className="empty-sub">Спробуйте змінити фільтр або додайте нового ліда</div>
                </div>
              </td></tr>
            ) : filtered.map(lead => {
              const s = STATUS_MAP[lead.status] || { label: lead.status, cls: 'badge-neutral' }
              return (
                <tr key={lead.id} className="clickable" onClick={() => navigate(`/leads/${lead.id}`)}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{ width: '30px', height: '30px', borderRadius: '8px', background: 'var(--primary-light)', color: 'var(--primary)', fontSize: '12px', fontWeight: '700', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        {lead.name[0]?.toUpperCase()}
                      </div>
                      <span style={{ fontWeight: '600', color: 'var(--text)' }}>{lead.name}</span>
                    </div>
                  </td>
                  <td>
                    <span style={{ color: 'var(--text-3)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Icon name="instagram" size={11} />
                      {lead.username}
                    </span>
                  </td>
                  <td><span className={`badge ${s.cls}`}>{s.label}</span></td>
                  <td>
                    {lead.amount > 0
                      ? <span style={{ fontWeight: '700', color: '#15803d', fontSize: '13px' }}>${Number(lead.amount).toFixed(2)}</span>
                      : <span style={{ color: 'var(--text-4)', fontSize: '12px' }}>—</span>
                    }
                  </td>
                  <td style={{ color: 'var(--text-3)', maxWidth: '160px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '12.5px' }}>
                    {lead.note || <span style={{ color: 'var(--text-4)' }}>—</span>}
                  </td>
                  <td style={{ color: 'var(--text-3)', fontSize: '12px', whiteSpace: 'nowrap' }}>{formatDate(lead.created_at)}</td>
                  <td>
                    <Icon name="chevron_right" size={14} color="var(--text-4)" />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {showAdd && <QuickAddLead onClose={() => setShowAdd(false)} onAdded={() => { fetchLeads(filter); setShowAdd(false) }} />}
    </div>
  )
}
