import { useState, useEffect, useRef } from 'react'
import client from '../api/client'
import Icon from '../components/Icons'

function formatDate(str) {
  if (!str) return '—'
  return new Date(str).toLocaleDateString('uk-UA', { day: '2-digit', month: 'short' })
}

function AnimNum({ value }) {
  const [display, setDisplay] = useState(0)
  const raf = useRef(null)
  useEffect(() => {
    const target = Number(value) || 0
    const start = Date.now()
    const tick = () => {
      const p = Math.min((Date.now() - start) / 700, 1)
      setDisplay(Math.round(target * (1 - Math.pow(1 - p, 3))))
      if (p < 1) raf.current = requestAnimationFrame(tick)
    }
    raf.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf.current)
  }, [value])
  return <span>{display}</span>
}

function LineChart({ datasets, labels, height = 180 }) {
  const [hovered, setHovered] = useState(null)
  const [mounted, setMounted] = useState(false)
  useEffect(() => { const t = setTimeout(() => setMounted(true), 80); return () => clearTimeout(t) }, [])
  const W = 560, H = height, PAD = { top: 16, right: 16, bottom: 28, left: 36 }
  const cW = W - PAD.left - PAD.right, cH = H - PAD.top - PAD.bottom
  if (!datasets?.length || !labels?.length) return <div style={{ height, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--t4)', fontSize: '12px' }}>Немає даних</div>
  const maxVal = Math.max(...datasets.flatMap(d => d.data), 1)
  const xStep = cW / Math.max(labels.length - 1, 1)
  const toX = i => PAD.left + i * xStep
  const toY = v => PAD.top + cH - (v / maxVal) * cH
  const smooth = pts => {
    if (pts.length < 2) return ''
    let d = `M ${pts[0].x} ${pts[0].y}`
    for (let i = 1; i < pts.length; i++) {
      const cp = (pts[i-1].x + pts[i].x) / 2
      d += ` C ${cp} ${pts[i-1].y} ${cp} ${pts[i].y} ${pts[i].x} ${pts[i].y}`
    }
    return d
  }
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ overflow: 'visible', display: 'block' }}>
      <defs>{datasets.map((ds, di) => (
        <linearGradient key={di} id={`rg${di}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={ds.color} stopOpacity="0.16" />
          <stop offset="100%" stopColor={ds.color} stopOpacity="0" />
        </linearGradient>
      ))}</defs>
      {[0, 0.5, 1].map((t, i) => {
        const tick = Math.round(t * maxVal), y = toY(tick)
        return <g key={i}><line x1={PAD.left} y1={y} x2={W-PAD.right} y2={y} stroke="var(--b2)" strokeWidth="1" strokeDasharray={i===0?'none':'3,5'} /><text x={PAD.left-6} y={y+4} textAnchor="end" fontSize="9" fill="var(--t4)" fontFamily="Inter,sans-serif">{tick}</text></g>
      })}
      {labels.map((label, i) => <text key={i} x={toX(i)} y={H-4} textAnchor="middle" fontSize="9" fill="var(--t4)" fontFamily="Inter,sans-serif">{label}</text>)}
      {datasets.map((ds, di) => {
        const pts = ds.data.map((v, i) => ({ x: toX(i), y: toY(v) }))
        const line = smooth(pts)
        const area = line + ` L ${pts[pts.length-1].x} ${toY(0)} L ${pts[0].x} ${toY(0)} Z`
        return (
          <g key={di}>
            <path d={area} fill={`url(#rg${di})`} />
            <path d={line} fill="none" stroke={ds.color} strokeWidth="2" strokeLinecap="round"
              style={{ strokeDasharray: mounted ? 'none' : '1200', strokeDashoffset: mounted ? '0' : '1200', transition: 'stroke-dashoffset 1.1s cubic-bezier(0.16,1,0.3,1)' }} />
            {pts.map((pt, i) => (
              <g key={i}>
                <circle cx={pt.x} cy={pt.y} r="10" fill="transparent" style={{ cursor: 'pointer' }}
                  onMouseEnter={() => setHovered({ di, i, x: pt.x, y: pt.y, val: ds.data[i], label: labels[i] })}
                  onMouseLeave={() => setHovered(null)} />
                <circle cx={pt.x} cy={pt.y} r={hovered?.di===di&&hovered?.i===i ? 5 : 3.5}
                  fill={ds.color} stroke="#fff" strokeWidth="2"
                  style={{ transition: 'r 0.15s', filter: hovered?.di===di&&hovered?.i===i ? `drop-shadow(0 0 5px ${ds.color}90)` : 'none' }} />
              </g>
            ))}
          </g>
        )
      })}
      {hovered && (() => {
        const tx = Math.min(Math.max(hovered.x, 55), W-55), ty = Math.max(hovered.y-34, PAD.top)
        return <g><rect x={tx-38} y={ty-13} width="76" height="24" rx="6" fill="rgba(13,17,23,0.9)" /><text x={tx} y={ty+2} textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#fff" fontFamily="Inter,sans-serif">{hovered.val} · {hovered.label}</text></g>
      })()}
    </svg>
  )
}

function DonutChart({ segments, size = 100 }) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => { const t = setTimeout(() => setMounted(true), 120); return () => clearTimeout(t) }, [])
  const r = (size-12)/2, cx = size/2, cy = size/2, circ = 2*Math.PI*r
  const total = segments.reduce((s, sg) => s + sg.value, 0)
  let offset = circ/4
  const arcs = segments.map(sg => {
    const pct = total > 0 ? sg.value/total : 0
    const dash = mounted ? pct*circ : 0
    const arc = { ...sg, dash, gap: circ-dash, offset }
    offset -= pct*circ
    return arc
  })
  const paidPct = total > 0 ? Math.round((segments[2]?.value||0)/total*100) : 0
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ flexShrink: 0 }}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--b2)" strokeWidth="10" />
      {arcs.map((arc, i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={arc.color} strokeWidth="10"
          strokeDasharray={`${arc.dash} ${arc.gap}`} strokeDashoffset={arc.offset} strokeLinecap="round"
          style={{ transition: `stroke-dasharray 0.8s cubic-bezier(0.16,1,0.3,1) ${i*80}ms` }} />
      ))}
      <text x={cx} y={cy-4} textAnchor="middle" fontSize="14" fontWeight="800" fill="var(--t1)" fontFamily="Inter,sans-serif">{paidPct}%</text>
      <text x={cx} y={cy+9} textAnchor="middle" fontSize="8" fill="var(--t4)" fontFamily="Inter,sans-serif">конверсія</text>
    </svg>
  )
}

export default function Reports() {
  const [stats, setStats] = useState(null)
  const [leads, setLeads] = useState([])
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(true)
  const [period, setPeriod] = useState('week')

  useEffect(() => {
    Promise.all([client.get('/dashboard/stats'), client.get('/leads'), client.get('/tasks')])
      .then(([s, l, t]) => { setStats(s.data); setLeads(Array.isArray(l.data)?l.data:[]); setTasks(Array.isArray(t.data)?t.data:[]) })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="loading-center"><div className="spinner" /></div>

  const total = stats?.total||0, paid = stats?.paid_count||0, newCount = stats?.new_count||0
  const replied = stats?.replied_count||0, canceled = stats?.canceled_count||0
  const convRate = total > 0 ? Math.round((paid/total)*100) : 0
  const totalRevenue = leads.filter(l=>l.status==='paid').reduce((s,l)=>s+(l.amount||0),0)
  const avgDeal = paid > 0 ? totalRevenue/paid : 0

  const days = period==='week'?7:period==='month'?30:90
  const pts = Array.from({ length: Math.min(days,14) }, (_,i) => {
    const d = new Date(); d.setDate(d.getDate()-(Math.min(days,14)-1-i))
    const ds = d.toISOString().slice(0,10)
    const dl = leads.filter(l=>l.created_at?.slice(0,10)===ds)
    return { label: d.toLocaleDateString('uk-UA',{day:'2-digit',month:'short'}), total: dl.length, paid: dl.filter(l=>l.status==='paid').length }
  })

  const statusData = [
    { label:'Нові',      value:newCount, color:'#2563eb', bg:'#eff6ff' },
    { label:'Відповіли', value:replied,  color:'#b45309', bg:'#fffbeb' },
    { label:'Оплачено',  value:paid,     color:'#16a34a', bg:'#f0fdf4' },
    { label:'Скасовано', value:canceled, color:'#dc2626', bg:'#fef2f2' },
  ]

  return (
    <div className="fade-up">
      <div className="page-header">
        <div><h1 className="page-title">Звіти</h1><p className="page-subtitle">Аналітика та статистика воркспейсу</p></div>
        <div className="tabs">
          {[{k:'week',l:'7 днів'},{k:'month',l:'30 днів'},{k:'quarter',l:'90 днів'}].map(p => (
            <button key={p.k} className={`tab${period===p.k?' active':''}`} onClick={()=>setPeriod(p.k)}>{p.l}</button>
          ))}
        </div>
      </div>

      <div className="stats-grid stagger" style={{ gridTemplateColumns:'repeat(4,1fr)', marginBottom:'20px' }}>
        {[
          { label:'Всього лідів', icon:'leads',       color:'#7c3aed', bg:'#f5f3ff', val:total },
          { label:'Оплачено',     icon:'dollar',      color:'#15803d', bg:'#dcfce7', val:paid, sub:`${convRate}% конверсія` },
          { label:'Виручка',      icon:'trending_up', color:'#16a34a', bg:'#f0fdf4', val:`$${totalRevenue.toFixed(0)}` },
          { label:'Середній чек', icon:'pie_chart',   color:'#2563eb', bg:'#eff6ff', val:`$${avgDeal.toFixed(0)}` },
        ].map((s,i) => (
          <div key={i} className="stat-card">
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div className="stat-icon" style={{background:s.bg,color:s.color}}><Icon name={s.icon} size={16} /></div>
            </div>
            <div className="stat-value" style={{fontSize:'26px'}}>{typeof s.val==='string'?s.val:<AnimNum value={s.val}/>}</div>
            <div className="stat-label">{s.label}</div>
            {s.sub && <div style={{fontSize:'11px',color:'var(--t4)',marginTop:'4px'}}>{s.sub}</div>}
          </div>
        ))}
      </div>

      <div className="card" style={{ marginBottom:'16px' }}>
        <div className="card-header">
          <div>
            <span className="card-title">Динаміка лідів</span>
            <div style={{display:'flex',gap:'14px',marginTop:'5px'}}>
              {[{color:'#7c3aed',label:'Всього'},{color:'#16a34a',label:'Оплачено'}].map((ds,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:'5px'}}>
                  <div style={{width:'12px',height:'3px',borderRadius:'2px',background:ds.color}}/>
                  <span style={{fontSize:'11px',color:'var(--t3)'}}>{ds.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div style={{padding:'16px 20px 8px'}}>
          <LineChart datasets={[{label:'Всього',data:pts.map(p=>p.total),color:'#7c3aed'},{label:'Оплачено',data:pts.map(p=>p.paid),color:'#16a34a'}]} labels={pts.map(p=>p.label)} height={180} />
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'16px',marginBottom:'16px'}}>
        <div className="card">
          <div className="card-header"><span className="card-title">Розподіл статусів</span></div>
          <div style={{padding:'20px',display:'flex',gap:'20px',alignItems:'center'}}>
            <DonutChart segments={statusData} size={100} />
            <div style={{flex:1}}>
              {statusData.map(s => {
                const pct = total>0?(s.value/total)*100:0
                return (
                  <div key={s.label} style={{marginBottom:'10px'}}>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:'4px'}}>
                      <div style={{display:'flex',alignItems:'center',gap:'6px'}}>
                        <div style={{width:'8px',height:'8px',borderRadius:'2px',background:s.color}}/>
                        <span style={{fontSize:'12px',color:'var(--t2)',fontWeight:'500'}}>{s.label}</span>
                      </div>
                      <div style={{display:'flex',gap:'8px'}}>
                        <span style={{fontSize:'12px',fontWeight:'700',color:s.color}}>{s.value}</span>
                        <span style={{fontSize:'11px',color:'var(--t4)',width:'28px',textAlign:'right'}}>{Math.round(pct)}%</span>
                      </div>
                    </div>
                    <div style={{height:'4px',background:s.bg,borderRadius:'2px',overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${pct}%`,background:s.color,borderRadius:'2px',transition:'width 0.7s cubic-bezier(0.16,1,0.3,1)'}}/>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header"><span className="card-title">Завдання</span></div>
          <div style={{padding:'20px',display:'flex',flexDirection:'column',gap:'10px'}}>
            {[
              {label:'Виконано',    value:tasks.filter(t=>t.is_completed).length,                   color:'#15803d',bg:'#f0fdf4',icon:'check'},
              {label:'Прострочено', value:tasks.filter(t=>t.is_overdue&&!t.is_completed).length,    color:'#dc2626',bg:'#fef2f2',icon:'warning'},
              {label:'Активних',    value:tasks.filter(t=>!t.is_completed&&!t.is_overdue).length,   color:'#2563eb',bg:'#eff6ff',icon:'tasks'},
            ].map(item=>(
              <div key={item.label} style={{display:'flex',alignItems:'center',gap:'12px',padding:'11px 14px',background:item.bg,borderRadius:'var(--r3)',border:`1px solid ${item.color}20`}}>
                <div style={{width:'30px',height:'30px',borderRadius:'8px',background:item.color+'20',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                  <Icon name={item.icon} size={13} color={item.color}/>
                </div>
                <span style={{flex:1,fontSize:'13px',fontWeight:'500',color:'var(--t2)'}}>{item.label}</span>
                <span style={{fontSize:'22px',fontWeight:'800',color:item.color,letterSpacing:'-0.5px'}}><AnimNum value={item.value}/></span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {paid > 0 && (
        <div className="card">
          <div className="card-header"><span className="card-title">Оплачені ліди</span><span className="badge badge-paid">{paid} клієнтів</span></div>
          <table>
            <thead><tr><th>Клієнт</th><th>Нікнейм</th><th>Сума</th><th>Дата</th></tr></thead>
            <tbody>
              {leads.filter(l=>l.status==='paid').slice(0,8).map(lead=>(
                <tr key={lead.id}>
                  <td><div style={{display:'flex',alignItems:'center',gap:'8px'}}><div style={{width:'26px',height:'26px',borderRadius:'6px',background:'#f0fdf4',color:'#16a34a',fontSize:'11px',fontWeight:'700',display:'flex',alignItems:'center',justifyContent:'center'}}>{lead.name[0]?.toUpperCase()}</div><span style={{fontWeight:'600'}}>{lead.name}</span></div></td>
                  <td style={{color:'var(--t3)'}}>@{lead.username}</td>
                  <td>{lead.amount>0?<span style={{fontWeight:'700',color:'#15803d'}}>${Number(lead.amount).toFixed(2)}</span>:<span style={{color:'var(--t4)'}}>—</span>}</td>
                  <td style={{color:'var(--t3)',fontSize:'12px'}}>{formatDate(lead.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
