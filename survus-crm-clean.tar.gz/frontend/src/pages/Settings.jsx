import { useState, useEffect, useCallback } from 'react'
import client from '../api/client'
import Icon from '../components/Icons'
import { applyTheme } from '../utils/theme'

const ACCENT_COLORS = [
  { name: 'Emerald', value: '#16a34a' },
  { name: 'Blue',    value: '#2563eb' },
  { name: 'Violet',  value: '#7c3aed' },
  { name: 'Rose',    value: '#e11d48' },
  { name: 'Amber',   value: '#d97706' },
  { name: 'Cyan',    value: '#0891b2' },
  { name: 'Slate',   value: '#475569' },
  { name: 'Indigo',  value: '#4338ca' },
]

const ALL_TABS = [
  { key: 'dashboard',    label: 'Дашборд',  icon: 'dashboard', required: true },
  { key: 'leads',        label: 'Ліди',     icon: 'leads',     required: true },
  { key: 'tasks',        label: 'Завдання', icon: 'tasks',     required: false },
  { key: 'reports',      label: 'Звіти',    icon: 'reports',   required: false },
  { key: 'contacts',     label: 'Контакти', icon: 'contacts',  required: false },
  { key: 'deals',        label: 'Угоди',    icon: 'deals',     required: false },
  { key: 'appointments', label: 'Зустрічі', icon: 'calendar',  required: false },
]

const ROLE_META = {
  owner:  { label: 'Власник',        color: '#7c3aed', bg: '#f5f3ff' },
  admin:  { label: 'Адміністратор',  color: '#2563eb', bg: '#eff6ff' },
  helper: { label: 'Помічник',       color: '#16a34a', bg: '#f0fdf4' },
}

const PERM_LABELS = { leads: 'Ліди', tasks: 'Завдання', reports: 'Звіти', settings: 'Налаштування', team: 'Команда' }
const PERM_LEVELS = ['none', 'view', 'edit']

function applyThemeColor(color) {
  applyTheme(color)
}

function shadeColor(color, pct) {
  try {
    const n = parseInt(color.replace('#',''), 16), a = Math.round(2.55 * pct)
    const R = Math.min(255, Math.max(0, (n >> 16) + a))
    const G = Math.min(255, Math.max(0, (n >> 8 & 0xff) + a))
    const B = Math.min(255, Math.max(0, (n & 0xff) + a))
    return '#' + (0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)
  } catch { return color }
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState('workspace')
  const [copied, setCopied] = useState(false)
  const [dragIdx, setDragIdx] = useState(null)
  const [subInfo, setSubInfo] = useState(null)
  const [team, setTeam] = useState([])
  const [showAddMember, setShowAddMember] = useState(false)
  const [newMember, setNewMember] = useState({ name: '', email: '', password: '', role: 'helper' })
  const [addingMember, setAddingMember] = useState(false)
  const [editingPerms, setEditingPerms] = useState(null) // memberId
  const [showEditProfile, setShowEditProfile] = useState(false)
  const [profileForm, setProfileForm] = useState({ email: '', password: '', confirmPassword: '' })
  const [profileError, setProfileError] = useState('')
  const [profileSuccess, setProfileSuccess] = useState(false)
  const [updatingProfile, setUpdatingProfile] = useState(false)

  const workspace = (() => { try { return JSON.parse(localStorage.getItem('survus_workspace') || '{}') } catch { return {} } })()
  const token = localStorage.getItem('survus_token') || ''
  const config = workspace?.crm_config || {}

  const [primaryColor, setPrimaryColor] = useState(config?.primary_color || '#16a34a')
  const [tabs, setTabs] = useState(() => ALL_TABS.map((t, i) => ({ ...t, order: i + 1, enabled: true })))

  const plan = subInfo?.plan || workspace?.subscription_plan || 'free'
  const isProPlus = plan === 'pro_plus'

  // Load subscription info
  useEffect(() => {
    client.get('/subscription/info').then(r => setSubInfo(r.data)).catch(() => {})
  }, [])

  // Load team if PRO+
  useEffect(() => {
    if (isProPlus) {
      client.get('/team').then(r => setTeam(r.data)).catch(() => {})
    }
  }, [isProPlus])

  // Load current user info
  useEffect(() => {
    const user = (() => { try { return JSON.parse(localStorage.getItem('survus_user') || '{}') } catch { return {} } })()
    if (user.email) {
      setProfileForm(p => ({ ...p, email: user.email }))
    }
  }, [])

  function applyColor(color) {
    setPrimaryColor(color)
    applyThemeColor(color)
    try {
      const ws = JSON.parse(localStorage.getItem('survus_workspace') || '{}')
      if (ws.crm_config) { ws.crm_config.primary_color = color; localStorage.setItem('survus_workspace', JSON.stringify(ws)) }
    } catch {}
  }

  function toggleTab(key) { setTabs(p => p.map(t => t.key === key ? { ...t, enabled: !t.enabled } : t)) }
  function moveTab(from, to) {
    const arr = [...tabs]; const [item] = arr.splice(from, 1); arr.splice(to, 0, item)
    setTabs(arr.map((t, i) => ({ ...t, order: i + 1 })))
  }
  function copyToken() { navigator.clipboard.writeText(token); setCopied(true); setTimeout(() => setCopied(false), 2000) }
  function logout() { localStorage.removeItem('survus_token'); localStorage.removeItem('survus_workspace'); window.location.reload() }

  async function handleAddMember(e) {
    e.preventDefault()
    if (!newMember.name.trim()) return
    setAddingMember(true)
    try {
      const res = await client.post('/team', newMember)
      setTeam(p => [...p, res.data])
      setNewMember({ name: '', email: '', password: '', role: 'helper' })
      setShowAddMember(false)
    } catch (err) { alert(err.response?.data?.error || 'Помилка') }
    finally { setAddingMember(false) }
  }

  async function handleRemoveMember(id) {
    if (!confirm('Видалити учасника?')) return
    await client.delete(`/team/${id}`)
    setTeam(p => p.filter(m => m.id !== id))
  }

  async function handleUpdatePerm(memberId, resource, level) {
    const member = team.find(m => m.id === memberId)
    if (!member) return
    const newPerms = { ...member.permissions, [resource]: level }
    const res = await client.patch(`/team/${memberId}`, { permissions: newPerms })
    setTeam(p => p.map(m => m.id === memberId ? res.data : m))
  }

  async function handleUpdateProfile(e) {
    e.preventDefault()
    setProfileError('')
    setProfileSuccess(false)

    if (!profileForm.email.trim()) {
      setProfileError('Email обов\'язковий')
      return
    }

    if (profileForm.password && profileForm.password !== profileForm.confirmPassword) {
      setProfileError('Паролі не співпадають')
      return
    }

    if (profileForm.password && profileForm.password.length < 6) {
      setProfileError('Пароль має бути мінімум 6 символів')
      return
    }

    setUpdatingProfile(true)
    try {
      const payload = { email: profileForm.email.trim() }
      if (profileForm.password) {
        payload.password = profileForm.password
      }
      
      const res = await client.patch('/users/me', payload)
      
      // Update local storage
      const user = (() => { try { return JSON.parse(localStorage.getItem('survus_user') || '{}') } catch { return {} } })()
      user.email = res.data.email
      localStorage.setItem('survus_user', JSON.stringify(user))
      
      setProfileSuccess(true)
      setProfileForm(p => ({ ...p, password: '', confirmPassword: '' }))
      setTimeout(() => {
        setShowEditProfile(false)
        setProfileSuccess(false)
      }, 1500)
    } catch (err) {
      setProfileError(err.response?.data?.error || 'Помилка оновлення')
    } finally {
      setUpdatingProfile(false)
    }
  }

  // Subscription status helpers
  const daysLeft = subInfo?.daysRemaining ?? (workspace?.subscription_until
    ? Math.ceil((new Date(workspace.subscription_until) - new Date()) / 86400000) : null)
  const subStatus = subInfo?.status || workspace?.subscription_status || 'active'
  const subUntil = subInfo?.subscriptionUntil || workspace?.subscription_until
  const statusColor = subStatus === 'active' && daysLeft > 7 ? '#15803d'
    : subStatus === 'active' && daysLeft <= 7 ? '#b45309' : '#dc2626'
  const statusLabel = subStatus === 'active' && daysLeft > 7 ? 'Активна'
    : subStatus === 'active' && daysLeft <= 7 ? 'Закінчується' : 'Прострочена'

  const TABS_NAV = [
    { key: 'workspace',   label: 'Воркспейс',  icon: 'building' },
    { key: 'appearance',  label: 'Вигляд',      icon: 'settings' },
    { key: 'subscription',label: 'Підписка',    icon: 'credit_card' },
    ...(isProPlus ? [{ key: 'team', label: 'Команда', icon: 'users' }] : []),
  ]

  return (
    <div className="fade-up" style={{ maxWidth: '800px' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">Налаштування</h1>
          <p className="page-subtitle">Персоналізуйте ваш воркспейс</p>
        </div>
      </div>

      {/* Tab nav */}
      <div style={{ display: 'flex', gap: '2px', background: 'var(--s2)', borderRadius: 'var(--r3)', padding: '4px', border: '1px solid var(--b1)', marginBottom: '24px', width: 'fit-content' }}>
        {TABS_NAV.map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '7px 16px', borderRadius: 'var(--r2)', border: 'none', cursor: 'pointer', background: activeTab === t.key ? 'var(--s0)' : 'transparent', color: activeTab === t.key ? 'var(--t1)' : 'var(--t4)', fontSize: '12.5px', fontWeight: activeTab === t.key ? '600' : '400', boxShadow: activeTab === t.key ? 'var(--sh0)' : 'none', transition: 'all 0.15s cubic-bezier(0.16,1,0.3,1)' }}>
            <Icon name={t.icon} size={13} />{t.label}
          </button>
        ))}
      </div>

      {/* ── WORKSPACE TAB ── */}
      {activeTab === 'workspace' && (
        <div className="stagger">
          <div className="card" style={{ marginBottom: '14px' }}>
            <div className="card-header"><div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Icon name="building" size={14} color="var(--t4)" /><span className="card-title">Інформація</span></div></div>
            <div style={{ padding: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '20px' }}>
                <div style={{ width: '56px', height: '56px', borderRadius: '16px', background: primaryColor + '18', color: primaryColor, fontSize: '22px', fontWeight: '800', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, border: `1px solid ${primaryColor}30`, transition: 'all 0.3s' }}>
                  {(workspace.company_name || 'W')[0].toUpperCase()}
                </div>
                <div>
                  <div style={{ fontSize: '18px', fontWeight: '800', color: 'var(--t1)', marginBottom: '6px', letterSpacing: '-0.02em' }}>{workspace.company_name || 'Workspace'}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '20px', fontSize: '11px', fontWeight: '600', background: statusColor + '15', color: statusColor }}>
                      <span style={{ width: '5px', height: '5px', borderRadius: '50%', background: statusColor, display: 'inline-block' }} />
                      {statusLabel}
                    </span>
                    {plan !== 'free' && (
                      <span style={{ display: 'inline-flex', padding: '3px 8px', borderRadius: '20px', fontSize: '11px', fontWeight: '700', background: plan === 'pro_plus' ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'linear-gradient(135deg,#7c3aed,#4f46e5)', color: '#fff' }}>
                        {plan === 'pro_plus' ? 'PRO+' : 'PRO'}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="info-row"><span className="info-label">Шаблон CRM</span><span className="info-value"><code style={{ fontSize: '12px', fontFamily: 'var(--mono)', background: 'var(--s2)', padding: '2px 8px', borderRadius: 'var(--r1)', border: '1px solid var(--b1)' }}>{config?.id || workspace?.template_id || '—'}</code></span></div>
              <div className="info-row"><span className="info-label">Колір бренду</span><span className="info-value" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><div style={{ width: '20px', height: '20px', borderRadius: '5px', background: primaryColor, border: '1px solid rgba(0,0,0,0.1)', transition: 'background 0.3s' }} /><code style={{ fontSize: '12px', fontFamily: 'var(--mono)', color: 'var(--t3)' }}>{primaryColor}</code></span></div>
            </div>
          </div>
          <div className="card" style={{ marginBottom: '14px' }}>
            <div className="card-header"><div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Icon name="key" size={14} color="var(--t4)" /><span className="card-title">Токен доступу</span></div></div>
            <div style={{ padding: '18px 20px' }}>
              <p style={{ fontSize: '12.5px', color: 'var(--t4)', marginBottom: '12px' }}>Не передавайте токен стороннім особам.</p>
              <div style={{ display: 'flex', gap: '8px' }}>
                <div style={{ flex: 1, background: 'var(--s2)', border: '1.5px solid var(--b1)', borderRadius: 'var(--r2)', padding: '9px 12px', fontFamily: 'var(--mono)', fontSize: '12px', color: 'var(--t3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {token ? token.slice(0, 8) + '••••••••••••••••••••••••••••' : '—'}
                </div>
                <button onClick={copyToken} className={`btn ${copied ? 'btn-secondary' : 'btn-primary'} btn-sm`}><Icon name={copied ? 'check' : 'copy'} size={12} />{copied ? 'Скопійовано' : 'Копіювати'}</button>
              </div>
            </div>
          </div>
          <div className="card">
            <div style={{ padding: '18px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div><div style={{ fontSize: '13.5px', fontWeight: '600', color: 'var(--t1)', marginBottom: '2px' }}>Редагувати профіль</div><div style={{ fontSize: '12px', color: 'var(--t4)' }}>Змінити email або пароль</div></div>
              <button onClick={() => setShowEditProfile(true)} className="btn btn-secondary btn-sm"><Icon name="edit" size={12} /> Редагувати</button>
            </div>
          </div>
          <div className="card">
            <div style={{ padding: '18px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div><div style={{ fontSize: '13.5px', fontWeight: '600', color: 'var(--t1)', marginBottom: '2px' }}>Вийти з воркспейсу</div><div style={{ fontSize: '12px', color: 'var(--t4)' }}>Для повторного входу знадобиться токен</div></div>
              <button onClick={logout} className="btn btn-danger btn-sm"><Icon name="logout" size={12} /> Вийти</button>
            </div>
          </div>
        </div>
      )}

      {/* ── APPEARANCE TAB ── */}
      {activeTab === 'appearance' && (
        <div className="stagger">
          <div className="card" style={{ marginBottom: '14px' }}>
            <div className="card-header"><span className="card-title">Колір акценту</span><div style={{ width: '20px', height: '20px', borderRadius: '5px', background: primaryColor, border: '1px solid rgba(0,0,0,0.1)', transition: 'background 0.3s' }} /></div>
            <div style={{ padding: '20px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: '8px', marginBottom: '16px' }}>
                {ACCENT_COLORS.map(c => (
                  <div key={c.value} onClick={() => applyColor(c.value)} style={{ cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px' }}>
                    <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: c.value, border: primaryColor === c.value ? '3px solid var(--t1)' : '2px solid transparent', boxShadow: `0 2px 6px ${c.value}40`, transition: 'all 0.2s cubic-bezier(0.16,1,0.3,1)', transform: primaryColor === c.value ? 'scale(1.12)' : 'scale(1)' }} />
                    <span style={{ fontSize: '9.5px', color: 'var(--t4)', fontWeight: '500' }}>{c.name}</span>
                  </div>
                ))}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <input type="color" value={primaryColor} onChange={e => applyColor(e.target.value)} style={{ width: '44px', height: '38px', border: '1.5px solid var(--b1)', borderRadius: 'var(--r2)', cursor: 'pointer', padding: '3px' }} />
                <span style={{ fontSize: '12.5px', color: 'var(--t3)' }}>Або введіть свій колір</span>
                <code style={{ fontSize: '12px', fontFamily: 'var(--mono)', color: 'var(--t2)', background: 'var(--s2)', padding: '4px 10px', borderRadius: 'var(--r1)', border: '1px solid var(--b1)', transition: 'all 0.3s' }}>{primaryColor}</code>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-header"><span className="card-title">Розділи навігації</span><span style={{ fontSize: '12px', color: 'var(--t4)' }}>Перетягніть для зміни порядку</span></div>
            <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: '5px' }}>
              {tabs.map((tab, i) => {
                const meta = ALL_TABS.find(t => t.key === tab.key)
                return (
                  <div key={tab.key} draggable={!meta?.required}
                    onDragStart={() => setDragIdx(i)}
                    onDragOver={e => { e.preventDefault(); if (dragIdx !== null && dragIdx !== i) { moveTab(dragIdx, i); setDragIdx(i) } }}
                    onDragEnd={() => setDragIdx(null)}
                    style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px', borderRadius: 'var(--r2)', background: tab.enabled ? 'var(--s0)' : 'var(--s2)', border: `1px solid ${tab.enabled ? 'var(--b1)' : 'var(--b2)'}`, opacity: dragIdx === i ? 0.4 : 1, transition: 'all 0.15s cubic-bezier(0.16,1,0.3,1)', cursor: meta?.required ? 'default' : 'grab' }}>
                    {!meta?.required && <Icon name="filter" size={12} color="var(--t5)" />}
                    <span style={{ color: tab.enabled ? 'var(--p)' : 'var(--t5)', display: 'flex', transition: 'color 0.2s' }}><Icon name={meta?.icon || 'info'} size={14} /></span>
                    <span style={{ flex: 1, fontSize: '13.5px', fontWeight: '500', color: tab.enabled ? 'var(--t1)' : 'var(--t4)', transition: 'color 0.2s' }}>{tab.label}</span>
                    <span style={{ fontSize: '11px', color: 'var(--t5)', marginRight: '4px' }}>#{i + 1}</span>
                    {meta?.required
                      ? <span style={{ fontSize: '10px', color: 'var(--p)', fontWeight: '600', background: 'var(--p-light)', padding: '2px 6px', borderRadius: '4px' }}>обов.</span>
                      : <label className="toggle"><input type="checkbox" checked={!!tab.enabled} onChange={() => toggleTab(tab.key)} /><span className="toggle-slider" /></label>
                    }
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── SUBSCRIPTION TAB ── */}
      {activeTab === 'subscription' && (
        <div className="stagger">
          {/* Plan hero card */}
          <div style={{ borderRadius: 'var(--r4)', overflow: 'hidden', marginBottom: '14px', boxShadow: 'var(--sh2)' }}>
            <div style={{ background: plan === 'pro_plus' ? 'linear-gradient(135deg,#f59e0b,#d97706)' : plan === 'pro' ? 'linear-gradient(135deg,#7c3aed,#4f46e5)' : `linear-gradient(135deg,${primaryColor},${primaryColor}bb)`, padding: '24px 28px', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: '-40px', right: '-40px', width: '140px', height: '140px', borderRadius: '50%', background: 'rgba(255,255,255,0.07)' }} />
              <div style={{ position: 'absolute', bottom: '-20px', left: '40%', width: '80px', height: '80px', borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />
              <div style={{ fontSize: '10px', fontWeight: '700', color: 'rgba(255,255,255,0.65)', textTransform: 'uppercase', letterSpacing: '0.12em', marginBottom: '8px' }}>Поточний план</div>
              <div style={{ fontSize: '32px', fontWeight: '900', color: '#fff', letterSpacing: '-0.5px', marginBottom: '6px' }}>
                {plan === 'pro_plus' ? 'PRO+' : plan === 'pro' ? 'PRO' : 'Free'}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', background: 'rgba(255,255,255,0.18)', padding: '5px 12px', borderRadius: '20px' }}>
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: statusColor === '#15803d' ? '#4ade80' : statusColor === '#b45309' ? '#fbbf24' : '#f87171', display: 'inline-block' }} />
                  <span style={{ fontSize: '12px', color: '#fff', fontWeight: '600' }}>{statusLabel}</span>
                </div>
                {subUntil && (
                  <span style={{ fontSize: '12px', color: 'rgba(255,255,255,0.8)' }}>
                    До {new Date(subUntil).toLocaleDateString('uk-UA', { day: '2-digit', month: 'long', year: 'numeric' })}
                  </span>
                )}
              </div>
              {daysLeft !== null && daysLeft <= 14 && daysLeft > 0 && (
                <div style={{ marginTop: '12px', display: 'inline-flex', alignItems: 'center', gap: '5px', background: 'rgba(255,255,255,0.18)', padding: '5px 12px', borderRadius: '20px' }}>
                  <Icon name="clock" size={11} color="rgba(255,255,255,0.9)" />
                  <span style={{ fontSize: '12px', color: '#fff', fontWeight: '600' }}>{daysLeft} днів залишилось</span>
                </div>
              )}
            </div>
            {daysLeft !== null && daysLeft > 0 && (
              <div style={{ background: 'var(--s0)', padding: '12px 28px', borderTop: '1px solid var(--b2)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span style={{ fontSize: '11px', color: 'var(--t4)' }}>Залишилось днів</span>
                  <span style={{ fontSize: '11px', fontWeight: '700', color: daysLeft <= 7 ? '#dc2626' : 'var(--t2)' }}>{daysLeft} / {daysLeft > 30 ? 365 : 30}</span>
                </div>
                <div style={{ height: '5px', background: 'var(--s3)', borderRadius: '3px', overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${Math.min((daysLeft / (daysLeft > 30 ? 365 : 30)) * 100, 100)}%`, background: daysLeft <= 7 ? '#dc2626' : daysLeft <= 14 ? '#f59e0b' : primaryColor, borderRadius: '3px', transition: 'width 0.8s cubic-bezier(0.16,1,0.3,1)' }} />
                </div>
              </div>
            )}
          </div>

          {/* Features list */}
          <div className="card">
            <div className="card-header"><span className="card-title">Що включено</span></div>
            <div style={{ padding: '16px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              {(subInfo?.features || ['basic_crm']).map(f => {
                const names = { basic_crm:'Базовий CRM', up_to_100_leads:'До 100 лідів', basic_analytics:'Базова аналітика', unlimited_leads:'Необмежені ліди', advanced_analytics:'Розширена аналітика', custom_themes:'Кастомні теми', priority_support:'Пріоритетна підтримка', export_data:'Експорт даних', ai_insights:'AI-інсайти', custom_integrations:'Інтеграції', white_label:'White-label', api_access:'API доступ' }
                return (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', color: 'var(--t2)' }}>
                    <div style={{ width: '18px', height: '18px', borderRadius: '50%', background: 'var(--p-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name="check" size={10} color="var(--p)" /></div>
                    {names[f] || f}
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── TEAM TAB (PRO+ only) ── */}
      {activeTab === 'team' && isProPlus && (
        <div className="stagger">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div>
              <div style={{ fontSize: '15px', fontWeight: '700', color: 'var(--t1)' }}>Команда</div>
              <div style={{ fontSize: '12px', color: 'var(--t4)', marginTop: '2px' }}>Управляйте доступом учасників до воркспейсу</div>
            </div>
            <button onClick={() => setShowAddMember(true)} className="btn btn-primary btn-sm"><Icon name="plus" size={12} /> Додати учасника</button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {team.map(member => {
              const rm = ROLE_META[member.role] || ROLE_META.helper
              const isEditing = editingPerms === member.id
              return (
                <div key={member.id} className="card" style={{ overflow: 'hidden' }}>
                  <div style={{ padding: '14px 18px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: rm.bg, color: rm.color, fontSize: '14px', fontWeight: '700', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {member.name[0]?.toUpperCase()}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: '13.5px', fontWeight: '600', color: 'var(--t1)' }}>{member.name}</div>
                      {member.email && <div style={{ fontSize: '11.5px', color: 'var(--t4)' }}>{member.email}</div>}
                    </div>
                    <span style={{ fontSize: '11px', fontWeight: '700', padding: '3px 9px', borderRadius: '20px', background: rm.bg, color: rm.color }}>{rm.label}</span>
                    {member.role !== 'owner' && (
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button onClick={() => setEditingPerms(isEditing ? null : member.id)} className="btn btn-ghost btn-icon-sm" title="Права доступу"><Icon name="settings" size={13} /></button>
                        <button onClick={() => handleRemoveMember(member.id)} className="btn btn-ghost btn-icon-sm" style={{ color: '#dc2626' }} title="Видалити"><Icon name="trash" size={13} /></button>
                      </div>
                    )}
                  </div>
                  {isEditing && (
                    <div style={{ padding: '0 18px 16px', borderTop: '1px solid var(--b2)', paddingTop: '14px' }}>
                      <div style={{ fontSize: '11px', fontWeight: '700', color: 'var(--t4)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: '10px' }}>Права доступу</div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '8px' }}>
                        {Object.entries(PERM_LABELS).map(([res, label]) => (
                          <div key={res} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 10px', background: 'var(--s1)', borderRadius: 'var(--r2)', border: '1px solid var(--b1)' }}>
                            <span style={{ fontSize: '12.5px', color: 'var(--t2)', fontWeight: '500' }}>{label}</span>
                            <select value={member.permissions[res] || 'none'} onChange={e => handleUpdatePerm(member.id, res, e.target.value)} style={{ border: '1px solid var(--b1)', borderRadius: 'var(--r1)', padding: '3px 6px', fontSize: '11.5px', background: 'var(--s0)', color: 'var(--t1)', cursor: 'pointer', outline: 'none' }}>
                              {PERM_LEVELS.map(l => <option key={l} value={l}>{l === 'none' ? 'Немає' : l === 'view' ? 'Перегляд' : 'Редагування'}</option>)}
                            </select>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
            {team.length === 0 && (
              <div className="empty-state"><div className="empty-icon"><Icon name="users" size={28} /></div><div className="empty-title">Команда порожня</div><div className="empty-sub">Додайте учасників для спільної роботи</div></div>
            )}
          </div>

          {/* Add member modal */}
          {showAddMember && (
            <div className="overlay" onClick={() => setShowAddMember(false)}>
              <div className="modal" onClick={e => e.stopPropagation()}>
                <div className="modal-header"><div><div className="modal-title">Додати учасника</div><div className="modal-subtitle">Запросіть колегу до воркспейсу</div></div><button className="btn btn-ghost btn-icon-sm" onClick={() => setShowAddMember(false)}><Icon name="x" size={14} /></button></div>
                <form onSubmit={handleAddMember} className="modal-body">
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                    <div className="form-group"><label className="form-label">Ім'я <span className="form-required">*</span></label><input className="input" value={newMember.name} onChange={e => setNewMember(p => ({ ...p, name: e.target.value }))} placeholder="Ім'я учасника" autoFocus /></div>
                    <div className="form-group"><label className="form-label">Email <span className="form-required">*</span></label><input className="input" type="email" value={newMember.email} onChange={e => setNewMember(p => ({ ...p, email: e.target.value }))} placeholder="email@example.com" /></div>
                    <div className="form-group"><label className="form-label">Пароль <span className="form-required">*</span></label><input className="input" type="password" value={newMember.password} onChange={e => setNewMember(p => ({ ...p, password: e.target.value }))} placeholder="Мінімум 6 символів" /><div className="form-hint">Учасник зможе увійти через email та пароль</div></div>
                    <div className="form-group">
                      <label className="form-label">Роль</label>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        {['admin','helper'].map(role => {
                          const rm = ROLE_META[role]
                          return <button key={role} type="button" onClick={() => setNewMember(p => ({ ...p, role }))} style={{ flex: 1, padding: '10px', borderRadius: 'var(--r2)', border: `2px solid ${newMember.role === role ? rm.color : 'var(--b1)'}`, background: newMember.role === role ? rm.bg : 'var(--s0)', cursor: 'pointer', transition: 'all 0.15s' }}>
                            <div style={{ fontSize: '13px', fontWeight: '700', color: rm.color }}>{rm.label}</div>
                            <div style={{ fontSize: '11px', color: 'var(--t4)', marginTop: '2px' }}>{role === 'admin' ? 'Повний доступ' : 'Обмежений доступ'}</div>
                          </button>
                        })}
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '10px', marginTop: '4px' }}>
                      <button type="submit" disabled={addingMember || !newMember.name.trim() || !newMember.email.trim() || !newMember.password.trim()} className="btn btn-primary" style={{ flex: 1 }}>{addingMember ? 'Додаємо...' : 'Додати'}</button>
                      <button type="button" className="btn btn-secondary" onClick={() => setShowAddMember(false)}>Скасувати</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
    </div>

    {/* Edit Profile Modal */}
    {showEditProfile && (
      <div className="overlay" onClick={() => setShowEditProfile(false)}>
        <div className="modal" onClick={e => e.stopPropagation()}>
          <div className="modal-header">
            <div><div className="modal-title">Редагувати профіль</div><div className="modal-subtitle">Оновіть свої дані</div></div>
            <button className="btn btn-ghost btn-icon-sm" onClick={() => setShowEditProfile(false)}><Icon name="x" size={14} /></button>
          </div>
          <form onSubmit={handleUpdateProfile} className="modal-body">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div className="form-group">
                <label className="form-label">Email <span className="form-required">*</span></label>
                <input className="input" type="email" value={profileForm.email} onChange={e => setProfileForm(p => ({ ...p, email: e.target.value }))} placeholder="your@email.com" />
              </div>
              <div className="form-group">
                <label className="form-label">Новий пароль</label>
                <input className="input" type="password" value={profileForm.password} onChange={e => setProfileForm(p => ({ ...p, password: e.target.value }))} placeholder="Залиште порожнім, щоб не змінювати" />
                <div className="form-hint">Мінімум 6 символів</div>
              </div>
              {profileForm.password && (
                <div className="form-group">
                  <label className="form-label">Підтвердіть пароль <span className="form-required">*</span></label>
                  <input className="input" type="password" value={profileForm.confirmPassword} onChange={e => setProfileForm(p => ({ ...p, confirmPassword: e.target.value }))} placeholder="Повторіть пароль" />
                </div>
              )}
              {profileError && <div className="form-error"><Icon name="warning" size={13} />{profileError}</div>}
              {profileSuccess && <div className="form-success"><Icon name="check" size={13} />Профіль успішно оновлено!</div>}
              <div style={{ display: 'flex', gap: '10px', marginTop: '4px' }}>
                <button type="submit" disabled={updatingProfile} className="btn btn-primary" style={{ flex: 1 }}>{updatingProfile ? 'Оновлюємо...' : 'Зберегти'}</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowEditProfile(false)}>Скасувати</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    )}
  </div>
  )
}
