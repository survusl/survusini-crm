import { useState, useEffect } from 'react'
import client from '../api/client'
import Icon from '../components/Icons'

function formatDateTime(str) {
  if (!str) return '—'
  return new Date(str).toLocaleString('uk-UA', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
}

const TABS = [
  { key: 'all', label: 'Всі' },
  { key: 'active', label: 'Активні' },
  { key: 'overdue', label: 'Прострочені' },
  { key: 'done', label: 'Виконані' },
]

export default function Tasks() {
  const [tasks, setTasks] = useState([])
  const [tab, setTab] = useState('all')
  const [loading, setLoading] = useState(true)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ title: '', due_date: '' })
  const [submitting, setSubmitting] = useState(false)
  const [formError, setFormError] = useState(null)

  const fetchTasks = async () => {
    try {
      const res = await client.get('/tasks')
      setTasks(Array.isArray(res.data) ? res.data : [])
    } catch { setTasks([]) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchTasks() }, [])

  const handleComplete = async (id) => {
    try { await client.patch(`/tasks/${id}/complete`); fetchTasks() } catch {}
  }

  const handleAdd = async e => {
    e.preventDefault()
    if (!form.title.trim() || !form.due_date) { setFormError('Назва та дата обовʼязкові'); return }
    setSubmitting(true); setFormError(null)
    try {
      await client.post('/tasks', { title: form.title.trim(), due_date: new Date(form.due_date).toISOString() })
      setShowAdd(false); setForm({ title: '', due_date: '' }); fetchTasks()
    } catch (e) { setFormError(e?.response?.data?.error || 'Помилка при додаванні') }
    finally { setSubmitting(false) }
  }

  const filtered = tasks.filter(t => {
    if (tab === 'active') return !t.is_completed && !t.is_overdue
    if (tab === 'overdue') return t.is_overdue && !t.is_completed
    if (tab === 'done') return !!t.is_completed
    return true
  })

  const counts = {
    all: tasks.length,
    active: tasks.filter(t => !t.is_completed && !t.is_overdue).length,
    overdue: tasks.filter(t => t.is_overdue && !t.is_completed).length,
    done: tasks.filter(t => t.is_completed).length,
  }

  return (
    <div className="fade-up">
      <div className="page-header">
        <div>
          <h1 className="page-title">Завдання</h1>
          <p className="page-subtitle">{tasks.length} завдань · {counts.overdue > 0 && <span style={{ color: '#dc2626' }}>{counts.overdue} прострочено</span>}</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn btn-primary">
          <Icon name="plus" size={13} /> Нове завдання
        </button>
      </div>

      {/* Tabs */}
      <div className="tabs" style={{ marginBottom: '16px' }}>
        {TABS.map(t => (
          <button key={t.key} className={`tab${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>
            {t.label}
            <span className="tab-count">{counts[t.key]}</span>
          </button>
        ))}
      </div>

      {/* List */}
      {loading ? (
        <div className="loading-center"><div className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="card">
          <div className="empty-state">
            <div className="empty-icon"><Icon name={tab === 'done' ? 'check' : tab === 'overdue' ? 'warning' : 'tasks'} size={32} /></div>
            <div className="empty-title">
              {tab === 'done' ? 'Виконаних завдань немає' : tab === 'overdue' ? 'Прострочених немає!' : 'Завдань немає'}
            </div>
            <div className="empty-sub">
              {tab === 'overdue' ? 'Чудово! Всі завдання вчасно.' : 'Додайте нове завдання'}
            </div>
          </div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {filtered.map(task => {
            const overdue = task.is_overdue && !task.is_completed
            const done = !!task.is_completed
            return (
              <div key={task.id} style={{
                background: 'var(--surface)', borderRadius: 'var(--radius)',
                padding: '13px 16px',
                border: `1px solid ${overdue ? '#fecaca' : 'var(--border)'}`,
                borderLeft: `3px solid ${overdue ? '#dc2626' : done ? '#16a34a' : 'var(--primary)'}`,
                display: 'flex', alignItems: 'center', gap: '12px',
                opacity: done ? 0.65 : 1,
                boxShadow: 'var(--shadow-xs)',
              }}>
                {/* Checkbox */}
                <div
                  onClick={() => !done && handleComplete(task.id)}
                  style={{
                    width: '20px', height: '20px', borderRadius: '5px', flexShrink: 0,
                    border: `2px solid ${done ? '#16a34a' : 'var(--border)'}`,
                    background: done ? '#16a34a' : 'var(--surface)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    cursor: done ? 'default' : 'pointer', transition: 'all 0.15s',
                  }}
                >
                  {done && <Icon name="check" size={11} color="#fff" />}
                </div>

                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: '13.5px', fontWeight: '500', color: done ? 'var(--text-3)' : 'var(--text)', textDecoration: done ? 'line-through' : 'none', marginBottom: '2px' }}>
                    {task.title}
                  </div>
                  <div style={{ fontSize: '11.5px', color: overdue ? '#dc2626' : 'var(--text-3)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <Icon name="clock" size={10} />
                    {overdue ? 'Прострочено · ' : done ? 'Виконано · ' : ''}
                    {formatDateTime(task.due_date)}
                  </div>
                </div>

                {overdue && <Icon name="warning" size={15} color="#dc2626" />}
                {done && <Icon name="check" size={15} color="#16a34a" />}
                {!done && (
                  <button onClick={() => handleComplete(task.id)} className="btn btn-secondary btn-sm">
                    Виконати
                  </button>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* Add modal */}
      {showAdd && (
        <div className="overlay" onClick={() => setShowAdd(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <div className="modal-title">Нове завдання</div>
                <div className="modal-subtitle">Заплануйте нагадування</div>
              </div>
              <button onClick={() => setShowAdd(false)} className="btn btn-ghost btn-icon-sm">
                <Icon name="x" size={14} />
              </button>
            </div>
            <div className="modal-body">
              <form onSubmit={handleAdd} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <div className="form-group">
                  <label className="form-label">Назва завдання <span className="form-required">*</span></label>
                  <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Введіть назву..." className="input" autoFocus />
                </div>
                <div className="form-group">
                  <label className="form-label">Дата виконання <span className="form-required">*</span></label>
                  <input type="datetime-local" value={form.due_date} onChange={e => setForm(p => ({ ...p, due_date: e.target.value }))} className="input" />
                </div>
                {formError && <div className="form-error"><Icon name="warning" size={13} />{formError}</div>}
                <div style={{ display: 'flex', gap: '10px', marginTop: '8px' }}>
                  <button type="submit" className="btn btn-primary" disabled={submitting} style={{ flex: 1 }}>
                    {submitting ? 'Додаємо...' : <><Icon name="plus" size={13} /> Додати</>}
                  </button>
                  <button type="button" onClick={() => setShowAdd(false)} className="btn btn-secondary">Скасувати</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
