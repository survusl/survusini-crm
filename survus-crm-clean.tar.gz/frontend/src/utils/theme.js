function shadeColor(color, percent) {
  try {
    const num = parseInt(color.replace('#', ''), 16)
    const amt = Math.round(2.55 * percent)
    const R = Math.min(255, Math.max(0, (num >> 16) + amt))
    const G = Math.min(255, Math.max(0, (num >> 8 & 0x00FF) + amt))
    const B = Math.min(255, Math.max(0, (num & 0x0000FF) + amt))
    return '#' + (0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)
  } catch { return color }
}

export function applyTheme(color) {
  if (!color) return
  const root = document.documentElement
  root.style.setProperty('--primary', color)
  root.style.setProperty('--primary-dark', shadeColor(color, -15))
  root.style.setProperty('--primary-hover', shadeColor(color, -12))
  root.style.setProperty('--primary-light', color + '18')
  root.style.setProperty('--primary-bg', color + '0d')
  root.style.setProperty('--primary-border', color + '33')
  root.style.setProperty('--p', color)
  root.style.setProperty('--p-hover', shadeColor(color, -12))
  root.style.setProperty('--p-light', color + '14')
  root.style.setProperty('--p-border', color + '33')
  root.style.setProperty('--p-glow', `0 0 0 3px ${color}22`)
  localStorage.setItem('survus_theme_color', color)
}
