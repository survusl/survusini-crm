@echo off
echo ========================================
echo    SURVUS CRM - Zapusk vsoho proektu
echo ========================================
echo.

REM Perevirka Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js ne vstanovleno!
    echo Vstanovit Node.js z https://nodejs.org/
    pause
    exit /b 1
)

echo [OK] Node.js vstanovleno
node -v
echo.

REM Vstanovlennya zalezhnostey
if not exist "backend\node_modules" (
    echo [INFO] Vstanovlennya zalezhnostey dlya backend...
    cd backend
    call npm install
    cd ..
)

if not exist "frontend\node_modules" (
    echo [INFO] Vstanovlennya zalezhnostey dlya frontend...
    cd frontend
    call npm install
    cd ..
)

if not exist "admin\node_modules" (
    echo [INFO] Vstanovlennya zalezhnostey dlya admin...
    cd admin
    call npm install
    cd ..
)

echo.
echo [INFO] Zapusk migratsiy bazy danykh...
cd backend
node src\migrate.js
cd ..

echo.
echo [OK] Vse hotovo! Zapuskayemo servery...
echo.
echo Backend:  http://localhost:3001
echo Frontend: http://localhost:5173
echo Admin:    http://localhost:5174
echo.
echo Natysnit Ctrl+C dlya zupynky
echo.

REM Zapusk serveriv
start "Backend" cmd /k "cd backend && npm start"
timeout /t 2 /nobreak >nul
start "Frontend" cmd /k "cd frontend && npm run dev"
timeout /t 2 /nobreak >nul
start "Admin" cmd /k "cd admin && npm run dev"

echo.
echo [OK] Servery zapushcheni v okremykh viknakh!
echo Zakryyty vsi vikna dlya zupynky serveriv.
pause
