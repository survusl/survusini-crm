#!/bin/bash

echo "🚀 SURVUS CRM - Запуск всього проекту"
echo "======================================"

# Кольори
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Перевірка Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js не встановлено!${NC}"
    echo "Встановіть Node.js з https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✅ Node.js $(node -v)${NC}"

# Перевірка npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm не встановлено!${NC}"
    exit 1
fi

echo -e "${GREEN}✅ npm $(npm -v)${NC}"
echo ""

# Функція для перевірки чи встановлені залежності
check_dependencies() {
    if [ ! -d "$1/node_modules" ]; then
        echo -e "${BLUE}📦 Встановлення залежностей для $1...${NC}"
        cd "$1" && npm install && cd ..
    else
        echo -e "${GREEN}✅ Залежності для $1 вже встановлені${NC}"
    fi
}

# Перевірка та встановлення залежностей
check_dependencies "backend"
check_dependencies "frontend"
check_dependencies "admin"

echo ""
echo -e "${BLUE}🗄️  Запуск міграцій бази даних...${NC}"
cd backend && node src/migrate.js
cd ..

echo ""
echo -e "${GREEN}✅ Все готово! Запускаємо сервери...${NC}"
echo ""
echo "📍 Backend:  http://localhost:3001"
echo "📍 Frontend: http://localhost:5173"
echo "📍 Admin:    http://localhost:5174"
echo ""
echo "Натисніть Ctrl+C для зупинки всіх серверів"
echo ""

# Запуск всіх серверів
trap 'kill 0' EXIT

cd backend && npm start &
cd frontend && npm run dev &
cd admin && npm run dev &

wait
