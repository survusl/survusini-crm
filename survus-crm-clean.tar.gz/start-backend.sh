#!/bin/bash
export PATH="/Users/dobroslavbabak/.nvm/versions/node/v20.20.1/bin:$PATH"
cd backend
npm run dev
