#!/bin/bash
export PATH="/Users/dobroslavbabak/.nvm/versions/node/v20.20.1/bin:$PATH"

echo "🚀 Запуск SURVUS CRM..."

# Backend
cd backend
node src/server.js &
BACKEND_PID=$!
cd ..

sleep 2

# Frontend
cd frontend
npm run dev &
FRONTEND_PID=$!
cd ..

# Admin
cd admin
npm run dev -- --port 5174 &
ADMIN_PID=$!
cd ..

echo ""
echo "✅ SURVUS запущено!"
echo ""
echo "  🖥  CRM:    http://localhost:5173"
echo "  ⚙️  Admin:  http://localhost:5174"
echo ""
echo "  Пароль адміна: admin123"
echo ""
echo "Натисни Ctrl+C щоб зупинити"

# Open browser
sleep 2
open http://localhost:5174

wait
